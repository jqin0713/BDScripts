using UnityEngine;
using System.Collections;
using DG.Tweening;
using UnityEngine.EventSystems;
using System.Collections.Generic;
using UnityEngine.Events;

namespace LGG {
    public class Clickable : LGG.LGBehaviour, IPointerDownHandler, IPointerUpHandler, IPointerClickHandler {
        public Transform Target;
        public Vector3 StartScale;
        public bool BloopOnPress;
        public MessageEnum OnPressMessage, OnReleaseMessage, OnClickMessage;
        public TouchEvent OnPressEvent, OnReleaseEvent, OnClickEvent;

    	protected Sequence sequence;

    	void Start() {
    		if (Target == null)
    			Target = transform;

    		if(StartScale == Vector3.zero)
    			StartScale = Target.localScale;
    	}

        public void OnPointerDown(PointerEventData eventData) {
            if (BloopOnPress)
                BloopDown();

            Messenger.Broadcast<PointerEventData>(OnPressMessage, eventData);
            OnPressEvent.Invoke(eventData);
        }

        public void OnPointerUp(PointerEventData eventData) {
            if (BloopOnPress)
                BloopUp();
            
            Messenger.Broadcast<PointerEventData>(OnReleaseMessage, eventData);
            OnReleaseEvent.Invoke(eventData);
        }

        public void OnPointerClick(PointerEventData eventData) {
            Messenger.Broadcast<PointerEventData>(OnClickMessage, eventData);
            OnClickEvent.Invoke(eventData);
        }

    	void OnDestroy() {
    		sequence.Kill();
    	}

        public void BloopDown() {
            if (sequence != null)
            {
                Target.localScale = StartScale;
                sequence.Kill();
            }

            sequence = DOTween.Sequence();
            sequence.Append( DOTween.To(() => Target.localScale, s => Target.localScale = s, StartScale * 1.2f, 0.2f).SetEase(Ease.OutQuad) );
            sequence.Append( DOTween.To(() => Target.localScale, s => Target.localScale = s, StartScale * 0.98f, 0.13333f).SetEase(Ease.InQuad) );
            sequence.Append( DOTween.To(() => Target.localScale, s => Target.localScale = s, StartScale * 1.02f, 0.0666f).SetEase(Ease.OutQuad) );
            sequence.Append( DOTween.To(() => Target.localScale, s => Target.localScale = s, StartScale, 0.06667f).SetEase(Ease.InQuad) );
            sequence.OnComplete( () => {
                Target.localScale = StartScale;
            });
        }

        public void BloopUp() {
            if (sequence != null)
            {
                Target.localScale = StartScale;
                sequence.Kill();
            }

            sequence = DOTween.Sequence();
            sequence.Append( DOTween.To(() => Target.localScale, s => Target.localScale = s, StartScale * 0.87f, 0.2333f).SetEase(Ease.InQuad) );
            sequence.Append( DOTween.To(() => Target.localScale, s => Target.localScale = s, StartScale, 0.1777f).SetEase(Ease.OutQuad) );
            sequence.Append( DOTween.To(() => Target.localScale, s => Target.localScale = s, StartScale * 0.98f, 0.0666f).SetEase(Ease.InQuad) );
            sequence.Append( DOTween.To(() => Target.localScale, s => Target.localScale = s, StartScale, 0.06667f).SetEase(Ease.OutQuad) );
            sequence.OnComplete( () => {
                Target.localScale = StartScale;
            });
        }
    }
}
