﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using HutongGames.PlayMaker;
using System.Collections.Generic;
using UnityEngine.Events;
using LGG;

namespace BD {
    public class Draggable : LGG.LGBehaviour, IDragHandler, IEndDragHandler, IPointerDownHandler {
        public Transform target;
        public float Tolerance;
        public bool FollowTouch;
        public Vector3 followOffset;
        public MessageEnum OnDragMessage, OnBeginDragMessage, OnEndDragMessage;
        public DragEvent OnDragEvent, OnBeginDragEvent, OnEndDragEvent;


        private Vector3 startLocalPos;
        private Vector2 delta;
        private bool dragging;

        protected override void Awake()
        {
            base.Awake();

            if (target == null)
                target = GetComponent<Transform>();
        }

        //Object is still visibly dragged when below tolerance to activate the drag
		public void OnDrag(PointerEventData eventData) {

            if (FollowTouch)
                SetDraggedPosition(eventData);

            if(!dragging) {
                delta += eventData.delta;
                if(delta.magnitude > Tolerance) {
                    dragging = true;
                    OnBeginDrag(eventData);
                }
            } else {
                Messenger.Broadcast<Transform,PointerEventData>(OnDragMessage,target,eventData);
                OnDragEvent.Invoke(target,eventData);
            }
		}

		public void OnBeginDrag(PointerEventData eventData) {
            Messenger.Broadcast<Transform,PointerEventData>(OnBeginDragMessage,target,eventData);
            OnBeginDragEvent.Invoke(target,eventData);
		}

        public void OnPointerDown(PointerEventData eventData) {
            startLocalPos = target.localPosition;
        }

		public void OnEndDrag(PointerEventData eventData) {
            if(dragging) {
                Messenger.Broadcast<Transform,PointerEventData>(OnEndDragMessage,target,eventData);
                OnEndDragEvent.Invoke(target,eventData);
            }

            dragging = false;
            delta = Vector2.zero;

            //Reset pos next frame to not interfere with events
            if(gameObject.activeInHierarchy && FollowTouch)
                StartCoroutine(ResetPosition());
		}

		IEnumerator ResetPosition() {
			yield return null;
            //target.localPosition = startLocalPos;
		}

		private void SetDraggedPosition(PointerEventData eventData)
		{
            target.position = eventData.pressEventCamera.ScreenToWorldPoint(eventData.position) + followOffset;
		}

        private void OnEnable() {
            //target.localPosition = startLocalPos;
        }

        private void OnDisable() {
            //target.localPosition = startLocalPos;
        }
	}
}
