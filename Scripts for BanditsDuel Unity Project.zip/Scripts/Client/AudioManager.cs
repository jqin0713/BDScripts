﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using LGG;
using System.Linq;

namespace BD
{
    public class AudioManager : LGSingleton<AudioManager>
    {
        [SerializeField]
        private AudioClip[] clips;
        private Dictionary<AudioSource, Coroutine> audioSources;

        protected override void Init()
        {
            base.Init();

            audioSources = new Dictionary<AudioSource, Coroutine>();
        }

        public AudioSource PlaySound(string soundName)
        {
            AudioSource source = gameObject.AddComponent<AudioSource>();
            source.clip = clips.SingleOrDefault(c => c.name.Equals(soundName));
            audioSources.Add(source, StartCoroutine(PlaySoundRoutine(source)));
            return source;
        }

        public void StopSound(AudioSource source)
        {
            StopCoroutine(audioSources[source]);
            audioSources.Remove(source);
            Destroy(source);
        }

        private IEnumerator PlaySoundRoutine(AudioSource source)
        {
            source.Play();

            while (source.isPlaying)
            {
                yield return null;
            }

            audioSources.Remove(source);
            Destroy(source);
        }
    }
}