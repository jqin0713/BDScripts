﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.Networking;
using UnityEngine.Networking.NetworkSystem;
using UnityEngine.EventSystems;
using System.Linq;

namespace BD
{
    public class ClientNetworkManager : NetworkManager
    {
        public static NetworkClient GameClient;

        private NetworkClient connectionToMaster;
        private Coroutine connectToMasterRoutine;
        private Dictionary<int, float> pingRequests;
        private int pingRequestIndex = 0;

        IEnumerator Start()
        {
#if UNITY_STANDALONE || UNITY_STANDALONE_OSX
            Screen.SetResolution(800, 600, false);
            Application.targetFrameRate = 60;
#endif
            Messenger.AddListener<PointerEventData>(MessageEnum.ClientFindMatch, FindMatch);
            Messenger.AddListener<PointerEventData>(MessageEnum.ClientPlayOffline, PlayOffline);
            Messenger.AddListener<PointerEventData>(MessageEnum.ClientLeaveMatch, LeaveMatch);
            Messenger.AddListener<PointerEventData>(MessageEnum.ClientConnectToMaster, ConnectToMaster);
            Messenger.AddListener<PointerEventData>(MessageEnum.ClientDisconnectFromMaster, DisconnectFromMaster);

            connectionToMaster = new NetworkClient();
            connectionToMaster.RegisterHandler(MsgType.Connect, OnConnected);
            connectionToMaster.RegisterHandler(MsgType.Disconnect, OnDisconnected);
            connectionToMaster.RegisterHandler(1000, JoinMatch);

            yield return null;
        }

        public void CheckMasterConnection()
        {
            if (!connectionToMaster.isConnected)
            {
                ConnectToMaster(null);
            }
            else
            {
                Messenger.Broadcast<bool>(MessageEnum.ClientSetConnectedToMaster, true);
            }
        }

        private void DisconnectFromMaster(PointerEventData eventData)
        {
            Messenger.Broadcast<bool>(MessageEnum.ClientSetConnectedToMaster, false);
            connectionToMaster.Disconnect();
        }

        private void ConnectToMaster(PointerEventData eventData)
        {
            if (connectToMasterRoutine != null)
            {
                StopCoroutine(connectToMasterRoutine);
            }

            connectToMasterRoutine = StartCoroutine(ConnectToMasterRoutine());
        }

        private IEnumerator ConnectToMasterRoutine()
        {
            connectionToMaster.Connect(Configuration.MasterServerIp, Configuration.MasterServerPort);
            float startTime = Time.time;

            while (!connectionToMaster.isConnected && Time.time - startTime < 5.0f)
            {
                yield return null;
            }

            if (!connectionToMaster.isConnected)
            {
                Messenger.Broadcast<bool>(MessageEnum.ClientSetConnectedToMaster, false);
                connectionToMaster.Disconnect();  // [TODO]:  Is this the correct way to cancel a connection attempt before it times out?
            }
        }

        public void FindMatch(PointerEventData eventData)
        {
            GameManager.Instance.OnlineMatch = true;
            GameManager.Instance.IsClient = true;
            StartCoroutine(FindMatchRoutine());
        }

        public void PlayOffline(PointerEventData eventData)
        {
            GameManager.Instance.OnlineMatch = false;
            GameManager.Instance.IsClient = false;
            StartCoroutine(FindMatchRoutine());
        }

        private IEnumerator FindMatchRoutine()
        {
            AudioManager.Instance.PlaySound("sfx_duel_enter");
            GameManager.Instance.TeamList = new List<string>(GameObject.FindObjectOfType<TeamSelectWindow>().GetFinalTeamList());
            GameManager.Instance.SwitchScene("Duel");

            while (GameManager.Instance.LoadingScene && GameManager.Instance.DuelManager == null)
            {
                yield return null;
            }

            if (GameManager.Instance.OnlineMatch)
            {
                Hashtable data = new Hashtable();
                data["team_size"] = GameManager.Instance.TeamSize;
                string stringMessage = JSON.JsonEncode(data);
                var message = new StringMessage(stringMessage);
                connectionToMaster.Send(1000, message);
            }
            else
            {
                GameManager.Instance.DuelManager.gameObject.SetActive(true);
            }
        }

        private void JoinMatch(NetworkMessage netMsg)
        {
            pingRequests = new Dictionary<int, float>();
            pingRequestIndex = 0;

            var message = netMsg.ReadMessage<StringMessage>();
            string stringMessage = message.value;
            Hashtable data = JSON.JsonDecode(stringMessage) as Hashtable;

            networkPort = (int)data["port"];
            networkAddress = Configuration.MasterServerIp;
            StartClient();
        }

        private void LeaveMatch(PointerEventData eventData)
        {
            Debug.Log("Leave Match");
            StopClient();
            Messenger.Broadcast(MessageEnum.SetAlert, "Disconnected", "You have been disconnected from the Game Server.");
        }

        private void OnConnected(NetworkMessage netMsg)
        {
            Debug.Log("Connected to Master Server");
            Messenger.Broadcast<bool>(MessageEnum.ClientSetConnectedToMaster, true);
        }

        private void OnDisconnected(NetworkMessage netMsg)
        {
            Debug.Log("Disconnected from server");
            Messenger.Broadcast<bool>(MessageEnum.ClientSetConnectedToMaster, false);
        }

        public override void OnStartClient(NetworkClient client)
        {
            base.OnStartClient(client);
            Debug.Log("Start Game Client");
            GameClient = client;
            GameClient.RegisterHandler(4001, ClientPingResponse);
            StartClientPingRequestRoutine();
        }

        private Coroutine pingRequestRoutine;
        
        private void StartClientPingRequestRoutine()
        {
            if (pingRequestRoutine != null)
            {
                StopCoroutine(pingRequestRoutine);
            }

            pingRequestRoutine = StartCoroutine(ClientPingRequest());
        }

        private void StopClientPingRequestRoutine()
        {
            if (pingRequestRoutine != null)
            {
                StopCoroutine(pingRequestRoutine);
                pingRequestRoutine = null;
            }
        }

        public IEnumerator ClientPingRequest()
        {
            while (Player.Authoritative == null)
            {
                yield return null;
            }

            float lastSendTime;

            while (GameClient.connection.isConnected)
            {
                
                pingRequestIndex++;
                pingRequests.Add(pingRequestIndex, Time.time);
                lastSendTime = Time.time;

                Hashtable data = new Hashtable();
                data["index"] = pingRequestIndex;
                string message = JSON.JsonEncode(data);
                var msg = new StringMessage(message);

                GameClient.Send(4000, msg);

                while (Time.time - lastSendTime < 1f)
                {
                    if (pingRequests.Count > 0)
                    {
                        Player.Authoritative.Latency = (int)Mathf.Max(Player.Authoritative.Latency, (Time.time - pingRequests[pingRequests.Keys.Min()]) * 1000f);
                    }
                    
                    yield return null;
                }
            }

            pingRequestRoutine = null;
        }

        private void ClientPingResponse(NetworkMessage netMsg)
        {
            var message = netMsg.ReadMessage<StringMessage>();
            string stringMessage = message.value;
            Hashtable data = JSON.JsonDecode(stringMessage) as Hashtable;

            int pingResponseIndex = (int)data["index"];
            //Player.Authoritative.Latency = (int)((Time.time - pingRequests[pingResponseIndex]) * 1000f);
            pingRequests.Remove(pingResponseIndex);
        }

        public override void OnStopClient()
        {
            base.OnStopClient();
            Debug.Log("Stop Game Client");
            GameClient = null;
            StopClientPingRequestRoutine();
            Messenger.Broadcast(MessageEnum.SetAlert, "Disconnected", "You have been disconnected from the Game Server.");
        }

        public override void OnClientConnect(NetworkConnection conn)
        {
            base.OnClientConnect(conn);
            Debug.Log("Client Connect");
            ClientScene.AddPlayer(conn, 0);
            StartClientPingRequestRoutine();
        }

        public override void OnClientDisconnect(NetworkConnection conn)
        {
            base.OnClientDisconnect(conn);
            Debug.Log("Client Disconnect");
            StopClient();
        }

        public override void OnClientSceneChanged(NetworkConnection conn)
        {
            base.OnClientSceneChanged(conn);
            Debug.Log("Client Scene Changed");
        }

        public override void OnClientError(NetworkConnection conn, int errorCode)
        {
            base.OnClientError(conn, errorCode);
            Debug.LogErrorFormat("Client Error: {0}", errorCode);
        }
    }
}