﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using HutongGames.PlayMaker;
using System.Collections.Generic;
using UnityEngine.Events;
using LGG;

namespace BD {
    public class Hoverable : LGG.LGBehaviour, IPointerEnterHandler, IPointerExitHandler{
        public Transform target;
        public MessageEnum OnHoverEnterMessage, OnHoverExitMessage, OnHoverOverMessage;
        public HoverEvent OnHoverEnterEvent, OnHoverExitEvent, OnHoverOverEvent;

        private bool hoverOver = false;
        private EventSystem eventSystem;

        protected override void Awake()
        {
            base.Awake();

            if (target == null)
                target = GetComponent<Transform>();

            eventSystem = FindObjectOfType<EventSystem>();
        }

        public void OnPointerEnter(PointerEventData eventData) {
            Messenger.Broadcast<Transform,PointerEventData>(OnHoverEnterMessage,target,eventData);
            OnHoverEnterEvent.Invoke(target,eventData);
            hoverOver = true;

            StartCoroutine(OnHoverOver());
        }

        public void OnPointerExit(PointerEventData eventData) {
            Messenger.Broadcast<Transform,PointerEventData>(OnHoverExitMessage,target,eventData);
            OnHoverExitEvent.Invoke(target,eventData);
            hoverOver = false;
        }


        private IEnumerator OnHoverOver() {
            while (hoverOver == true)
            {
                PointerEventData eventData = new PointerEventData(eventSystem);
                eventData.position = Input.mousePosition;
                    
                Messenger.Broadcast<Transform,PointerEventData>(OnHoverOverMessage,target,eventData);
                OnHoverExitEvent.Invoke(target,eventData);
                yield return null;
            }
        }
	}
}
