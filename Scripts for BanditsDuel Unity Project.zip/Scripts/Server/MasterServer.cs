﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.Networking;
using UnityEngine.Networking.NetworkSystem;
using System.Diagnostics;
using System.IO;
using System.Linq;

namespace BD
{
    // [TODO]:  Ping the game servers at a set interval, remove crashed entries from the gameServers list
    // Could also fix by not adding servers to the list until SetConnectionId is hit, but clients who FindMatch simultaneously will be sent to unique GameServers
    public class MasterServer : MonoBehaviour
    {
        private List<ServerEntry> gameServers;
        private int currentPort;

        private class ServerEntry
        {
            // Server Settings
            public int Port;
            public int Connections;
            public int ConnectionId;

            // Game Settings
            public int TeamSize;
        }

        void Start()
        {
#if UNITY_STANDALONE || UNITY_STANDALONE_OSX
            Screen.SetResolution(853, 480, false);
            Application.targetFrameRate = 60;
#endif
            gameServers = new List<ServerEntry>();
            currentPort = Configuration.GameServerStartingPort;

            NetworkServer.RegisterHandler(MsgType.Connect, OnConnected);
            NetworkServer.RegisterHandler(MsgType.Disconnect, OnDisconnected);
            NetworkServer.RegisterHandler(1000, FindGameServer);
            NetworkServer.RegisterHandler(2000, UpdateGameServersList);
            NetworkServer.RegisterHandler(2001, SetConnectionID);

            NetworkServer.Listen( Configuration.MasterServerPort);
            UnityEngine.Debug.LogFormat("Listening on port {0}", Configuration.MasterServerPort);
        }

        private void OnConnected(NetworkMessage netMsg)
        {
            UnityEngine.Debug.Log("Client [" + netMsg.conn.address + "] connected to server with ID [" + netMsg.conn.connectionId + "]");
        }

        private void OnDisconnected(NetworkMessage netMsg)
        {
            UnityEngine.Debug.Log("Client [" + netMsg.conn.address + "] with ID [" + netMsg.conn.connectionId + "] disconnected from server");
            ServerEntry server = gameServers.SingleOrDefault(s => s.ConnectionId == netMsg.conn.connectionId);

            if (server != null)
            {
                gameServers.Remove(server);
            }
        }

        private void SetConnectionID(NetworkMessage netMsg)
        {
            var message = netMsg.ReadMessage<StringMessage>();
            string stringMessage = message.value;
            Hashtable data = JSON.JsonDecode(stringMessage) as Hashtable;
            ServerEntry server = gameServers.SingleOrDefault(s => s.Port == (int)data["port"]);

            if (server != null)
            {
                server.ConnectionId = netMsg.conn.connectionId;
            }
        }

        private void FindGameServer(NetworkMessage netMsg)
        {
            var message = netMsg.ReadMessage<StringMessage>();
            string stringMessage = message.value;
            Hashtable data = JSON.JsonDecode(stringMessage) as Hashtable;
            ServerEntry server = gameServers.SingleOrDefault(s => s.Connections == 1);

            // Join an existing Game Server
            if (server != null)
            {
                UnityEngine.Debug.LogFormat("Found Game Server, connecting ID {0} on port {1}", netMsg.conn.connectionId, server.Port);

                data["port"] = server.Port;
                data["team_size"] = server.TeamSize;
            }

            // Create a new Game Server
            else
            {
                data["port"] = currentPort;
                stringMessage = JSON.JsonEncode(data);
                stringMessage = stringMessage.Replace("\"", "\\\"");  // Have to do this because of stupid reasons (over-excited parsing on the Game Server)

#if UNITY_STANDALONE_LINUX
                Process.Start(Configuration.GameServerBinaryPath, stringMessage);
#else
                string path = Application.dataPath;

                if (Application.platform == RuntimePlatform.OSXPlayer)
                {
                    path += "/../../GameServer.app/Contents/MacOS/GameServer";

                }
                else if (Application.platform == RuntimePlatform.WindowsPlayer)
                {
                    path += "/../GameServer.exe";
                }

                path = Path.GetFullPath(path);
                UnityEngine.Debug.Log("Creating new Game Server");

                if (File.Exists(path))
                {
                    Process.Start(path, stringMessage);
                }
                else
                {
                    UnityEngine.Debug.LogError("GameServer binary not found at " + path);
                }
#endif

                ServerEntry entry = new ServerEntry();
                entry.Port = currentPort;
                entry.Connections = 1;  
                entry.TeamSize = (int)data["team_size"];
                gameServers.Add(entry);

                currentPort++;
            }

            stringMessage = JSON.JsonEncode(data);
            message = new StringMessage(stringMessage);
            NetworkServer.SendToClient(netMsg.conn.connectionId, 1000, message);
        }

        private void UpdateGameServersList(NetworkMessage netMsg)
        {
            var message = netMsg.ReadMessage<StringMessage>();
            string stringMessage = message.value;
            Hashtable data = JSON.JsonDecode(stringMessage) as Hashtable;

            ServerEntry server = gameServers.SingleOrDefault(s => s.ConnectionId == netMsg.conn.connectionId);

            if (server != null)
            {
                server.Connections = (int)data["connections"];
            }
        }
    }
}