﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.Networking;
using UnityEngine.Networking.NetworkSystem;
using System;
using System.Linq;

namespace BD
{
    public class GameServer : NetworkManager
    {
        private const int PLAYERS_TO_START = 2;

        public Player[] Players = new Player[2];
        public NetworkConnection[] Conns = new NetworkConnection[2];
        protected int connections;
        private NetworkClient connectionToMaster;
        private Coroutine updateRoutine;

        

        protected virtual IEnumerator Start () {
#if UNITY_STANDALONE || UNITY_STANDALONE_OSX
            Screen.SetResolution(853, 480, false);
            Application.targetFrameRate = 60;
#endif
            while (DatabaseManager.AnyLoading())
            {
                yield return null;
            }

            AsyncOperation op = UnityEngine.SceneManagement.SceneManager.LoadSceneAsync("Duel", UnityEngine.SceneManagement.LoadSceneMode.Additive);

            connectionToMaster = new NetworkClient();
            connections = 0;

            string stringMessage = Environment.CommandLine;
            stringMessage = stringMessage.Substring(stringMessage.IndexOf("{"));  // weird but can't get the F'n command line argument without the entire file path appended
            Hashtable data = JSON.JsonDecode(stringMessage) as Hashtable;

            networkAddress = Configuration.MasterServerIp;
            networkPort = (int)data["port"];

            while (!op.isDone)
            {
                yield return null;
            }

            yield return null;

            connectionToMaster.RegisterHandler(MsgType.Connect, OnConnectedToMaster);
            connectionToMaster.RegisterHandler(MsgType.Disconnect, OnDisconnectedFromMaster);
            connectionToMaster.Connect(Configuration.MasterServerIp, Configuration.MasterServerPort);

            NetworkServer.RegisterHandler(4000, ServerPingResponse);

            StartServer();
        }

        private void ServerPingResponse(NetworkMessage netMsg)
        {
            NetworkServer.SendToClient(netMsg.conn.connectionId, 4001, new StringMessage(netMsg.ReadMessage<StringMessage>().value));
        }

        private void OnConnectedToMaster(NetworkMessage netMsg)
        {
            Debug.Log("Connected to Master Server");

            Hashtable data = new Hashtable();
            data["port"] = networkPort;
            string message = JSON.JsonEncode(data);
            var msg = new StringMessage(message);
            connectionToMaster.Send(2001, msg);
        }

        private void OnDisconnectedFromMaster(NetworkMessage netMsg)
        {
            Debug.Log("Disconnected from Master Server");
        }

        private void UpdateMasterServer()
        {
            if (updateRoutine != null)
            {
                StopCoroutine(updateRoutine);
            }

            updateRoutine = StartCoroutine(UpdateMasterServerRoutine());
        }

        private IEnumerator UpdateMasterServerRoutine()
        {
            while (!connectionToMaster.isConnected)
            {
                yield return null;
            }

            Hashtable data = new Hashtable();
            data["connections"] = connections;
            string message = JSON.JsonEncode(data);
            var msg = new StringMessage(message);
            connectionToMaster.Send(2000, msg);
        }

        public override void OnStartServer()
        {
            base.OnStartServer();
            Debug.Log("Game Server Started");
            GameManager.Instance.OnlineMatch = true;
            GameManager.Instance.IsServer = true;
        }

        public override void OnStopServer()
        {
            base.OnStopServer();
            Debug.Log("Game Server Stopped");
            Application.Quit();
        }

        public override void OnServerConnect(NetworkConnection conn)
        {
            base.OnServerConnect(conn);
            Debug.Log("Client [" + conn.address + "] connected to server with ID [" + conn.connectionId + "]");
            connections++;
            UpdateMasterServer();
        }

        public override void OnServerDisconnect(NetworkConnection conn)
        {
            base.OnServerDisconnect(conn);
            Debug.Log("Client [" + conn.address + "] with ID [" + conn.connectionId + "] disconnected from server");
            connections--;
            StopServer();
        }

        public override void OnServerAddPlayer(NetworkConnection conn, short playerControllerId)
        {
            Player player = Instantiate<Player>(spawnPrefabs[0].GetComponent<Player>());
            NetworkServer.AddPlayerForConnection(conn, player.gameObject, playerControllerId);
            Players[numPlayers - 1] = player;
            Conns[numPlayers - 1] = conn;
            Debug.LogFormat("Player {0} added to scene for Client ID [{1}]", numPlayers, conn.connectionId);

            if (numPlayers == PLAYERS_TO_START)
            {
                StartCoroutine(StartGame());
            }
        }

        protected virtual IEnumerator StartGame() {
            bool ready = false;
            Debug.Log("Starting Game");

            while (!ready)
            {
                ready = true;

                foreach (NetworkConnection c in NetworkServer.connections.Where(con => con != null))
                {
                    if (!c.isReady)
                    {
                        ready = false;
                        break;
                    }
                }

                yield return null;
            }

            NetworkServer.SpawnObjects();

            yield return null;

            //GameManager.Instance.DuelManager.InitializeDuel();
            //GameManager.Instance.DuelManager.RpcInitializeDuel();

            //while (GameManager.Instance.DuelManager.Initializing)
            {
                yield return null;
            }
;
            //PlayerNPC.SetPlayerId(0);
            Players[0].SetPlayerId(1);
            Players[1].SetPlayerId(2);

            //PlayerNPC.RpcSetPlayerID(0);
            Players[0].RpcSetPlayerID(1);
            GameManager.Instance.DuelManager.Player1 = Players[0];
            Players[1].RpcSetPlayerID(2);
            GameManager.Instance.DuelManager.Player2 = Players[1];

            yield return null;

            GameManager.Instance.DuelManager.StartDuel();
        }

        private void OnApplicationQuit()
        {
            connections = 0;
            UpdateMasterServer();
            StopServer();
        }
    }
}