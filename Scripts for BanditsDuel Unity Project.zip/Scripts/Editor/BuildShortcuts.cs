using UnityEditor;
using UnityEditor.Callbacks;
using System.IO;
using UnityEditor.SceneManagement;

#if UNITY_EDITOR
namespace BD {
    public class BuildShortcuts : Editor
    {
        #if UNITY_EDITOR_OSX
        const BuildTarget TARGET = BuildTarget.StandaloneOSXIntel64;
        const string EXT = ".app";
        const string PLATFORM = "MacOS";
        #else
        const string EXT = ".exe";
        const BuildTarget TARGET = BuildTarget.StandaloneWindows64;
        const string PLATFORM = "Windows";
        #endif

        [MenuItem("Build/Linux/All")]
        public static void BuildAllLinux() {
            BuildLinuxMasterServer();
            BuildLinuxGameServer();
        }

        [MenuItem("Build/" + PLATFORM + "/All %#a")]
        public static void BuildAllLocal()
        {
            EditorSceneManager.OpenScene("Assets/_BD/Scenes/Boot.unity", OpenSceneMode.Single);
            BuildLocalMasterServer();
            BuildLocalGameServer();
            BuildLocalClient();
        }

        [MenuItem("Build/" + PLATFORM + "/Servers")]
        public static void BuildServersLocal()
        {
            BuildLocalMasterServer();
            BuildLocalGameServer();
        }

        [MenuItem("Build/" + PLATFORM + "/Duels %#d")]
        public static void BuildDuelsLocal()
        {
            EditorSceneManager.OpenScene("Assets/_BD/Scenes/Boot.unity", OpenSceneMode.Single);
            BuildLocalGameServer();
            BuildLocalClient();
        }

        public static void BuildMasterServer(string ext, BuildTarget target, string platform)
        {
            UnityEngine.Debug.Log("Building Master Server");
            PlayerSettings.productName = "Master Server";
            var levels = new string[] { "Assets/_BD/Scenes/MasterServer.unity" };
            BuildPipeline.BuildPlayer(levels, "../Builds/" + platform + "/MasterServer" + ext, target, target == BuildTarget.StandaloneLinux64 ? BuildOptions.None : BuildOptions.Development | BuildOptions.AutoRunPlayer);
        }

        public static void BuildGameServer(string ext, BuildTarget target, string platform)
        {
            UnityEngine.Debug.Log("Building Game Server");

            PlayerSettings.productName = "Game Server";
            var levels = new string[] { 
                "Assets/_BD/Scenes/GameServer.unity",
                "Assets/_BD/Scenes/Duel.unity"
            };
            BuildPipeline.BuildPlayer(levels, "../Builds/" + platform + "/GameServer" + ext, target, target == BuildTarget.StandaloneLinux64 ? BuildOptions.None : BuildOptions.Development);
        }

        [MenuItem("Build/" + PLATFORM + "/Master Server")]
        public static void BuildLocalMasterServer()
        {
            BuildMasterServer(EXT, TARGET, PLATFORM);
        }

        [MenuItem("Build/" + PLATFORM + "/Game Server %#g")]
        public static void BuildLocalGameServer()
        {
            BuildGameServer(EXT, TARGET, PLATFORM);
        }

        [MenuItem("Build/" + PLATFORM + "/Client %#c")]
        public static void BuildLocalClient()
        {
            UnityEngine.Debug.Log("Building Client");

            PlayerSettings.productName = "Bandits Duel";
            var levels = new string[] { 
                "Assets/_BD/Scenes/Boot.unity",
                "Assets/_BD/Scenes/Main.unity",
                "Assets/_BD/Scenes/Duel.unity"
            };
            BuildPipeline.BuildPlayer(levels, "../Builds/" + PLATFORM + "/Client" + EXT, TARGET, BuildOptions.Development | BuildOptions.AutoRunPlayer);
        }

        [MenuItem("Build/Linux/Master Server")]
        public static void BuildLinuxMasterServer()
        {
            EditorUserBuildSettings.enableHeadlessMode = true;
            BuildMasterServer(".x86_64", BuildTarget.StandaloneLinux64, "Linux");
        }

        [MenuItem("Build/Linux/Game Server")]
        public static void BuildLinuxGameServer()
        {
            EditorUserBuildSettings.enableHeadlessMode = true;
            BuildGameServer(".x86_64", BuildTarget.StandaloneLinux64, "Linux");
        }

        [PostProcessBuildAttribute(1)]
        public static void OnPostprocessBuild(BuildTarget target, string pathToBuiltProject) {
            UnityEngine.Debug.Log("Built to " + pathToBuiltProject);

            if(pathToBuiltProject == "../Builds/" + PLATFORM + "/Client" + EXT) {
                if (EditorApplication.isCompiling)
                    EditorApplication.delayCall += StartFromBoot;
                else
                    StartFromBoot();
            }
        }

        private static void StartFromBoot() {
            UnityEngine.Debug.Log("Playing from Boot");
            EditorApplication.isPlaying = true;
        }
    }
}
#endif
