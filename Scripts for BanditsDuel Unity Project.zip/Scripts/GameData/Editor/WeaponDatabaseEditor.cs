﻿using UnityEngine;
using System.Collections;
using UnityEditor;
using System.Linq;
using Spine.Unity;
using UnityEngine.UI;

namespace BD
{
    [CustomEditor(typeof(WeaponDatabase))]
    public class WeaponDatabaseEditor : DatabaseEditor<WeaponData>
    {
        private Spine.Unity.SkeletonDataAsset actionButtonSkeleton;

        protected override void OnEnable()
        {
            base.OnEnable();
            database.Initialize();
        }

        protected override void DrawEntry()
        {
            base.DrawEntry();

            actionButtonSkeleton = EditorGUILayout.ObjectField("Front Animation", actionButtonSkeleton, typeof(SkeletonDataAsset), false) as SkeletonDataAsset;
        }

        protected override void LoadCurrent()
        {
            actionButtonSkeleton = currentEntry.ActionButtonSkeleton;
        }

        protected override void Set()
        {
            currentEntry.Set(actionButtonSkeleton);
        }

        protected override void DrawDownloadedValues()
        {
            base.DrawDownloadedValues();

            EditorGUILayout.LabelField("Range", currentEntry.Range.ToString());

            for (int i = 0; i < currentEntry.TargetTypes.Count; i++)
            {
                EditorGUILayout.LabelField("Target Type", currentEntry.TargetTypes[i].ToString());
            }

            if (currentEntry.Params == null || currentEntry.Params.Count == 0) return;

            foreach (DuelManager.ParamTypes pt in currentEntry.Params.Keys)
            {
                string paramString = string.Empty;
                paramString += pt.ToString() + ":  " + currentEntry.Params[pt].ToString();
                EditorGUILayout.LabelField("Param", paramString);
            }
        }
    }
}
