﻿using UnityEngine;
using System.Collections;
using UnityEditor;
using System.Linq;
using Spine.Unity;

namespace BD
{
    [CustomEditor(typeof(HeroDatabase))]
    public class HeroDatabaseEditor : DatabaseEditor<HeroData>
    {
        private int skinIndex;
        private Spine.Unity.SkeletonDataAsset frontSkeleton, backSkeleton;
        private string skin;

        protected override void DrawEntry()
        {
            base.DrawEntry();

            frontSkeleton = EditorGUILayout.ObjectField("Front Animation", frontSkeleton, typeof(SkeletonDataAsset),false) as SkeletonDataAsset;
			backSkeleton = EditorGUILayout.ObjectField("Back Animation", backSkeleton, typeof(SkeletonDataAsset),false) as SkeletonDataAsset;

			if (frontSkeleton != null)
            {
				string[] skins = (from Spine.Skin s in frontSkeleton.GetSkeletonData(true).Skins select s.Name).ToArray();

                if(currentEntry != lastEntry && currentEntry != null)
                {
                    skinIndex = skins.ToList().FindIndex(s => s == skin);
                }

                skinIndex = EditorGUILayout.Popup("Skin", skinIndex, skins);
                skin = skins[skinIndex];
            }
        }

        protected override void LoadCurrent()
        {
            frontSkeleton = currentEntry.FrontSkeleton;
            backSkeleton = currentEntry.BackSkeleton;
            skin = currentEntry.Skin;
        }

        protected override void Set()
        {
            currentEntry.Set(frontSkeleton, backSkeleton, skin);
        }

        protected override void DrawDownloadedValues()
        {
            base.DrawDownloadedValues();

            EditorGUILayout.LabelField("HP", currentEntry.HP.ToString());
            EditorGUILayout.LabelField("Speed", currentEntry.Speed.ToString());
            DatabaseGUILayout.DataButton<WeaponDatabase,WeaponData>("Weapon", currentEntry.Weapon);
        }
    }
}
