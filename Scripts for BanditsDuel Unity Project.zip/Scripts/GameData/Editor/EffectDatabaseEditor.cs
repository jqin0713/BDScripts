﻿using UnityEngine;
using System.Collections;
using UnityEditor;
using System.Linq;
using Spine.Unity;
using UnityEngine.UI;

namespace BD
{
	[CustomEditor(typeof(EffectDatabase))]
	public class EffectDatabaseEditor : DatabaseEditor<EffectData>
	{
		protected override void OnEnable()
		{
			base.OnEnable();
			database.Initialize();
		}

		protected override void DrawEntry()
		{
			base.DrawEntry();
		}

		protected override void LoadCurrent()
		{

		}

		protected override void Set()
		{
		}

		protected override void DrawDownloadedValues()
		{
			base.DrawDownloadedValues();
			EditorGUILayout.LabelField("Type Of Effect", currentEntry.TypeOfEffect);
			EditorGUILayout.LabelField("Effect Duration Type", currentEntry.EffectDurationType.ToString());
			EditorGUILayout.LabelField("Effect Duration", currentEntry.EffectDuration.ToString());
			EditorGUILayout.LabelField("Stack Limit", currentEntry.StackLimit.ToString());

			string effectAmountsAsString = null;
			if (currentEntry.EffectAmounts != null)
			{
				for (int i = 0; i < currentEntry.EffectAmounts.Length; i++)
				{
					if (i == currentEntry.EffectAmounts.Length - 1)
					{
						effectAmountsAsString += currentEntry.EffectAmounts[i];
					}
					else
					{
						effectAmountsAsString += currentEntry.EffectAmounts[i] + ", ";
					}
				}
			}
			EditorGUILayout.LabelField("Effect Amounts", effectAmountsAsString == null ? "Not Applicable" : effectAmountsAsString);
			EditorGUILayout.LabelField("Effect Frequency", currentEntry.EffectFrequency.ToString());
		}
	}
}
