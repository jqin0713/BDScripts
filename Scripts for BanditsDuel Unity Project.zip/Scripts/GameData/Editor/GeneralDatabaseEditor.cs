﻿using UnityEngine;
using System.Collections;
using UnityEditor;
using System.Linq;
using Spine.Unity;
using UnityEngine.UI;

namespace BD
{
    [CustomEditor(typeof(GeneralDatabase))]
    public class GeneralDatabaseEditor : DatabaseEditor<GeneralData>
    {
        protected override void OnEnable()
        {
            base.OnEnable();
            database.Initialize();
        }

        protected override void DrawEntry()
        {
            base.DrawEntry();
        }

        protected override void LoadCurrent()
        {

        }

        protected override void Set()
        {

        }

        protected override void DrawDownloadedValues()
        {
            base.DrawDownloadedValues();

            switch (currentEntry.ValueType)
            {
                case "int":
                    EditorGUILayout.LabelField("Value", currentEntry.IntValue.ToString());
                    break;
                case "float":
                    EditorGUILayout.LabelField("Value", currentEntry.FloatValue.ToString());
                    break;
                case "string":
                    EditorGUILayout.LabelField("Value", currentEntry.StringValue.ToString());
                    break;
            }
        }
    }
}
