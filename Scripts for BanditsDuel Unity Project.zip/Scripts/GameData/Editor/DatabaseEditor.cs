﻿using UnityEngine;
using System.Collections;
using UnityEditor;
using System;
using System.Collections.Generic;
using System.Linq;

namespace BD {
    [CustomEditor(typeof(Database<Data>))]
    public class DatabaseEditor<T> : Editor where T : Data {
        public static GameObject prevTarget;
        enum Sort { Index, Alphabetical };

        private static Sort keySort;
        private static bool showInfo, showOptions, showDev;
        private static int currentIndex = 1;

        protected Database<T> database;
        private string[] keys;

        protected T currentEntry;
		protected T lastEntry;
        protected string currentKey;
        protected string duplicateKey;
        protected Color bodyColour;

        protected virtual void OnEnable() {
            bodyColour = new Color(0.7f, 0.7f, 0.7f, 1);
            database = (Database<T>)target;
            database.transform.hideFlags |= HideFlags.HideInInspector;
            database.Initialize();

            RefreshKeys();

            if (!string.IsNullOrEmpty(database.goToEntry))
            {
                currentIndex = keys.ToList().FindIndex(e => e == database.goToEntry);
                database.goToEntry = null;
            } else {
                currentIndex = Mathf.Clamp(currentIndex, 0, database.Count);
                prevTarget = null;
            }

            if(!database.SheetLoaded)
                database.LoadSheet( () => {
                    RefreshKeys();
                    Repaint();
                });
        }

        private void RefreshKeys() {
            List<string> arr = new List<string>();
            arr.Add("[New Entry]");
            if(keySort == Sort.Alphabetical)
                arr.AddRange(database.Keys.OrderBy(k => k));
            else
                arr.AddRange(database.Keys.OrderBy(k => database.FindIndex(k)));
            
            this.keys = arr.ToArray();
        }

        public override void OnInspectorGUI()
        {
            if (Event.current != null && Event.current.type == EventType.KeyUp)
            {
                OnKeyUp(Event.current);
                return;
            }

            EditorGUI.BeginDisabledGroup(Application.isPlaying);
            EditorGUI.indentLevel = 0;

            DrawDev();
            DrawHeader();

            EditorGUILayout.Separator();

            if (currentIndex == 0) {
                DrawNewEntry();
            } else {
                if (currentIndex < 0)
                    currentIndex = keys.Length - 1;
                else if (currentIndex >= keys.Length)
                    currentIndex = 1;
                
                DrawBody();
            }

            EditorGUI.EndDisabledGroup();
            DrawFooter();

            if (EditorGUI.EndChangeCheck())
            {
                EditorUtility.SetDirty(database);
                serializedObject.ApplyModifiedProperties();
            }

           
        }

        protected virtual void DrawEntry() {
            if (currentEntry != lastEntry && currentEntry != null)
                LoadCurrent();

            if (currentEntry != null)
            {
                GUIStyle style = new GUIStyle();
                style.normal.textColor = Color.white;
                style.fontStyle = FontStyle.Bold;
                style.fontSize = 16;

                EditorGUILayout.BeginHorizontal();
                EditorGUI.DropShadowLabel(EditorGUILayout.GetControlRect(), currentEntry.Key,style);
                EditorGUILayout.LabelField(string.Format("Index {0}",currentEntry.Index));
                EditorGUILayout.EndHorizontal();
                EditorGUILayout.Space();
            }

            EditorGUI.indentLevel++;

        }

        protected virtual void DrawHeader() {
            EditorGUI.BeginChangeCheck();

            EditorGUILayout.BeginHorizontal();

            EditorGUILayout.LabelField("Entries",GUILayout.Width(50));
            currentIndex = EditorGUILayout.Popup(currentIndex, keys,GUILayout.Width(100));
            Sort oldSort = keySort;
            EditorGUILayout.LabelField("Sort by",GUILayout.Width(50));
            keySort = (Sort)EditorGUILayout.EnumPopup(keySort,GUILayout.Width(80));
            if (oldSort != keySort)
                RefreshKeys();
            if (GUILayout.Button("Refresh",EditorStyles.miniButton))
            {
                database.LoadSheet( () => {
                    RefreshKeys();
                    Repaint();
                });
            }
                
            EditorGUILayout.EndHorizontal();
        }

        protected virtual void DrawNewEntry() {
            currentIndex = 0;
            Rect bodyRect = EditorGUILayout.BeginVertical();
            EditorGUILayout.Space();

            EditorGUILayout.BeginHorizontal();
            DatabaseGUILayout.DrawRectBorder(bodyRect,bodyColour, 1f, Color.black);

            currentKey = EditorGUILayout.TextField("Key", currentKey);

            if (GUILayout.Button("Add Entry"))
            {
                database.CreateEntry(currentKey);
                RefreshKeys();
                currentIndex = keys.Count() - 1;
            }
            EditorGUILayout.EndHorizontal();

            EditorGUILayout.Space();
            EditorGUILayout.EndVertical();
        }

        protected virtual void DrawBody() {
            currentKey = keys[currentIndex];
            lastEntry = currentEntry;
            currentEntry = database.Get(currentKey);

            Rect bodyRect = EditorGUILayout.BeginVertical();
            EditorGUILayout.Space();
            DatabaseGUILayout.DrawRectBorder(bodyRect, bodyColour, 1f, Color.black);

            DrawEntry();
            if(database.SheetLoaded)
                DrawDownloadedValues();
            Set();

            DrawOptions();

            EditorGUILayout.Space();
            EditorGUILayout.EndVertical();
        }

        protected virtual void DrawOptions() {
            Rect opRect = EditorGUILayout.BeginVertical();
            DatabaseGUILayout.DrawRectBorder(opRect, Color.gray,1, Color.black);

            GUIStyle style = new GUIStyle(EditorStyles.foldout);
            style.fontStyle = FontStyle.Bold;
            style.normal.textColor = Color.white;

            showOptions = EditorGUILayout.Foldout(showOptions, "Options", style);
            if (showOptions)
            {
                EditorGUI.indentLevel++;
                EditorGUILayout.BeginHorizontal();
                if (GUILayout.Button("Copy to"))
                {
                    database.DuplicateEntry(currentEntry,duplicateKey);
                    RefreshKeys();
                    currentIndex = keys.Count() - 1;
                }

                duplicateKey = EditorGUILayout.TextField(duplicateKey);
                EditorGUILayout.Space();

                EditorGUILayout.EndHorizontal();
                if (GUILayout.Button("Delete Entry"))
                {
                    database.Remove(currentKey);
                    database.RefreshIndicies();
                    RefreshKeys();
                }
                EditorGUI.indentLevel--;
                EditorGUILayout.Space();

            }
            EditorGUILayout.EndVertical();
        }

        protected virtual void DrawDev() {
            EditorGUI.indentLevel++;
            Rect opRect = EditorGUILayout.BeginVertical();
            DatabaseGUILayout.DrawRectBorder(opRect, new Color32(255,190,190,255),1, Color.red);

            GUIStyle style = new GUIStyle(EditorStyles.foldout);
            style.fontStyle = FontStyle.Bold;
            //style.normal.textColor = Color.white;

            showDev = EditorGUILayout.Foldout(showDev, "Dev Only", style);
            if (showDev)
            {
                EditorGUI.indentLevel++;
                database.filename = EditorGUILayout.TextField("Filename",  database.filename);
                database.spreadsheetID = EditorGUILayout.TextField("Spreadsheet ID",  database.spreadsheetID);
                database.gid = EditorGUILayout.TextField("GID",  database.gid);
                EditorGUI.indentLevel--;
                EditorGUILayout.Space();

            }
            EditorGUILayout.EndVertical();
            EditorGUI.indentLevel--;
        }


        protected virtual void DrawFooter() {
            if (database.Count > 0)
            {

                EditorGUILayout.BeginHorizontal();
                if (GUILayout.Button("<< Prev"))
                    Prev();
                
                if (GUILayout.Button("Next >>"))
                    Next();
                
                EditorGUILayout.EndHorizontal();

                if (prevTarget != null)
                {
                    GUIStyle style = new GUIStyle(GUI.skin.button);
                    style.normal.textColor = Color.blue;
                    if (GUILayout.Button("Back to " + prevTarget.name,style))
                        Selection.activeGameObject = prevTarget;
                }
            }
            if (GUILayout.Button("Open Data Table"))
            {
                Application.OpenURL(string.Format("https://docs.google.com/spreadsheets/d/{0}/edit#gid={1}",database.spreadsheetID,database.gid));
            }
            EditorGUILayout.HelpBox("Hotkeys:\n> Next\n< Prev\nAlt+N New Entry",MessageType.Info);
        }

        protected virtual void DrawDownloadedValues() {
        }

        protected virtual void LoadCurrent() {
            
        }

        protected virtual void Set() {
            
        }

        private void OnKeyUp(Event e) {
            if (e.keyCode == KeyCode.Period)
                Next();
            else if (e.keyCode == KeyCode.Comma)
                Prev();
            else if (e.keyCode == KeyCode.N && e.alt)
                GoToNewEntry();

            Repaint();
        }

        private void GoToNewEntry() {
            currentIndex = 0;
        }
       
        private void Next() {
            currentIndex++;
        }

        private void Prev() {
            currentIndex--;
            if(currentIndex == 0)
                currentIndex = keys.Length - 1;
        }
    }

    public static class DatabaseGUILayout {
        public static void DrawRectBorder(Rect r, Color c, float thickness, Color borderColor) {
            Rect b = new Rect(r);
            r.width -= thickness * 2f;
            r.height -= thickness * 2f;
            r.x += thickness;
            r.y += thickness;

            EditorGUI.DrawRect(b, borderColor);
            EditorGUI.DrawRect(r, c);

        }

        public static Sprite SpriteField(string label,Sprite sprite) {
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField(label);
            Rect r = EditorGUILayout.BeginVertical();

            if(sprite != null)
                GUILayout.Box(sprite.texture,EditorStyles.label,GUILayout.Height(100),GUILayout.Width(100));
            else
                GUILayout.Box("No sprite",EditorStyles.helpBox,GUILayout.Height(100),GUILayout.Width(100));
            
            sprite = EditorGUILayout.ObjectField(sprite, typeof(Sprite), false) as Sprite;
            EditorGUILayout.EndVertical();
            EditorGUILayout.EndHorizontal();

            return sprite;
        }
            
        public static void GoToDatabaseEntry<T,U>(string key) where T : Database<U> where U : Data{
            T database = GameObject.FindObjectOfType<T>();
            database.goToEntry = key;

            DatabaseEditor<U>.prevTarget = Selection.activeGameObject;
            Selection.activeGameObject = database.gameObject;
        }

        public static void DataButton<T,U>(string label, string key) where T : Database<U> where U : Data{
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField(label,GUILayout.ExpandWidth(false));
            if (GUILayout.Button(key))
            {
                GoToDatabaseEntry<T,U>(key);
            }

            EditorGUILayout.EndHorizontal();
        }


    }
}
