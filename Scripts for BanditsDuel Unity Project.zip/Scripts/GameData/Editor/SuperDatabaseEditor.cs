﻿using UnityEngine;
using System.Collections;
using UnityEditor;
using System.Linq;
using Spine.Unity;
using UnityEngine.UI;

namespace BD
{
	[CustomEditor(typeof(SuperDatabase))]
	public class SuperDatabaseEditor : DatabaseEditor<SuperData>
	{
		protected override void OnEnable()
		{
			base.OnEnable();
			database.Initialize();
		}

		protected override void DrawEntry()
		{
			base.DrawEntry();
		}

		protected override void LoadCurrent()
		{

		}

		protected override void Set()
		{

		}

		protected override void DrawDownloadedValues()
		{
			base.DrawDownloadedValues();

			EditorGUILayout.LabelField ("Weapon", currentEntry.Weapon == null ? "AE Generated Super" : currentEntry.Weapon);
			EditorGUILayout.LabelField ("MP Cost", currentEntry.Weapon == null ? "Not Applicable" : currentEntry.MPCost.ToString ());
			EditorGUILayout.LabelField ("Cooldown Type", currentEntry.Cooldown == 0f ? "Not Applicable" : currentEntry.CooldownType.ToString ());
			EditorGUILayout.LabelField ("Cooldown", currentEntry.Cooldown == 0f ? "Not Applicable" : currentEntry.Cooldown.ToString ());
			EditorGUILayout.LabelField ("Type Of Super", currentEntry.TypeOfSuper);
			EditorGUILayout.LabelField ("Duration Type", currentEntry.DurationType.ToString ());
			EditorGUILayout.LabelField ("Duration", currentEntry.Duration == 0f ? "Non-constant duration or Instant" : currentEntry.Duration.ToString ());
			EditorGUILayout.LabelField ("Field Type", currentEntry.TypeOfSuper == "Field Effect" ? currentEntry.Field.ToString () : "Not Applicable");
			EditorGUILayout.LabelField ("Effect Type", currentEntry.EffectType.ToString ());

			EditorGUILayout.LabelField("Effects", currentEntry.Effects == null ? "No Effects" : string.Join(", ", currentEntry.Effects));
			EditorGUILayout.LabelField("Effect Specifications", currentEntry.EffectSpecifications == null ? "No Effects to specify" : string.Join("; ", currentEntry.EffectSpecifications));
			/*string[] effects;
			if (currentEntry.Debuffs == null && currentEntry.Buffs == null) {
				effects = null;
			} else if (currentEntry.Debuffs == null) {
				effects = currentEntry.Buffs;
			} else if (currentEntry.Buffs == null) {
				effects = currentEntry.Debuffs;
			} else {
				effects = currentEntry.Buffs.Concat (currentEntry.Debuffs).ToArray ();
			}
			if (effects == null) {
				EditorGUILayout.LabelField ("Effects", "No effects");
			} else {
				EditorGUILayout.LabelField ("Effects", string.Join (", ", effects));
			}

			string[] effectSpecifications;
			if (currentEntry.DebuffSpecifications == null && currentEntry.BuffSpecifications == null) {
				effectSpecifications = null;
			} else if (currentEntry.DebuffSpecifications == null) {
				effectSpecifications = currentEntry.BuffSpecifications;
			} else if (currentEntry.BuffSpecifications == null) {
				effectSpecifications = currentEntry.DebuffSpecifications;
			} else {
				effectSpecifications = currentEntry.BuffSpecifications.Concat (currentEntry.DebuffSpecifications).ToArray ();
			}
			if (effectSpecifications == null) {
				EditorGUILayout.LabelField ("Effect Specifications", "No effect specifications");
			} else {
				EditorGUILayout.LabelField("Effect Specifications", string.Join(", ", effectSpecifications));
			}*/
			
			EditorGUILayout.LabelField ("Solo Enhancement Only", (currentEntry.TypeOfSuper == "Attack Enhancer") ? currentEntry.SoloEnhancementOnly.ToString() : "Not Applicable");

			EditorGUILayout.LabelField ("Enhancement Specifications", (currentEntry.TypeOfSuper == "Attack Enhancer") ? (currentEntry.EnhancementSpecifications == null ? "No enhancement specifications" : string.Join(", " ,currentEntry.EnhancementSpecifications)) : "Not applicable");

			EditorGUILayout.LabelField ("Field Effect Specifications", currentEntry.FieldEffectSpecifications == null ? "Either no specifications provided or not applicable to this particular Super" : currentEntry.FieldEffectSpecifications.Length.ToString());

			EditorGUILayout.LabelField ("Priority", currentEntry.TypeOfSuper == "Attack Enhancer" ? currentEntry.AEPriority.ToString() : "Not applicable");



		}
	}
}

