﻿using UnityEngine;
using System.Collections;
using LGG;
using Spine.Unity;
using System.Collections.Generic;

namespace BD
{
    [System.Serializable]
    public class HeroData : Data
    {
        //Set in editor and saved in a prefab
        [SerializeField] private SkeletonDataAsset frontSkeleton;
        [SerializeField] private SkeletonDataAsset backSkeleton;
        [SerializeField] private string skin;

        //Getters for vars set in editor
        public SkeletonDataAsset FrontSkeleton { get { return frontSkeleton; } }
        public SkeletonDataAsset BackSkeleton { get { return backSkeleton; } }
        public string Skin { get { return skin; } }

        //Set in google spreadsheets and parsed
        public int HP { get; private set; }
		public float Speed { get; private set; }
        public string Weapon { get; private set; }

		public WeaponData WeaponData { get { return WeaponDatabase.Instance.Get(Weapon); } }

        public HeroData(string key,int i) : base(key, i) { }

        public HeroData (string k, int i, HeroData d) : base(k,i,d)
        {
            this.frontSkeleton = d.frontSkeleton;
            this.backSkeleton = d.backSkeleton;
            this.skin = d.skin;
        }

        public override void Set(params object [] args)
        {
            frontSkeleton = (SkeletonDataAsset)args[0];
            backSkeleton = (SkeletonDataAsset)args[1];
            skin = (string)args[2];
        } 

        public override void Parse(List<string> tokens)
        {
            HP = int.Parse(tokens[1]);
            Speed = float.Parse(tokens[2]);
            Weapon = tokens[3];
        }
    }


    [System.Serializable]
    public class HeroDatabase : Database<HeroData> { }
}
