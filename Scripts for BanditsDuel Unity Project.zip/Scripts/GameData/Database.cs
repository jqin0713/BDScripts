﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using LGG;
using System.Linq;
using System;
using System.IO;

namespace BD {
    [System.Serializable]
	public abstract class Data{
        [SerializeField] private string key;
        public int Index;

        public string Key { get { return key; } }
	
        public Data (string k, int i) {
            key = k;
            Index = i;
        }

        public Data (string k, int i, Data d) {
            key = k;
            Index = i;
        }

        public abstract void Parse(List<string> tokens);
        public abstract void Set(params object[] args);
    }

    [System.Serializable]
    public abstract class Database<T> : LGSingleton<Database<T>> where T : Data{
        [SerializeField] private List<string> keys;
        [SerializeField] private List<T> entries;

        public string spreadsheetID,gid,filename,goToEntry;

        public List<string> Keys { get { return keys; } }
        public List<T> Entries { get { return entries; } }
        public int Count { get { return entries.Count; } }
        public string SpreadsheetURL { get { return string.Format("https://docs.google.com/spreadsheets/d/{0}/export?format=csv&id={0}&gid={1}",spreadsheetID,gid); } }
        public bool SheetLoaded { get; private set; }

        private Coroutine loadingCr;

        protected override void Init()
        {
            base.Init();
            LoadSheet();
        }

        public void Initialize()
        {
            if (keys == null)
            {
                keys = new List<string>();
                entries = new List<T>();
            }

        }

        public bool Add(string k, T e) {
            if(keys.Contains(k)) {
                Debug.LogWarningFormat("BaseDatabase::Add Failed to add entry with key {0}. Key already exists in database.", k);
                return false;
            }

            keys.Add(k);
            entries.Add(e);
            return true;
        }

        public void Set(string k, T e) {
            if (keys.Contains(k))
            {
                entries[FindIndex(k)] = e;
            } else
                Debug.LogWarningFormat("BaseDatabase::Set Failed to set entry with key {0}. Key does not exist in database.", k);
                
        }

        public bool Remove(string k) {
            if (keys.Contains(k)) {
                return Remove(FindIndex(k));
            }

            Debug.LogWarningFormat("BaseDatabase::Remove Failed to remove entry with key {0}. Key does not exist in database.", k);
            return false;
        }

        public bool Remove(int i) {
            if (i < entries.Count && i >= 0)
            {
                entries.RemoveAt(i);
                keys.RemoveAt(i);
                return true;
            }

            Debug.LogWarningFormat("BaseDatabase::Remove Failed to remove index {0}. Database size {1}", i, Count);
            return false;
        }

        public T Get(int i) {
            if (!Application.isPlaying || SheetLoaded)
            {
                if (i < entries.Count && i >= 0)
                    return entries[i];

                Debug.LogWarningFormat("BaseDatabase::Get Failed to retrieve index {0}. Database size {1}", i, Count);
                return null;
            }
            else
            {
                Debug.LogWarningFormat("BaseDatabase::Get Failed to retrieve index {0}. The Database has not finished loading from google spreadsheets.", i, Count);
                return null;
            }
        }

        public T Get(string k) {
            if (keys.Contains(k)) {
                return Get(FindIndex(k));
            }

            Debug.LogErrorFormat("BaseDatabase::Get Failed to retrieve entry with key \"{0}\". Key does not exist in database.", k);
            return null;
        }

        public int FindIndex(string k) {
            return entries.FindIndex(e => e.Key == k);
        }

        public void RefreshIndicies() {
            foreach (T e in entries)
            {
                e.Index = FindIndex(e.Key);
            }
        }

        public void LoadSheet(Callback cb = null) {
            if (loadingCr == null)
            {
                loadingCr = StartCoroutine(LoadSheetRoutine(cb));
                DatabaseManager.AddLoading(loadingCr);
            }
        }

        private IEnumerator LoadSheetRoutine(Callback cb = null) {
            yield return null;
            SheetLoaded = false;

            if (string.IsNullOrEmpty(spreadsheetID) || string.IsNullOrEmpty(gid))
            {
                LoadCached(cb);
                DatabaseManager.RemoveLoading(loadingCr);
                loadingCr = null;
                yield break;
            }
                
            WWW www = new WWW(SpreadsheetURL);

            yield return www;

            if (www.error == null)
            {
                ParseData(www.text);

                Debug.LogFormat("Database::LoadSheet {0} loaded successfully.", name); 
                SheetLoaded = true;

                if (cb != null)
                    cb();
                
                if(Application.isPlaying)
                    CacheData(www.text);
            }
            else
            {
                LoadCached(cb);
            }

            DatabaseManager.RemoveLoading(loadingCr);
            loadingCr = null;
        }

        private void ParseData(string text) {
            var lines = CSVParser.Parse(text);

            for (int i = 1; i < lines.Count; i++)
            {
                List<string> tokens = lines[i];
                string key = tokens[0];
                T data = Entries.SingleOrDefault( e => e.Key == key);

                if (data == null)
                {
                    data = (T)Activator.CreateInstance(typeof(T), key, Count);
                    Add(key, data);
                }

                data.Parse(tokens);
            }
        }

        private void CacheData(string text) {
            if (string.IsNullOrEmpty(filename))
            {
                Debug.LogWarning("Database::CacheData Cannot cache, no filename is set. Please set a filename in the inspector."); 
                return;
            }
            string dir = string.Format("{0}/Data",Application.persistentDataPath);
            string path = string.Format("{0}/{1}.csv",dir,filename);

            if(!Directory.Exists(dir))
                Directory.CreateDirectory(dir);

            File.WriteAllText(path,text);

            Debug.LogFormat("Database::CacheData {0} cache successful {1}", name, path); 
        }

        private void LoadCached(Callback cb) {
            string path = string.Format("{0}/Data/{1}.csv",Application.persistentDataPath,filename);
            Debug.LogFormat("Database::LoadCached Failed to download data. Loading from file {0}", path); 

            if(File.Exists(path)) {
                ParseData(File.ReadAllText(path));

                if (cb != null)
                    cb();

                SheetLoaded = true;
                Debug.LogFormat("GameData::LoadCached Sheet Successfully loaded {0}.", path);
            } else {
                Debug.LogErrorFormat("GameData::LoadCached Could not load file {0}", path);
            }
        }

        public virtual T CreateEntry(string key) {
            T entry = (T)Activator.CreateInstance(typeof(T),key,Count);
            Add(key, entry);
            return entry;
        }

        public virtual T DuplicateEntry(T orig, string newKey) {
            T entry = (T)Activator.CreateInstance(typeof(T),newKey,Count, orig);
            Add(newKey, entry);
            return entry;
        }
    }
}
