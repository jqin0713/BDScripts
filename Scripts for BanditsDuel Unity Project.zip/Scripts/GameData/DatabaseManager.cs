﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace BD {
    public static class DatabaseManager
    {
        static List<Coroutine> loadingRoutines;

        public static void AddLoading(Coroutine r) {
            if (loadingRoutines == null)
                loadingRoutines = new List<Coroutine>();

            loadingRoutines.Add(r);
        }

        public static void RemoveLoading(Coroutine r) {
            loadingRoutines.Remove(r);
        }

        public static bool AnyLoading() {
            return loadingRoutines.Any();
        }
    }
}
