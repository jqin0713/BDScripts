﻿using UnityEngine;
using System.Collections;
using LGG;
using Spine.Unity;
using System.Collections.Generic;
using UnityEngine.UI;

namespace BD
{
    [System.Serializable]
    public class GeneralData : Data
    {
        public int IntValue { get; private set; }
        public float FloatValue { get; private set; }
        public string StringValue { get; private set; }

        public string ValueType { get; private set; }

        public GeneralData(string key, int i) : base(key, i)
        {

        }

        public GeneralData(string k, int i, GeneralData d) : base(k, i, d)
        {

        }

        public override void Set(params object[] args)
        {

        }

        public override void Parse(List<string> tokens)
        {
            ValueType = tokens[1];

            switch (ValueType)
            {
                case "int":
                    IntValue = int.Parse(tokens[2]);
                    break;
                case "float":
                    FloatValue = float.Parse(tokens[2]);
                    break;
                case "string":
                    StringValue = tokens[2];
                    break;
            }
        }
    }

    [System.Serializable]
    public class GeneralDatabase : Database<GeneralData>
    {

    }
}
