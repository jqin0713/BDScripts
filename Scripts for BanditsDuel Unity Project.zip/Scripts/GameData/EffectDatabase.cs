﻿using UnityEngine;
using System.Collections;
using LGG;
using Spine.Unity;
using System.Collections.Generic;
using UnityEngine.UI;
using System.Linq;

namespace BD
{
	[System.Serializable]
	public class EffectData : Data
	{


		//Set in google spreadsheets and parsed
		public string TypeOfEffect { get; private set; }

		public Effect.EffectDurationTypes EffectDurationType { get; private set; }
		public float EffectDuration { get; private set; }

		public int StackLimit { get; private set; }

		public float[] EffectAmounts { get; private set; }

		public float EffectFrequency { get; private set; }


		public EffectData(string key, int i) : base(key, i) { }

		public EffectData(string k, int i, SuperData d) : base(k, i, d)
		{

		}

		public override void Set(params object[] args)
		{

		}

		public override void Parse(List<string> tokens)
		{
			TypeOfEffect = tokens[1];

			EffectDurationType = (Effect.EffectDurationTypes)System.Enum.Parse(typeof(Effect.EffectDurationTypes), tokens[2], true);
			switch (EffectDurationType)
			{
				case Effect.EffectDurationTypes.Set_Duration:
					EffectDuration = float.Parse(tokens[3]);
					break;
				case Effect.EffectDurationTypes.Rest_Of_Match:
					EffectDuration = 300f;
					break;
			}

			StackLimit = int.Parse(tokens[4]);

			if (string.IsNullOrEmpty(tokens[5]))
			{
				EffectAmounts = null;
			}
			else
			{
				string[] amountsAsStrings = tokens[5].Split(',');
				EffectAmounts = new float[amountsAsStrings.Length];
				for (int i = 0; i < amountsAsStrings.Length; i++)
				{
					EffectAmounts[i] = float.Parse(amountsAsStrings[i].Trim());
				}
			}

			EffectFrequency = float.Parse (tokens [6]);
		}
	}

	[System.Serializable]
	public class EffectDatabase : Database<EffectData>
	{

	}
}
