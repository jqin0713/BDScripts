﻿using UnityEngine;
using System.Collections;
using LGG;
using Spine.Unity;
using System.Collections.Generic;
using UnityEngine.UI;

namespace BD
{
    [System.Serializable]
    public class WeaponData : Data
    {
        //Set in editor and saved in a prefab
        [SerializeField] private SkeletonDataAsset actionButtonSkeleton;

        //Getters for vars set in editor
        public SkeletonDataAsset ActionButtonSkeleton { get { return actionButtonSkeleton; } }

        //Set in google spreadsheets and parsed
        public float Range { get; private set; }
        public List<DuelManager.TargetTypes> TargetTypes { get; private set; }
		public int StartingAmmo { get; private set; }
		public int AmmoRegain {get; private set; }
        public Dictionary<DuelManager.ParamTypes, int> Params { get; private set; }

        public WeaponData(string key, int i) : base(key, i) { }

        public WeaponData(string k, int i, WeaponData d) : base(k, i, d)
        {
            this.actionButtonSkeleton = d.actionButtonSkeleton;
        }

        public override void Set(params object[] args)
        {
            actionButtonSkeleton = (SkeletonDataAsset)args[0];
        }

        public override void Parse(List<string> tokens)
        {
            TargetTypes = new List<DuelManager.TargetTypes>();
            Params = new Dictionary<DuelManager.ParamTypes, int>();

            Range = float.Parse(tokens[1]);

            if (!string.IsNullOrEmpty(tokens[2]))
            {
                TargetTypes.Add((DuelManager.TargetTypes)System.Enum.Parse(typeof(DuelManager.TargetTypes), tokens[2]));
            }

            if (!string.IsNullOrEmpty(tokens[3]))
            {
                TargetTypes.Add((DuelManager.TargetTypes)System.Enum.Parse(typeof(DuelManager.TargetTypes), tokens[3]));
            }

            if (!string.IsNullOrEmpty(tokens[4]))
            {
                Params.Add((DuelManager.ParamTypes)System.Enum.Parse(typeof(DuelManager.ParamTypes), tokens[4]), int.Parse(tokens[5]));
            }

            if (!string.IsNullOrEmpty(tokens[6]))
            {
                Params.Add((DuelManager.ParamTypes)System.Enum.Parse(typeof(DuelManager.ParamTypes), tokens[6]), int.Parse(tokens[7]));
            }
			if (!string.IsNullOrEmpty (tokens [8])) {
				StartingAmmo = int.Parse(tokens[8]);
			}
			if (!string.IsNullOrEmpty (tokens [9])) {
				AmmoRegain = int.Parse (tokens [9]);
			}
        }
    }

    [System.Serializable]
    public class WeaponDatabase : Database<WeaponData>
    {
        
    }
}
