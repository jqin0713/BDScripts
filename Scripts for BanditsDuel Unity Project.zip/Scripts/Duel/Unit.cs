﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.Networking;
using Spine.Unity;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using System.Linq;
using LGG;
using DG.Tweening;
using Pathfinding;
using TMPro;
using System;

namespace BD
{
    public class Unit : LGNetworkBehaviour
    {
        [SerializeField]
        private Rigidbody2D playerRigidbody;
        [SerializeField]
        private SkeletonAnimation skeletonAnimation;
        [SerializeField]
        private SpriteRenderer healthBarFill;
        [SerializeField]
        private Seeker seeker;
        [SerializeField]
        private Sprite greenFill, yellowFill, redFill;
        [SerializeField]
        private Transform hand;
        [SerializeField]
        private TextMeshPro ammoLabel;

        public Transform Hand { get { return hand; } protected set { } }
        public HeroData Data { get; protected set; }
        public Directions Facing { get; protected set; }
        public Player Owner { get; protected set; }
        public Weapon Weapon;
        public UnitAI AI;
		public CircleCollider2D critHitCircle, normHitCircle, grazeHitCircle;
        public Lane Lane;
        public bool DestinationReached;
        public float PercentReached;
        public Vector2 WalkStartPos;
        public ActionButton ActionButton;
		//This variable will be used to affect damage-intake. This value starts off at 1; a smallest value (though higher than 0) indicates that a Unit
		//will take MORE damage; a higher value = LESS damage. Specifically, damage intake = normal damage / armor value
		public int Armor;

		public List<Effect> Debuffs;
		public List<Effect> Buffs;

		public List<Super> Supers;

		//This window pops up at the bottom of the screen during the actual fighting sequence whenever a Unit is selected. For now, the limit will be something around 3 Cards per Unit.
		public SuperWindow SuperWindow;

        private Coroutine pathingRoutine, walkRoutine, startWalkRoutine;
        private List<Vector3> currentWaypoints;
        private Vector3 currentWaypoint;

        public enum Directions
        {
            Forward,
            Backward,
            Left,
            Right
        }

        public enum ActionStates
        {
            Idling,
            Walking,
            Shooting,
            TakingDamage,
            Dead,
            KnockedDown
        }

        public ActionStates ActionState;

        private int health;
        public int Health
        {
            get
            {
                return health;
            }
            set
            {
                health = Mathf.Clamp(value, 0, Data.HP);
                UpdateHealth();

                if (Owner.Heroes.ContainsKey(Data.Key))
                {
                    Owner.Heroes[Data.Key].Health = health;
                }
            }
        }

        private int ammo;
        public int Ammo
        {
            get
            {
                return ammo;
            }
            set
            {
                ammo = value;
                UpdateAmmo();

                if (Owner.Heroes.ContainsKey(Data.Key))
                {
                    Owner.Heroes[Data.Key].Ammo = ammo;
                }
            }
        }

        protected override void Awake()
        {
            base.Awake();
            AI = GetComponent<UnitAI>();
			Debuffs = new List<Effect> ();
			Buffs = new List<Effect> ();
        }

		public float Speed;

        protected override void OnDestroy()
        {
            base.OnDestroy();
			Destroy(SuperWindow);
			//Destroy(SuperWindow.gameObject);
        }

		public Unit UnitClone() {
			return (Unit)this.MemberwiseClone ();
		}

        public void SetData(string key, Vector2 position, int id, Lane l)
        {
            Lane = l;
            Owner = GameObject.FindObjectsOfType<Player>().FirstOrDefault(p => p.ClientID == id);
            GameManager.Instance.DuelManager.AllUnits.Add(this);
			transform.SetParent(Owner.UnitsRoot.transform, true);
            Data = HeroDatabase.Instance.Get(key);
            skeletonAnimation.initialSkinName = Data.Skin;
            SetSkeleton(Data.FrontSkeleton);
            skeletonAnimation.Initialize(true);
            transform.position = position;
            WalkStartPos = transform.position;
            SetDirection(Owner.ClientID == 2 ? Directions.Backward : Directions.Forward, true);
            Health = Owner.Heroes[key].Health;
			Speed = Owner.Heroes [key].Speed;
            Ammo = 5;
			Armor = 1;

            //Ammo = Owner.Heroes[key].Ammo;
            SetAnimation("idle", true, 1);

            switch (Data.WeaponData.Key)
            {
                case "Revolver":
                    Weapon = GetComponent<WeaponRevolver>();
                    break;
                case "Dynamite":
                    Weapon = GetComponent<WeaponDynamite>();
                    break;
                case "Barrel":
                    Weapon = GetComponent<WeaponBarrel>();
                    break;
                default:
                    break;
            }

            Weapon.enabled = true;
            Weapon.Initialize(this, Data.WeaponData.Key);

            if (GameManager.Instance.OnlineMatch)
            {
                if (GameManager.Instance.IsClient)
                {
                    if (Owner == Player.Authoritative)
                    {
                        healthBarFill.sprite = greenFill;
                    }
                    else
                    {
                        healthBarFill.sprite = redFill;
                    }
                }
                else //isServer
                {
                    healthBarFill.sprite = yellowFill;
                }
            }
            else
            {
                if (Owner.ClientID == 0 || Owner.ClientID == 2)
                {
                    healthBarFill.sprite = redFill;
                }
                else if (Owner.ClientID == 1)
                {
                    healthBarFill.sprite = greenFill;
                }
            }
        }

        [ClientRpc]
        public void RpcSetData(string key, Vector2 position, int id, int laneIndex)
        {
            Lane l = GameManager.Instance.DuelManager.lanes[laneIndex];
            SetData(key, position, id, l);
        }

        protected virtual void UpdateHealth()
        {
            float percent = Health / (float)Data.HP;
            healthBarFill.transform.localScale = new Vector3(2.5f * percent, 2, 1f);
            healthBarFill.transform.localPosition = new Vector3(-1.9f + (percent * 1.9f), healthBarFill.transform.localPosition.y, healthBarFill.transform.localPosition.z);
        }

        protected virtual void UpdateAmmo()
        {
            ammoLabel.text = Ammo.ToString();
        }

        private void SetSkeleton(SkeletonDataAsset skel, bool force = false)
        {
            if (force || skeletonAnimation.skeletonDataAsset != skel)
            {
                skeletonAnimation.skeletonDataAsset = skel;
                skeletonAnimation.Initialize(true);
            }
        }

        public void SetAnimation(string animation, bool loop, float timeScale)
        {
            skeletonAnimation.state.ClearTracks();
            skeletonAnimation.state.SetAnimation(0, animation, loop);
            skeletonAnimation.timeScale = timeScale;
        }

        private Vector2 CalculateVeleocity(Vector2 targetPosition)
        {
            return (targetPosition - (Vector2)transform.position).normalized;
        }

        public Directions CalculateDirection(Vector2 targetPosition)
        {
            Vector2 targetDirection = targetPosition - (Vector2)transform.position;

            Directions dir = Directions.Backward;

            if (targetDirection.x > 0 && targetDirection.y > 0)
            {
                dir = Directions.Forward;
            }
            else if (targetDirection.x < 0 && targetDirection.y < 0)
            {
                dir = Directions.Backward;
            }
            else if (targetDirection.x < 0 && targetDirection.y > 0)
            {
                dir = Directions.Left;
            }
            else if (targetDirection.x > 0 && targetDirection.y < 0)
            {
                dir = Directions.Right;
            }

            return dir;
        }

        public void SetDirection(Directions dir, bool force = false)
        {
            if (Facing == dir && !force)
                return;

            string animation = skeletonAnimation.AnimationName;
            bool loop = skeletonAnimation.loop;
            float timeScale = skeletonAnimation.timeScale;

            Facing = dir;
            SetSkeleton(Facing == Directions.Backward || Facing == Directions.Right ? Data.FrontSkeleton : Data.BackSkeleton);
            skeletonAnimation.skeleton.FlipX = (Facing == Directions.Backward || Facing == Directions.Left);

            if (animation != null)
            {
                SetAnimation(animation, loop, timeScale);
            }
        }

        public virtual void StopWalking(bool setIdle, bool clearWalkTarget)
        {
            if (pathingRoutine != null)
            {
                StopCoroutine(pathingRoutine);
            }

            if (walkRoutine != null)
            {
                StopCoroutine(walkRoutine);
            }

            if (startWalkRoutine != null)
            {
                StopCoroutine(startWalkRoutine);
            }

            playerRigidbody.velocity = Vector3.zero;

            if (clearWalkTarget)
            {
                currentWaypoint = Vector3.zero;
                DestinationReached = true;
                PercentReached = 1f;
            }

            if (setIdle)
            {
                ActionState = ActionStates.Idling;
                SetAnimation("idle", true, 1f);
            }
        }

        public void StartWalking(float delay)
        {
            if (startWalkRoutine != null)
            {
                StopCoroutine(startWalkRoutine);
            }

            startWalkRoutine = StartCoroutine(StartWalkingRoutine(delay));
        }

        private IEnumerator StartWalkingRoutine(float delay)
        {
            yield return new WaitForSeconds(delay);

            if (currentWaypoint != Vector3.zero)
            {
                if (pathingRoutine != null)
                {
                    StopCoroutine(pathingRoutine);
                }

                pathingRoutine = StartCoroutine(FindPathRoutine(transform.position, currentWaypoint, true, true));
            }
            else
            {
                ActionState = ActionStates.Idling;
                SetAnimation("idle", true, 1f);
            }

            startWalkRoutine = null;
        }

        public virtual void WalkToPosition(Vector3 targetPos)
        {
            currentWaypoint = targetPos;

            if (pathingRoutine != null)
            {
                StopCoroutine(pathingRoutine);
            }

            pathingRoutine = StartCoroutine(FindPathRoutine(transform.position, targetPos, true, true));
        }

        protected virtual IEnumerator FindPathRoutine(Vector3 startPos, Vector3 targetPos, bool selfIsTrigger, bool removeFirst)
        {
            Path path = null;
            RaycastHit hit;

            if (Physics.Raycast((Vector2)startPos, Camera.main.transform.forward, out hit, 1000f))
            {
                startPos = hit.point;
            }

            if (Physics.Raycast((Vector2)targetPos, Camera.main.transform.forward, out hit, 1000f))
            {
                seeker.StartPath(startPos, hit.point, (Path p) =>
                {
                    if (!p.error)
                    {
                        path = p;
                    }
                    else
                    {
                        Debug.LogError("Pathing Error");
                    }
                });
            }

            while (path == null)
            {
                yield return null;
            }

            if (path.vectorPath.Count > 1)
            {
                if (removeFirst)
                {
                    path.vectorPath.RemoveAt(0);
                }

                if (walkRoutine != null)
                {
                    StopCoroutine(walkRoutine);
                }

                walkRoutine = StartCoroutine(WalkToPositionRoutine(path.vectorPath.ToArray()));
            }

            pathingRoutine = null;
        }

        protected virtual IEnumerator WalkToPositionRoutine(Vector3[] waypoints)
        {
            ActionState = ActionStates.Walking;
            DestinationReached = false;
            PercentReached = 0;
            currentWaypoints = new List<Vector3>(waypoints);

            float totalDist = Vector2.Distance(WalkStartPos, (Vector2)currentWaypoints[currentWaypoints.Count - 1]);

            SetAnimation("walk", true, 1f);
            SetDirection(CalculateDirection(currentWaypoints[0]));
            playerRigidbody.velocity = CalculateVeleocity(currentWaypoints[0]) * Speed;

            while (currentWaypoints.Count > 0)
            {
                playerRigidbody.velocity = CalculateVeleocity(currentWaypoints[0]) * Speed;
                PercentReached = Vector2.Distance(WalkStartPos, (Vector2)transform.position) / totalDist;

                if (Vector2.Distance((Vector2)transform.position, (Vector2)currentWaypoints[0]) < 0.2f)
                {
                    currentWaypoints.RemoveAt(0);

                    if (currentWaypoints.Count > 1)
                    {
                        SetDirection(CalculateDirection(currentWaypoints[0]));
                    }
                }

                yield return new WaitForFixedUpdate();
            }

            playerRigidbody.velocity = Vector3.zero;
            walkRoutine = null;
            DestinationReached = true;
            currentWaypoint = Vector3.zero;
            SetAnimation("idle", true, 1);
        }

		//Here, a check will be made for any effects that only proc on the "next successful enemy attack"
        public void KnockDown(int damage, DuelManager.HitTypes hitType = DuelManager.HitTypes.Miss)
        {
            if (hitType == DuelManager.HitTypes.Miss || Health <= 0) return;

			for (int i = 0; i < Buffs.Count; i ++) {
				if (Buffs[i].EffectDurationType == Effect.EffectDurationTypes.After_Next_Successful_Enemy_Attack) {
					Buffs [i].Proc ();
					Buffs.RemoveAt (i);
					i--;
				}
			}
			for (int i = 0; i < Debuffs.Count; i ++) {
				if (Debuffs[i].EffectDurationType == Effect.EffectDurationTypes.After_Next_Successful_Enemy_Attack) {
					Debuffs [i].Proc ();
					Debuffs.RemoveAt (i);
					i--;

				}
			}

            ActionState = ActionStates.KnockedDown;
            StopWalking(false, false);
			damage /= Armor;
			Health -= damage;
            SpawnFloatingText("-" + damage.ToString(), hitType);

            if (Health <= 0)
            {
                Dead();
            }
            else
            {
                SetAnimation("knockoutHit", false, 1f);
                AudioManager.Instance.PlaySound("sfx_anim_knocked_out");
                StartWalking(1.2f); //0.833 default value
            }
        }

		//Same with this
        public void TakeDamage(int damage, DuelManager.HitTypes hitType)
        {
            if (hitType == DuelManager.HitTypes.Miss || Health <= 0) return;

			for (int i = 0; i < Buffs.Count; i ++) {
				if (Buffs[i].EffectDurationType == Effect.EffectDurationTypes.After_Next_Successful_Enemy_Attack) {
					Buffs [i].Proc ();
					Buffs.RemoveAt (i);
					i--;
				}
			}
			for (int i = 0; i < Debuffs.Count; i ++) {
				if (Debuffs[i].EffectDurationType == Effect.EffectDurationTypes.After_Next_Successful_Enemy_Attack) {
					Debuffs [i].Proc ();
					Debuffs.RemoveAt (i);
					i--;
				}
			}

			Debug.LogWarning ("" + hitType + " received on " + Data.Key);

            ActionState = ActionStates.TakingDamage;
            StopWalking(false, false);
			damage /= Armor;
			Health -= damage;
            SpawnFloatingText("-" + damage.ToString(), hitType);

            if (Health <= 0)
            {
                Dead();
            }
            else
            {
                SetAnimation("hit", false, 1f);
                AudioManager.Instance.PlaySound("sfx_character_hit1");
                StartWalking(0.833f);
            }
        }

		//This method is to allow for damage taking without flinching
		public void TakeDamageFromDebuff(int damage) {
			ActionState = ActionStates.TakingDamage;
			Health -= damage;
			SpawnFloatingText("-" + damage.ToString(), DuelManager.HitTypes.Debuff);

			if (Health <= 0)
			{
				foreach (Effect e in Debuffs)
				{
					e.MarkedForRemoval = true;
				}
				Dead();
			}
		}

        private void Dead()
        {
            StartCoroutine(DeadRoutine());
        }

        private IEnumerator DeadRoutine()
        {
            yield return null;

            if (Owner.ClientID == 1)
            {
                GameManager.Instance.DuelManager.Player2.Score++;
            }
            else if (Owner.ClientID == 2)
            {
                GameManager.Instance.DuelManager.Player1.Score++;
            }

            GameManager.Instance.DuelManager.UpdateScore();

            ActionState = ActionStates.Dead;
            Owner.Heroes.Remove(Data.Key);

            SetAnimation("knockoutHit", false, 1f);
            AudioManager.Instance.PlaySound("sfx_anim_knocked_out");

            yield return new WaitForSeconds(0.833f);

            SetAnimation("knockoutIdle", true, 1f);

            float startTime = Time.time;
            float percent = 0f;

            while (percent < 1f)
            {
                percent = (Time.time - startTime) / 2.5f;
                skeletonAnimation.skeleton.a = 1f - percent;

                yield return null;
            }

            GameManager.Instance.DuelManager.AllUnits.Remove(this);
			//GameManager.Instance.DuelManager.UnitIterationOffset = true;
            Destroy(gameObject);
        }

        public void SpawnFloatingText(string message, DuelManager.HitTypes hitType)
        {
            FloatingText floatingText = Instantiate(GameManager.Instance.FloatingTextPrefab, this.transform).GetComponent<FloatingText>();
            floatingText.gameObject.transform.position = new Vector3(transform.position.x, transform.position.y + 6, transform.position.z);
            floatingText.SetText(message, hitType, this);
        }
    }
}
