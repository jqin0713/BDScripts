﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using LGG;
using UnityEngine.UI;
using System.Linq;
using DG.Tweening;
using Spine.Unity;
using UnityEngine.Networking;

namespace BD
{
	public class FieldEffect : Super
	{
		//Note that althought field effects are their own category of super, it is possible for another super type, such as an Attack Enhancer like Toxic Explosive,
		//to create "Field Effects". In general, field effects will have their sprite size and collider size (and type) determined by Attack Enhancer specifications,
		//but only if the "Side" warrants it. For examples, Player, Opponent, and Both always have the same dimensions. Note that FieldEffect skills based on certain weapons
		//will go under the various <WeaponType>Super folders; FieldEffects created from AttackEnhancers go inside the FieldEffects folder.
		//***NOTE***: Inside the data tables, AE-generated FEs will NOT have their own FE specs; this is because they are already supplied inside the FE specs for the AE
		public enum AfflictedSide { Player, Opponent, Both, Selected, Lane_Or_Lanes, Area }
		public AfflictedSide Side;

		public string[] FieldEffectSpecifications;

		public void ApplySpecifications()
		{
			if (FieldEffectSpecifications == null)
			{
				return;
			}
			ActuallyApplySpecs();
		}

		public virtual void ActuallyApplySpecs()
		{
		}

		//This method deals with the remaining aspects of the Field Effect: the location (the parameter Location will
		//often be a center, as long as the Side isn't one of the special types) and enabling the Colliders and
		//the GameSprites, as well as some "spawn animation". In the case that the Field Effect is Instant, only an 
		//animation will play.
		public virtual void Placement(Vector3 Location) {
			
		}

		//Usually some fade out animation goes here (the creation animations happen in Placement)
		public virtual void Destroy() {
		}
	}
}

