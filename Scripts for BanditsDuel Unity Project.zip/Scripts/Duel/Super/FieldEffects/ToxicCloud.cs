﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using LGG;
using UnityEngine.UI;
using System.Linq;
using DG.Tweening;
using Spine.Unity;
using UnityEngine.Networking;

namespace BD
{
	
	public class ToxicCloud : FieldEffect
	{
		public CircleCollider2D Cloud;
		public float TickFrequency;
		public Dictionary<Unit, float> UnitsInside;

		public override void Destroy()
		{
			
		}

		public override void ActuallyApplySpecs ()
		{
			UnitsInside = new Dictionary<Unit,float> ();
			Cloud.radius = float.Parse(FieldEffectSpecifications [0]);
			TickFrequency = float.Parse(FieldEffectSpecifications [1]);
		}

		public override void Placement (Vector3 Location)
		{
			Cloud.offset = Location;
			Cloud.enabled = true;
		}

		private void OnTriggerEnter2D(Collider2D other)
		{
			if (other.gameObject.layer == LayerMask.NameToLayer("Hero"))
			{
				Unit u = other.GetComponentInParent<Unit>();
				if (u.Owner != Player.Authoritative)
				{
					UnitsInside.Add(u, Time.time);
				}
				ApplyEffects(UnitsInside.Keys.ToList());
			}
		}

		private void OnTriggerStay2D(Collider2D other)
		{
			List<Unit> applicableUnits = new List<Unit>();
			foreach (Unit u in UnitsInside.Keys) {
				if (Time.time - UnitsInside [u] > TickFrequency) {
					UnitsInside [u] = Time.time;
					applicableUnits.Add (u);
				}
			}
			ApplyEffects (applicableUnits);
		}

		private void OnTriggerExit2D(Collider2D other) {
			if (other.gameObject.layer == LayerMask.NameToLayer ("Hero")) {
				Unit u = other.GetComponentInParent<Unit>();
				if (u.Owner != Player.Authoritative) {
					UnitsInside.Remove (u);
				}
			}
		}

		
	}
}
