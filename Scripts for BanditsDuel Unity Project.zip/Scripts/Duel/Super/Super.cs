﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using LGG;
using UnityEngine.UI;
using System.Linq;
using DG.Tweening;
using Spine.Unity;
using UnityEngine.Networking;
using System.Text.RegularExpressions;
using System.Reflection;
using System;

namespace BD
{
	public class Super : LGNetworkBehaviour, IComparable<Super>
	{
		public string SuperName;
		//Instead of a super associated with a particular character, supers will be based on what weapon is selected; for now,
		//these two are essentially the same concept since each character has a unique weapon
		public string Weapon;

		//The Unit using this Super during the current game; used for applying weapon enhancements
		public Unit User;

		//Although supers are divided up into four categories, many of them are somewhat intertwined with each other. The only skills that can directly apply buffs are
		//FieldEffect and AllyAssist types. Skills that can apply debuffs include AttackEnhancers (but ONLY INDIRECTLY), FieldEffects, and EnemyDebuffers. AllyAssist and
		//EnemyDebuffer types are SINGLE-TARGET ONLY. FieldEffects are the only DIRECT way to affect multiple targets, though AttackEnhancers may CREATE certain
		//FieldEffects. AttackEnhancers that apply debuffs WITHOUT using FieldEffects are unable to affect more than one target.
		public string TypeOfSuper;

		public int MPCost;

		//"Dependent" duration types are exactly what they sound like they are
		//"Instant" duration types only apply for non-enhancement skills that cause Effects, though the Effects themselves may last quite a while
		public enum DurationTypes { After_Next_Ally_Attack, Instant, Set_Duration, Dependent }
		public DurationTypes DurationType;
		public float SetDuration;

		public enum CooldownTypes { Rest_Of_Match, Set_Duration }
		public CooldownTypes CooldownType;
		public float CooldownTime;
		//This variable keeps track of time since instantiation; only really matters for FieldEffects and AttackEnhancers
		public float LifeTime;

		public enum EffectTypes { Debuff, Buff, None, Both }
		public EffectTypes Effect;
		//If you observe the parsing code for effects, you'll notice that the effects are stored as an array of strings. This is because of hte issue
		//of the "Specifications" array, which may sometimes be used to override default values for certain effects (for example, Damage Increase might have a default
		//damage multiplier of 1.5, but if "Multiplicative 2" is specified, then the situation must be adjusted accordingly. The actual code for creating
		//the lists of effects occurs inside the specific effect classes.
		public List<Effect> BuffsApplied;
		public List<Effect> DebuffsApplied;

		//Idea: the name could be located directly inside this class, eliminating the need for an override to Start inside the individual super classes.
		//However, this is done via this.GetType().Name, which requires polymorphism (e.g. Super s = new SpecificSuper();) and requires parsing the names of classes
		//in order to insert spaces where necessary
		public void SetData() {
			SuperName = Regex.Replace (this.GetType ().Name, "([A-Z])(?![A-Z])", " $1").Trim();

			Weapon = SuperDatabase.Instance.Get (SuperName).Weapon;
			TypeOfSuper = SuperDatabase.Instance.Get (SuperName).TypeOfSuper;
			if (TypeOfSuper == "Field Effect") {
				((FieldEffect)this).Side = SuperDatabase.Instance.Get (SuperName).Field;
				((FieldEffect)this).FieldEffectSpecifications = SuperDatabase.Instance.Get(SuperName).FieldEffectSpecifications;
				((FieldEffect)this).ApplySpecifications ();
			} else if (TypeOfSuper == "Attack Enhancer") {
				((AttackEnhancer)this).SoloEnhancementOnly = SuperDatabase.Instance.Get (SuperName).SoloEnhancementOnly;
				((AttackEnhancer)this).EnhancementSpecifications = SuperDatabase.Instance.Get (SuperName).EnhancementSpecifications;
				((AttackEnhancer)this).ApplySpecifications ();
				((AttackEnhancer)this).AEFieldEffectSpecifications = SuperDatabase.Instance.Get(SuperName).FieldEffectSpecifications;
				//Specifications are applied when the AE generates the FE
				((AttackEnhancer)this).Priority = SuperDatabase.Instance.Get (SuperName).AEPriority;
			}
			MPCost = SuperDatabase.Instance.Get (SuperName).MPCost;
			DurationType = SuperDatabase.Instance.Get (SuperName).DurationType;

			//Remember, for ANSEA and ANAA types, this value is meaningless, and DurationType should be checked beforehand
			SetDuration = SuperDatabase.Instance.Get (SuperName).Duration;

			CooldownType = SuperDatabase.Instance.Get (SuperName).CooldownType;
			CooldownTime = SuperDatabase.Instance.Get (SuperName).Cooldown;

			Effect = SuperDatabase.Instance.Get (SuperName).EffectType;

			DebuffsApplied = new List<Effect> ();
			BuffsApplied = new List<Effect> ();

			//Shorter version of the null-check
			if (Effect != Super.EffectTypes.None)
			{
				int specCounter = 0;
				foreach (string effect in SuperDatabase.Instance.Get(SuperName).Effects)
				{
					Effect e = (Effect)Assembly.GetExecutingAssembly().CreateInstance("BD." + Regex.Replace(effect, @"\s+", ""));
					e.ApplySpecifications(SuperDatabase.Instance.Get(SuperName).EffectSpecifications[specCounter]);
					e.AssociatedSuper = this;
					if (EffectDatabase.Instance.Get(effect).TypeOfEffect == "Debuff")
					{
						DebuffsApplied.Add(e);
					}
					else
					{
						BuffsApplied.Add(e);
					}
					specCounter++;
				}
			}


			/*
			string[] debuffs = SuperDatabase.Instance.Get (SuperName).Debuffs;
			string[] buffs = SuperDatabase.Instance.Get (SuperName).Buffs;

			DebuffsApplied = new List<Effect> ();
			BuffsApplied = new List<Effect> ();

			if (debuffs != null) {
				string[] debuffSpecs = SuperDatabase.Instance.Get (SuperName).DebuffSpecifications;
				for (int i = 0; i < debuffs.Length; i++) {
					Effect e = (Effect)Assembly.GetExecutingAssembly ().CreateInstance ("BD." + Regex.Replace(debuffs [i], @"\s+", ""));
					e.ApplySpecifications (debuffSpecs [i]);
					e.AssociatedSuper = this;
					DebuffsApplied.Add (e);
				}
			}
			if (buffs != null) {
				string[] buffSpecs = SuperDatabase.Instance.Get (SuperName).BuffSpecifications;
				for (int i = 0; i < buffs.Length; i++) {
					Effect e = (Effect)Assembly.GetExecutingAssembly ().CreateInstance ("BD." + Regex.Replace(buffs [i], @"\s+", ""));
					e.ApplySpecifications (buffSpecs [i]);
					e.AssociatedSuper = this;
					BuffsApplied.Add (e);
				}
			}*/

		}

		public void ApplyEffects(Unit u) {
			List<Unit> singleUnit = new List<Unit> ();
			singleUnit.Add (u);
			ApplyEffects (singleUnit);
		}

		public virtual void ApplyEffects(List<Unit> units)
		{
			foreach (Unit u in units) {
				foreach (Effect toBeAdded in DebuffsApplied) {
					if (u.Debuffs.Contains (toBeAdded)) {
						if (u.Debuffs [u.Debuffs.IndexOf (toBeAdded)].CanStack ()) {
							u.Debuffs [u.Debuffs.IndexOf (toBeAdded)].Stack (toBeAdded);
						} else {
							u.Debuffs [u.Debuffs.IndexOf (toBeAdded)].ResetTimer ();
						}
					} else {
						//Check for presence of Debuff Immunity made here; this could be a platform for debuff resistance in the future
						if (!u.Buffs.Exists(x => x.EffectName == "Debuff Immunity")) {
							toBeAdded.AffectedUnit = u;
							u.Debuffs.Add(toBeAdded);
						}
					}
				}

				foreach (Effect toBeAdded in BuffsApplied) {
					if (u.Buffs.Contains (toBeAdded)) {
						if (u.Buffs [u.Buffs.IndexOf (toBeAdded)].CanStack ()) {
							u.Buffs [u.Buffs.IndexOf (toBeAdded)].Stack (toBeAdded);
						} else {
							u.Buffs [u.Buffs.IndexOf (toBeAdded)].ResetTimer ();
						}
					} else {
						toBeAdded.AffectedUnit = u;
						u.Buffs.Add (toBeAdded);
					}
				}
			}
		}

		//Although it may be possible for different units to use the same sort of weapon, enhancements will only apply
		//for the weapon of the user himself, as otherwise enhancements would be pretty too similar to buffs; note that this method is not virtual;
		//for now, there really isn't any polymorphism needed at this step: it happens instead inside the two major methods inside AttackEnhancer
		public virtual void ApplyEnhancement() {
			if (TypeOfSuper != "Attack Enhancer") {
				Debug.LogError ("The super you are using is not an attack enhancer");
				return;
			}
			if (Weapon != User.Weapon.Data.Key) {
				Debug.LogError ("The enhancement being applied is for the incorrect weapon type");
				return;
			}
			if (((AttackEnhancer)this).SoloEnhancementOnly && User.Weapon.Enhancements.Count > 0) {
				return;
			}
			if (User.Weapon.Enhancements.Exists (x => x.SuperName == this.SuperName)) {
				return;
			}
			User.Weapon.Enhancements.Add (this);
			User.Weapon.Enhancements.Sort ();
		}

		//If the two Supers being compared are not both Attack Enhancers, then this comparison is meaningless; the only
		//purpose of implementing IComparable is for Attack Enhancers to be sorted in a manner that allows for
		//effective for-each looping inside the various Weapon scripts
		public int CompareTo(Super other) {
			if (TypeOfSuper == "Attack Enhancer" && other.TypeOfSuper == "Attack Enhancer") {
				return ((AttackEnhancer)this).Priority - ((AttackEnhancer)other).Priority;
			}
			return 0;
		}
	}
}

