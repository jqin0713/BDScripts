﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using LGG;
using UnityEngine.UI;
using System.Linq;
using DG.Tweening;
using Spine.Unity;
using UnityEngine.Networking;

namespace BD
{
	//This class was originally planned for deletion, since accuracy was supposed to be a major component of a game and having a skill that applied debuffs on enemies without
	//requiring you to aim seemed kind of OP. For future reference, to avoid this issue, EnemyDebuffers should not be made too strong. Stronger debuffs should be applied
	//via AttackEnhancers
	public class EnemyDebuffer : Super
	{
		
	}
}

