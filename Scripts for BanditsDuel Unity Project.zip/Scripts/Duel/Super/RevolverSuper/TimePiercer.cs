﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using LGG;
using UnityEngine.UI;
using System.Linq;
using DG.Tweening;
using Spine.Unity;
using UnityEngine.Networking;

namespace BD
{
	public class TimePiercer : FieldEffect
	{


		public override void ActuallyApplySpecs ()
		{
			
		}

		public override void Placement (Vector3 Location)
		{
			GameManager.Instance.DuelManager.Player1 = GameManager.Instance.DuelManager.PastPlayer1;
			GameManager.Instance.DuelManager.Player2 = GameManager.Instance.DuelManager.PastPlayer2;
			for (int i = 0; i < GameManager.Instance.DuelManager.AllUnits.Count; i++) {
				GameManager.Instance.DuelManager.AllUnits [i] = GameManager.Instance.DuelManager.PastAllUnits [i];
			}
			//Also need to implement code to destroy all projectiles on the scene
		}

	}
}

