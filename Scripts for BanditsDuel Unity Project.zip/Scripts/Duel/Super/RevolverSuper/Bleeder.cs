﻿using System;
namespace BD
{
	public class Bleeder : EnemyDebuffer
	{
		
	}
}
