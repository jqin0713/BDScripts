﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using LGG;
using UnityEngine.UI;
using System.Linq;
using DG.Tweening;
using Spine.Unity;
using UnityEngine.Networking;

namespace BD
{
	public class DoubleExplosion : AttackEnhancer
	{
		//By default this is 2, but for testing purposes this will be adaptable
		private int amountOfExplosions;

		public override void ActuallyApplySpecs ()
		{
			amountOfExplosions = int.Parse (EnhancementSpecifications [0].Trim ());
			Debug.LogWarning ("amountOfExplosions is " + amountOfExplosions);
		}

		public override void ActuallyGenerateFieldEffect(Vector3 Location)
		{
			
			amountOfExplosions--;
			if (amountOfExplosions >= 1) {
				Projectile.GetComponent<Dynamite> ().Redo = true;
			} else {
				//The following line may seem counter-intuitive, but this is to distinguish it from the rest of the attack enhancers in that it should be deleted after the FIRST PASSTHROUGH inside ThrowButDontDestroy
				MarkedForDestruction = false;
			}

		}

	}
}

