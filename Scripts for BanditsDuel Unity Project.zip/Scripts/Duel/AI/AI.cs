﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using LGG;
using System.Linq;
using DG.Tweening;
using System;

namespace BD
{
	public class AI : LGBehaviour
	{
		protected Unit localUnit;

		public virtual Unit FindClosestVisibleEnemy()
		{
			List<Unit> unitsByDistance = GameManager.Instance.DuelManager.AllUnits.Where(u => u.Owner.ClientID != localUnit.Owner.ClientID && u.ActionState != Unit.ActionStates.Dead).OrderBy(x => Vector2.Distance(localUnit.transform.position, x.transform.position)).ToList();

			if (unitsByDistance.Count > 0)
			{
				for (int i = 0; i < unitsByDistance.Count; i++)
				{
					if (localUnit.AI.WithinRange(unitsByDistance[i]) && localUnit.AI.HasLineOfSight(unitsByDistance[i]))
					{
						return unitsByDistance[i];
					}
				}
			}

			return null;
		}

		public virtual Unit FindClosestVisibleAlly() {
			List<Unit> unitsByDistance = GameManager.Instance.DuelManager.AllUnits.Where(u => u.Owner.ClientID == localUnit.Owner.ClientID && u != localUnit && u.ActionState != Unit.ActionStates.Dead).OrderBy(x => Vector2.Distance(localUnit.transform.position, x.transform.position)).ToList();

			if (unitsByDistance.Count > 0)
			{
				for (int i = 0; i < unitsByDistance.Count; i++)
				{
					if (localUnit.AI.WithinRange(unitsByDistance[i]) && localUnit.AI.HasLineOfSight(unitsByDistance[i]))
					{
						return unitsByDistance[i];
					}
				}
			}

			return null;
		}

		public virtual bool HasLineOfSight(Unit target)
		{

			RaycastHit2D ray = Physics2D.Raycast((Vector2)localUnit.transform.position, (Vector2)target.transform.position - (Vector2)localUnit.transform.position, Vector2.Distance(localUnit.transform.position, target.transform.position), LayerMask.GetMask("Impassable"));

			if (ray.collider != null)
			{
				return false;
			}
			else
			{
				if (Vector3.Distance(target.transform.position, localUnit.transform.position) < localUnit.Weapon.Data.Range)
				{
					return true;
				}
				else
				{
					return false;
				}
			}
		}

		public virtual bool HasLineOfSight(Vector3 targetPos)
		{

			RaycastHit2D ray = Physics2D.Raycast((Vector2)localUnit.transform.position, (Vector2)targetPos - (Vector2)localUnit.transform.position, Vector2.Distance(localUnit.transform.position, targetPos), LayerMask.GetMask("Impassable"));

			if (ray.collider != null)
			{
				if (ray.collider.transform.parent.GetComponent<Destructible>() != null)
				{
					return true;
				}
				else
				{
					return false;
				}
			}
			else
			{
				if (Vector3.Distance(targetPos, localUnit.transform.position) < localUnit.Weapon.Data.Range)
				{
					return true;
				}
				else
				{
					return false;
				}
			}
		}

		public virtual bool WithinRange(Vector3 targetPos)
		{
			return (Vector3.Distance(localUnit.transform.position, targetPos) < localUnit.Data.WeaponData.Range);
		}

		public virtual bool WithinRange(Unit targetUnit)
		{
			return (Vector3.Distance(localUnit.transform.position, targetUnit.transform.position) < localUnit.Data.WeaponData.Range);
		}

		public virtual bool ValidateTargetType(Unit u)
		{
			if (u != null)
			{
				if (u.Owner != localUnit.Owner && localUnit.Weapon.Data.TargetTypes.Contains(DuelManager.TargetTypes.Enemy))
				{
					return true;
				}

				if (u.Owner == localUnit.Owner && (localUnit.Weapon.Data.TargetTypes.Contains(DuelManager.TargetTypes.Friendly)))
				{
					return true;
				}
			}

			return false;
		}


	}
}