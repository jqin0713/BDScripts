﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

namespace BD
{
    public class UnitAI : AI
    {
        public bool DisableAI;
		public bool TargetFriendly;

        protected override void Awake()
        {
            base.Awake();

            localUnit = GetComponent<Unit>();
        }

        protected override void Start()
        {
            base.Start();
            DisableAI = false;
			TargetFriendly = false;

            if (!GameManager.Instance.OnlineMatch && localUnit.Owner.ClientID != 1)
            {
                StartCoroutine(ShootRoutine());
            }
        }

        private void RevolverShoot(DuelManager.HitTypes ht, Unit enemy)
        {
            CircleCollider2D col;

            // CRIT
            if (ht == DuelManager.HitTypes.Crit)
            {
                col = enemy.critHitCircle;
            }

            // HIT
            else if (ht == DuelManager.HitTypes.Normal)
            {
                col = enemy.normHitCircle;
            }

            // GRAZE
            else
            {
                col = enemy.grazeHitCircle;
            }

            Vector3 dir = col.transform.position - localUnit.Hand.position;
            GameObject target = new GameObject("target");
            target.transform.position = col.transform.position;
            target.transform.LookAt(col.transform.position + dir);
            float offset = (col.radius * (Random.value < 0.5f ? -1f : 1f));
            target.transform.position += target.transform.up * offset;
            localUnit.Weapon.Shoot(target.transform.position);
        }

        private IEnumerator ShootRoutine()
		{
			while (GameManager.Instance.DuelManager.DuelActive)
			{
				Unit targetUnit = TargetFriendly ? FindClosestVisibleAlly() : FindClosestVisibleEnemy();
				//Debug.LogWarning ("TargetFriendly is " + TargetFriendly);

				//Debug.LogWarning("Target is" + (TargetFriendly ? " ally " : " enemy ") + (targetUnit == null ? " N/A " : targetUnit.Data.Key));

				if (targetUnit != null && localUnit.Ammo > 0)
				{
					switch (localUnit.Data.Key)
					{
					case "Marauder":
						if (!DisableAI)
						{
                            //localUnit.Weapon.Shoot(targetUnit.transform.position);
                            //localUnit.Weapon.Shoot (ShotDestination (targetUnit));
                            //localUnit.Weapon.Shoot(ShotDestination(targetUnit) + (Vector3)targetUnit.GetComponent<Rigidbody2D>().velocity.normalized * targetUnit.Data.Speed * (1.5f / Time.deltaTime));
							RevolverShoot(DuelManager.HitTypes.Graze, targetUnit);
						}
						yield return new WaitForSeconds(4f); //used to be 6.0f
						break;
					case "Digger":
						if (!DisableAI)
						{
							//localUnit.Weapon.Shoot(targetUnit.transform.position);
							Vector3 prediction = targetUnit.transform.position + (Vector3)targetUnit.GetComponent<Rigidbody2D>().velocity.normalized * targetUnit.Data.Speed * 3f;
							if (prediction.y < targetUnit.Lane.WalkPositions [targetUnit.Owner.ClientID - 1].position.y) {
								localUnit.Weapon.Shoot (prediction + new Vector3 (Random.value * 7f, Random.value * 7f, 0f));
							} else {
								localUnit.Weapon.Shoot (targetUnit.Lane.WalkPositions [targetUnit.Owner.ClientID - 1].position + new Vector3 (Random.value * 7f, Random.value * 7f, 0f));
							}
						}
						yield return new WaitForSeconds(4.5f); //used to be 8.5f
						break;
					case "Brigand":
						if (!DisableAI)
						{
							localUnit.Weapon.Shoot(targetUnit.transform.position);
							//localUnit.Weapon.Shoot(targetUnit.transform.position + (Vector3)targetUnit.GetComponent<Rigidbody2D>().velocity.normalized * targetUnit.Data.Speed * (2.5f / Time.deltaTime) + OffShoot());
							//yield return new WaitForSeconds(2.0f);
							yield return new WaitForSeconds ((targetUnit.transform.position - localUnit.transform.position).magnitude / 55f + 0.5f);
							localUnit.Weapon.Activate();
							yield return new WaitForSeconds(2.5f); //used to be 6.5f
						}
						yield return new WaitForSeconds(2.0f);
						break;
					}
				}
				else
				{
					yield return new WaitForSeconds(2f);
				}
			}
		}

		//Currently, this method returns a random vector inside the square in which the explosion circle is inscribed + error
		private Vector3 OffShoot()
		{
			float rng = Random.value;
			float inaccuracyChance = 0;

			switch (GameManager.Instance.Difficulty)
			{
			case GameManager.Difficulties.Easy:
				inaccuracyChance = GeneralDatabase.Instance.Get("EasyModeInaccuracyChance").FloatValue;
				break;
			case GameManager.Difficulties.Normal:
				inaccuracyChance = GeneralDatabase.Instance.Get("NormalModeInaccuracyChance").FloatValue;
				break;
			case GameManager.Difficulties.Hard:
				inaccuracyChance = GeneralDatabase.Instance.Get("HardModeInaccuracyChance").FloatValue;
				break;
			}

			return new Vector3(AlteredRange(inaccuracyChance), AlteredRange(inaccuracyChance), 0f);
		}

		//This method is only used for OffShoot in order to calculate the "extra range" to add to the randomizer
		private float AlteredRange(float inaccuracy) {
			if (localUnit.Weapon.Data.Key != "Dynamite" && localUnit.Weapon.Data.Key != "Barrel") {
				Debug.LogError ("This weapon is not of explosive type.");
				return 0f;
			}
			float rangeAddition = localUnit.Weapon.Data.Params [DuelManager.ParamTypes.ExplosionRange] * inaccuracy / (1 - inaccuracy);
			return Random.Range (-1 * localUnit.Weapon.Data.Params [DuelManager.ParamTypes.ExplosionRange] - rangeAddition/2, localUnit.Weapon.Data.Params [DuelManager.ParamTypes.ExplosionRange] + rangeAddition/2);
		}

		private Vector3 ShotDestination(Unit u)
		{
			float rng = Random.value;
			float clampedCriticalHitThreshold = 0f;
			float clampedNormalHitThreshold = 0f;
			float clampedGrazeThreshold = 0f;
			switch (GameManager.Instance.Difficulty)
			{
			case GameManager.Difficulties.Easy:
				clampedCriticalHitThreshold = Mathf.Clamp(GeneralDatabase.Instance.Get("BaseCriticalHitThreshold").FloatValue + GeneralDatabase.Instance.Get("EasyModeModifier").FloatValue, 0f, 1f);
				clampedNormalHitThreshold = Mathf.Clamp(GeneralDatabase.Instance.Get("BaseNormalHitThreshold").FloatValue + 2 * GeneralDatabase.Instance.Get("EasyModeModifier").FloatValue, clampedCriticalHitThreshold < 1f ? clampedCriticalHitThreshold : 1f, 1f);
				clampedGrazeThreshold = Mathf.Clamp(GeneralDatabase.Instance.Get("BaseGrazeThreshold").FloatValue + 2 * GeneralDatabase.Instance.Get("EasyModeModifier").FloatValue, clampedNormalHitThreshold < 1f ? clampedNormalHitThreshold : 1f, 1f);
				break;
			case GameManager.Difficulties.Normal:
				clampedCriticalHitThreshold = Mathf.Clamp(GeneralDatabase.Instance.Get("BaseCriticalHitThreshold").FloatValue + GeneralDatabase.Instance.Get("NormalModeModifier").FloatValue, 0f, 1f);
				clampedNormalHitThreshold = Mathf.Clamp(GeneralDatabase.Instance.Get("BaseNormalHitThreshold").FloatValue + 2 * GeneralDatabase.Instance.Get("NormalModeModifier").FloatValue, clampedCriticalHitThreshold < 1f ? clampedCriticalHitThreshold : 1f, 1f);
				clampedGrazeThreshold = Mathf.Clamp(GeneralDatabase.Instance.Get("BaseGrazeThreshold").FloatValue + 2 * GeneralDatabase.Instance.Get("NormalModeModifier").FloatValue, clampedNormalHitThreshold < 1f ? clampedNormalHitThreshold : 1f, 1f);
				break;
			case GameManager.Difficulties.Hard:
				clampedCriticalHitThreshold = Mathf.Clamp(GeneralDatabase.Instance.Get("BaseCriticalHitThreshold").FloatValue + GeneralDatabase.Instance.Get("HardModeModifier").FloatValue, 0f, 1f);
				clampedNormalHitThreshold = Mathf.Clamp(GeneralDatabase.Instance.Get("BaseNormalHitThreshold").FloatValue + 2 * GeneralDatabase.Instance.Get("HardModeModifier").FloatValue, clampedCriticalHitThreshold < 1f ? clampedCriticalHitThreshold : 1f, 1f);
				clampedGrazeThreshold = Mathf.Clamp(GeneralDatabase.Instance.Get("BaseGrazeThreshold").FloatValue + 2 * GeneralDatabase.Instance.Get("HardModeModifier").FloatValue, clampedNormalHitThreshold < 1f ? clampedNormalHitThreshold : 1f, 1f);
				break;
			}
			if (rng < clampedCriticalHitThreshold)
			{
				Debug.LogWarning ("Crit generated on " + u.Data.Key);
				return GenerateRandomCriticalHitPoint(u);
			}
			else if (rng < clampedNormalHitThreshold)
			{
				Debug.LogWarning ("Normal generated on " + u.Data.Key);
				return GenerateRandomNormalHitPoint(u);
			}
			else if (rng < clampedGrazeThreshold)
			{
				Debug.LogWarning ("Graze generated on " + u.Data.Key);
				return GenerateRandomGrazePoint(u);
			}
			Debug.LogWarning ("Miss generated on " + u.Data.Key);
			return GenerateRandomMiss(u);
		}

		private Vector3 GenerateRandomCriticalHitPoint(Unit u)
		{
			Vector3 fromHandToCenterOfTarget = (u.critHitCircle.transform.position - localUnit.Hand.transform.position);
			float critThresh = rotationToTangentPoint(u, "Critical");
			float angleToUse = 0.9f * Random.Range(0f, critThresh);
			float missWhatDirection = Random.value;
			return (missWhatDirection< 0.5f) ? localUnit.Hand.transform.position + rotateSomeRadiansIn2D(fromHandToCenterOfTarget, angleToUse) :
				localUnit.Hand.transform.position + rotateSomeRadiansIn2D(fromHandToCenterOfTarget, -1 * angleToUse);
		}

		private Vector3 GenerateRandomNormalHitPoint(Unit u)
		{

			Vector3 fromHandToCenterOfTarget = (u.critHitCircle.transform.position - localUnit.Hand.transform.position);
			float critThresh = 1.7f * rotationToTangentPoint(u, "Critical");
			//Debug.LogWarning ("Critical threshold is " + critThresh);
			float normalThresh = 0.9f * rotationToTangentPoint(u, "Normal");
			//Debug.LogWarning ("Normal threshold is " + normalThresh);
			float angleToUse = Random.Range(critThresh, normalThresh);
			//Debug.LogWarning ("Angle chosen for normal is " + angleToUse);
			//angleToUse = critThresh + 0.1f * (normalThresh - critThresh);
			float missWhatDirection = Random.value;
			return (missWhatDirection< 0.5f) ? localUnit.Hand.transform.position + rotateSomeRadiansIn2D(fromHandToCenterOfTarget, angleToUse) :
				localUnit.Hand.transform.position + rotateSomeRadiansIn2D(fromHandToCenterOfTarget, -1 * angleToUse);
		}

		private Vector3 GenerateRandomGrazePoint(Unit u)
		{
			Vector3 fromHandToCenterOfTarget = (u.critHitCircle.transform.position - localUnit.Hand.transform.position);
			float normalThresh = 1.5f * rotationToTangentPoint(u, "Normal");
			//Debug.LogWarning ("Normal threshold is " + normalThresh);
			float grazeThresh = 0.95f * rotationToTangentPoint(u, "Graze");
			//Debug.LogWarning ("Graze threshold is " + grazeThresh);
			float angleToUse = Random.Range(normalThresh, grazeThresh);
			//Debug.LogWarning ("Angle chosen for graze is " + angleToUse);
			//angleToUse = normalThresh + 0.5f * (grazeThresh - normalThresh);
			float missWhatDirection = Random.value;
			return (missWhatDirection < 0.5f) ? localUnit.Hand.transform.position + rotateSomeRadiansIn2D(fromHandToCenterOfTarget, angleToUse) :
				localUnit.Hand.transform.position + rotateSomeRadiansIn2D(fromHandToCenterOfTarget, -1 * angleToUse);
		}

		private Vector3 GenerateRandomMiss(Unit u)
		{
			Vector3 fromHandToCenterOfTarget = (u.critHitCircle.transform.position - localUnit.Hand.transform.position);
			float grazeThresh = 2.5f * rotationToTangentPoint(u, "Graze");
			float missWhatDirection = Random.value;
			return (missWhatDirection < 0.5f) ? localUnit.Hand.transform.position + rotateSomeRadiansIn2D(fromHandToCenterOfTarget, grazeThresh + Random.Range(0.1f, 0.2f)) :
				localUnit.Hand.transform.position + rotateSomeRadiansIn2D(fromHandToCenterOfTarget, -grazeThresh - Random.Range(0.1f, 0.2f));
		}

		private float rotationToTangentPoint(Unit u, string hitbox)
		{
			Vector3 fromHandToCenterOfTarget = u.critHitCircle.transform.position - localUnit.Hand.transform.position;
			float angle = 0f;
			switch (hitbox)
			{
			case "Critical":
				angle = Mathf.Abs(Mathf.Asin(u.critHitCircle.radius / Vector3.Magnitude(fromHandToCenterOfTarget)));
				break;
			case "Normal":
				angle = Mathf.Abs(Mathf.Asin(u.normHitCircle.radius / Vector3.Magnitude(fromHandToCenterOfTarget)));
				break;
			case "Graze":
				angle = Mathf.Abs(Mathf.Asin(u.grazeHitCircle.radius / Vector3.Magnitude(fromHandToCenterOfTarget)));
				break;
			}
			return angle;
		}

		private static Vector3 rotateSomeRadiansIn2D(Vector3 vec, float SomeRadians)
		{
			float cos = Mathf.Cos(SomeRadians);
			float sin = Mathf.Sin(SomeRadians);
			float newX = vec.x * cos - vec.y * sin;
			float newY = vec.x * sin + vec.y * cos;
			return new Vector3(newX, newY, 0f);
		}
	}
}
