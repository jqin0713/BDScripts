﻿using UnityEngine;
using System.Collections;
using LGG;

namespace BD
{
    public class SortByZPosition : LGBehaviour
    {
        [SerializeField] private bool setOnce;
        [SerializeField] private float offset;

        private Vector3 screenPosition;
        private Vector3 worldPosition;
        protected override void Update()
        {
            base.Update();
            RaycastHit hit;

            if (Physics.Raycast((Vector2)transform.position, Camera.main.transform.forward, out hit))
            {
                transform.position = new Vector3(hit.point.x, hit.point.y, hit.point.z - offset);
            }

            if (setOnce)
            {
                enabled = false;
            }
        }
    }
}