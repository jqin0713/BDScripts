﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using LGG;

namespace BD
{
    public class FootprintSpawner : LGBehaviour
    {
        [SerializeField]
        private GameObject footprintRightPrefab, footprintLeftPrefab;

        private Vector3 lastPos;
        private bool flip = false;
        private Unit localUnit;
        float minDist = 2.5f;

        protected override void Awake()
        {
            base.Awake();

            localUnit = GetComponent<Unit>();
        }

        protected override void Start()
        {
            base.Start();

            lastPos = transform.position;
        }

        void FixedUpdate()
        {
            if (((Vector2)lastPos - (Vector2)transform.position).magnitude < minDist - (localUnit.Data.Speed * 0.1f))
            {
                return;
            }

            lastPos = transform.position;
            GameObject footprint = Instantiate<GameObject>(flip ? footprintRightPrefab : footprintLeftPrefab);
            footprint.transform.position = transform.position;
            footprint.GetComponent<Footprint>().Set(localUnit.Facing, flip, localUnit);
            flip = !flip;
        }
    }
}