﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using LGG;

namespace BD
{
    public class Lane : MonoBehaviour
    {
        [SerializeField] private Image laneOverlay;

        public bool Occupied;
        public Transform[] SpawnPositions;
        public Transform[] WalkPositions;

        public void ShowOverlay(bool show)
        {
            laneOverlay.enabled = show;

            if (show)
            {
                if (!Occupied)
                {
                    laneOverlay.color = new Color(0.2f, 0.6f, 0.2f, 0.5f);
                }
                else
                {
                    laneOverlay.color = new Color(0.6f, 0.2f, 0.2f, 0.5f);
                }
            }
        }
    }
}