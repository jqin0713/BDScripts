﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;
using LGG;

namespace BD
{
    public class FloatingText : LGBehaviour
    {
        [SerializeField] private TextMeshPro text;

        private float duration;

        protected override void Awake()
        {
            base.Awake();

        }

        protected override void Start()
        {
            base.Start();

        }

        public void SetText(string s, DuelManager.HitTypes hitType, Unit localUnit)
        {
            //transform.SetParent(GameManager.Instance.DuelManager.FloatingTextRoot.transform);
            text.text = s + " " + hitType.ToString().ToUpper() + "!";
            Color color;

            switch (hitType)
            {
                case DuelManager.HitTypes.Crit:
                    color = Color.red;
                    break;
                case DuelManager.HitTypes.Normal:
                    color = new Color(1f, 0.6f, 0f, 1f);
                    break;
                case DuelManager.HitTypes.Graze:
                    color = Color.yellow;
                    break;
                default:
                    color = Color.black;
                    break;
            }

            text.color = color;
            StartCoroutine(FloatRoutine());
        }

        private IEnumerator FloatRoutine()
        {
            duration = GeneralDatabase.Instance.Get("FloatingTextDuration").FloatValue;
            float startTime = Time.time;
            float percent = 0f;

			while (percent < 1f)
            {
				if (Time.timeScale != 0) {
					percent = (Time.time - startTime) / duration;
					transform.position += new Vector3 (0f, 0.1f, 0f);

					if (percent > 0.75f) {
						text.color = new Color (text.color.r, text.color.g, text.color.b, 1f - ((percent - 0.75f) / 0.25f));
					}
				}

                yield return null;
            }

            Destroy(gameObject);
        }
    }
}