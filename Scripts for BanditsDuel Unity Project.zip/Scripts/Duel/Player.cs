using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.EventSystems;
using UnityEngine.Networking;
using System.Linq;
using LGG;
using UnityEngine.UI;
using TMPro;

namespace BD
{
	public class Player : LGNetworkBehaviour
	{
		public GameObject UnitsRoot;
		public GameObject FootprintsRoot;
		public GameObject WalkTargetMarkersRoot;
		public GameObject LinesRoot;
		public GameObject EffectsRoot;
		public GameObject WeaponObjectsRoot;

		//Pretty much the same as the healthBarFill inside Unit, but there's only one per player and the color is blue
		public GameObject MPBar;

		public static Player Authoritative { get; private set; }
		public int ClientID { get; private set; }
		public Dictionary<string, HeroInfo> Heroes { get; set; }


		private int mp;
		public int MP
		{
			get
			{
				return mp;
			}
			set
			{
				mp = (int)Mathf.Clamp(value, 0f, GameManager.Instance.DuelManager.TotalMPPerPlayer);
				UpdateMP();
			}
		}

		protected virtual void UpdateMP()
		{
			float percent = (float)mp / GameManager.Instance.DuelManager.TotalMPPerPlayer;
			MPBar.GetComponent<Image>().fillAmount = percent;
			MPBar.GetComponentInChildren<TextMeshProUGUI>().text = "MP: " + mp + " / " + GameManager.Instance.DuelManager.TotalMPPerPlayer;
			//Debug.LogWarning("Currently have " + mp + " MP out of 20");
		}

		public Player PlayerClone() {
			return (Player)this.MemberwiseClone ();
		}

		private int score;
		public int Score
		{
			get
			{
				return score;
			}
			set
			{
				score = value;

				if (!GameManager.Instance.OnlineMatch)
				{
					if (score == GameManager.Instance.TeamSize)
					{
						GameManager.Instance.DuelManager.EndDuel();
						GameManager.Instance.DuelManager.GameOverWindow.GameOver();
						GameManager.Instance.DuelManager.GameOverWindow.ShowWindow();
					}
				}
				else
				{
					if (score == GameManager.Instance.TeamSize)
					{
						if (GameManager.Instance.IsClient)
						{
							GameManager.Instance.DuelManager.EndDuel();
							GameManager.Instance.DuelManager.GameOverWindow.GameOver();
							GameManager.Instance.DuelManager.GameOverWindow.ShowWindow();
						}
						else if (GameManager.Instance.IsServer)
						{
							GameManager.Instance.DuelManager.EndDuel();
						}
					}
				}
			}
		}

		private int latency;
		public int Latency
		{
			get
			{
				return latency;
			}
			set
			{
				latency = value;
				GameManager.Instance.DuelManager.SetLatency(latency);
			}
		}

		private Unit unitPressed;

		public enum TapTypes
		{
			Press,
			Release
		}

		public class HeroInfo
		{
			public int Health;
			public int Ammo;
			public float Speed;

			public HeroInfo() { }

			public HeroInfo(HeroInfo info)
			{
				Health = info.Health;
				Ammo = info.Ammo;
				Speed = info.Speed;
			}
		}

		[Command]
		public void CmdAddHero(string key)
		{
			Player.HeroInfo info = new Player.HeroInfo();
			info.Health = HeroDatabase.Instance.Get(key).HP;
			info.Ammo = HeroDatabase.Instance.Get(key).WeaponData.StartingAmmo;
			info.Speed = HeroDatabase.Instance.Get(key).Speed;
			Heroes.Add(key, info);

			RpcAddHero(key);
		}

		[ClientRpc]
		private void RpcAddHero(string key)
		{
			if (hasAuthority) return;

			Player.HeroInfo info = new Player.HeroInfo();
			info.Health = HeroDatabase.Instance.Get(key).HP;
			info.Ammo = HeroDatabase.Instance.Get(key).WeaponData.StartingAmmo;
			info.Speed = HeroDatabase.Instance.Get(key).Speed;
			Heroes.Add(key, info);
		}

		[Command]
		public void CmdSpawnHero(string key, int laneIndex)
		{
			Lane currentLane = GameManager.Instance.DuelManager.lanes[laneIndex];
			Unit newUnit = Instantiate(GameObject.FindObjectOfType<GameServer>().spawnPrefabs[1]).GetComponent<Unit>();
			NetworkServer.SpawnWithClientAuthority(newUnit.gameObject, GameObject.FindObjectOfType<GameServer>().Conns[ClientID - 1]);
			newUnit.SetData(key, currentLane.SpawnPositions[ClientID - 1].position, ClientID, currentLane);
			newUnit.RpcSetData(key, currentLane.SpawnPositions[ClientID - 1].position, ClientID, laneIndex);
		}

		public void SetPlayerId(int id)
		{
			Heroes = new Dictionary<string, HeroInfo>();
			ClientID = id;
			name = string.Format("Player" + id);
			transform.SetParent(GameManager.Instance.DuelManager.PlayerRoot);

			if (id == 1)
			{
				if (!GameManager.Instance.OnlineMatch)
				{
					Authoritative = this;

					Messenger.AddListener<PointerEventData>(MessageEnum.OnClick, OnClick);
					Messenger.AddListener<PointerEventData>(MessageEnum.OnPress, OnPress);
					Messenger.AddListener<PointerEventData>(MessageEnum.OnRelease, OnRelease);
					Messenger.AddListener<Transform, PointerEventData>(MessageEnum.OnBeginDrag, OnBeginDrag);
					Messenger.AddListener<Transform, PointerEventData>(MessageEnum.OnDrag, OnDrag);
					Messenger.AddListener<Transform, PointerEventData>(MessageEnum.OnEndDrag, OnEndDrag);
				}

				GameManager.Instance.DuelManager.Player1 = this;
			}
			else if (id == 2)
			{
				GameManager.Instance.DuelManager.Player2 = this;
			}

			if (GameManager.Instance.IsClient && hasAuthority)
			{
				Authoritative = this;

				Messenger.AddListener<PointerEventData>(MessageEnum.OnClick, OnClick);
				Messenger.AddListener<PointerEventData>(MessageEnum.OnPress, OnPress);
				Messenger.AddListener<PointerEventData>(MessageEnum.OnRelease, OnRelease);
				Messenger.AddListener<Transform, PointerEventData>(MessageEnum.OnBeginDrag, OnBeginDrag);
				Messenger.AddListener<Transform, PointerEventData>(MessageEnum.OnDrag, OnDrag);
				Messenger.AddListener<Transform, PointerEventData>(MessageEnum.OnEndDrag, OnEndDrag);
			}
		}

		[ClientRpc]
		public void RpcSetPlayerID(int id)
		{
			SetPlayerId(id);
		}

		[Command]
		public void CmdResetGame()
		{
			GameManager.Instance.DuelManager.EndDuel();
			GameManager.Instance.DuelManager.RpcEndDuel();
			GameManager.Instance.DuelManager.StartDuel();
		}

		protected override void RemoveListeners()
		{
			base.RemoveListeners();

			if (Player.Authoritative == this)
			{
				Messenger.RemoveListener<PointerEventData>(MessageEnum.OnClick, OnClick);
				Messenger.RemoveListener<PointerEventData>(MessageEnum.OnPress, OnPress);
				Messenger.RemoveListener<PointerEventData>(MessageEnum.OnRelease, OnRelease);
				Messenger.RemoveListener<Transform, PointerEventData>(MessageEnum.OnBeginDrag, OnBeginDrag);
				Messenger.RemoveListener<Transform, PointerEventData>(MessageEnum.OnDrag, OnDrag);
				Messenger.RemoveListener<Transform, PointerEventData>(MessageEnum.OnEndDrag, OnEndDrag);
			}
		}

		// TAP
		private void OnPress(PointerEventData eventData)
		{
			if (!GameManager.Instance.DuelManager.DuelActive || !GameManager.Instance.DuelManager.Action()) return;

			Hashtable data = new Hashtable();

			if (eventData.pointerCurrentRaycast.gameObject.CompareTag("Hero"))
			{
				unitPressed = eventData.pointerCurrentRaycast.gameObject.transform.parent.GetComponent<Unit>();

				if (unitPressed.Owner == this)
				{
					

					unitPressed.Weapon.Use(data, TapTypes.Press);

				}
			}
		}

		public void OnRelease(PointerEventData eventData)
		{
			if (!GameManager.Instance.DuelManager.DuelActive || !GameManager.Instance.DuelManager.Action()) return;

			//Debug.LogWarning ("Release registered");

			Hashtable data = new Hashtable();

			Vector3 targetPos = eventData.pointerCurrentRaycast.screenPosition;
			RaycastHit hit;
			Physics.Raycast(GameManager.Instance.DuelManager.MainCamera.ScreenPointToRay(targetPos), out hit, 1000f, LayerMask.GetMask("Background"));
			data["targetUnit"] = null;
			data["targetPos"] = hit.point;

			if (unitPressed != null) {
				if (eventData.pointerCurrentRaycast.gameObject.transform.parent.GetComponent<Unit>() == unitPressed) {
					foreach (Unit u in GameManager.Instance.DuelManager.AllUnits.Where(x => x.Owner == this)) {
						if (u.SuperWindow.gameObject.activeSelf) {
							u.SuperWindow.ToggleWindowActive ();
						}
					}
					unitPressed.SuperWindow.ToggleWindowActive ();
				}
				unitPressed.Weapon.Use (data, TapTypes.Release);
				unitPressed = null;
			} else {
				foreach (Unit u in GameManager.Instance.DuelManager.AllUnits.Where(x => x.Owner == this)) {
					if (u.SuperWindow.gameObject.activeSelf) {
						u.SuperWindow.ToggleWindowActive ();
					}
				}
			}
		}

		private void OnClick(PointerEventData eventData)
		{
			
		}

		// DRAG
		private void OnBeginDrag(Transform t, PointerEventData eventData)
		{
			if (!GameManager.Instance.DuelManager.DuelActive) return;

			OnDrag(t, eventData);
		}

		private void OnDrag(Transform t, PointerEventData eventData)
		{
			if (!GameManager.Instance.DuelManager.DuelActive) return;

		}

		private void OnEndDrag(Transform t, PointerEventData eventData)
		{
			if (!GameManager.Instance.DuelManager.DuelActive) return;

		}
	}
}