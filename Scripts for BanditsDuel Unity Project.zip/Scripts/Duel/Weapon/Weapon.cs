﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using LGG;
using UnityEngine.UI;
using DG.Tweening;
using Spine.Unity;
using UnityEngine.Networking;

namespace BD
{
    public abstract class Weapon : LGNetworkBehaviour
    {
        public SkeletonAnimation Exclamation;
		public MeshRenderer ExclamationRenderer;
        public WeaponData Data;
        public Coroutine UseRoutine;
        public Coroutine ActivateRoutine;
        public bool Holding;

        protected Unit localUnit;
        protected Vector3 origin;
        protected Vector3 target;

        private Coroutine exclamationRoutine;

		public bool EnableFriendlyFire;

		public List<Super> Enhancements;

        public Weapon()
        {

        }

        public virtual void Initialize(Unit unit, string key)
        {
            localUnit = unit;
            Data = WeaponDatabase.Instance.Get(key);
			ExclamationRenderer.enabled = false;
			Enhancements = new List<Super> ();
        }

        public virtual void Use(Hashtable args, Player.TapTypes tapType)
        {
            if (tapType == Player.TapTypes.Press)
            {
                Press(args);
            }
            else if (tapType == Player.TapTypes.Release)
            {
                Release(args);
            }
        }

        protected virtual void Press(Hashtable args)
        {

        }

        protected virtual void Release(Hashtable args)
        {
            target = (Vector3)args["targetPos"];
            Holding = false;
        }
        
		//Here, a check will be made for any Weapon enhancements (i.e. AttackEnhancers) that only apply through the next attack. 
        public virtual void Shoot(Vector3 target)
        {
			foreach (Super s in Enhancements) {
				if (s.DurationType == Super.DurationTypes.After_Next_Ally_Attack) {
					((AttackEnhancer)s).MarkedForDestruction = true;
				}
			}
            localUnit.Ammo--;
        }

        protected virtual void Shoot2(Vector3 target)
        {

        }

        public virtual void Activate()
        {
            
        }

        protected void AnimateExlamation()
        {
			ExclamationRenderer.enabled = true;
            Exclamation.state.ClearTracks();
            Exclamation.state.SetAnimation(0, "PUMP UP", false);
            Exclamation.timeScale = 1f;
            AudioManager.Instance.PlaySound("ui_equip_item");

            if (exclamationRoutine != null)
            {
				StopCoroutine (exclamationRoutine);
			}

			exclamationRoutine = StartCoroutine (AnimateExclamationRoutine());
        }

		private IEnumerator AnimateExclamationRoutine()
		{
			yield return new WaitForSeconds(0.667f);

			ExclamationRenderer.enabled = false;
			exclamationRoutine = null;
		}

        protected virtual void SetActionButtonAnimation(string animation, bool loop, float timeScale, float startTime = 0f)
        {
            localUnit.ActionButton.ActionAnimation.state.ClearTracks();
            localUnit.ActionButton.ActionAnimation.state.SetAnimation(0, animation, loop).time = startTime;
            localUnit.ActionButton.ActionAnimation.timeScale = timeScale;
        }
    }
}