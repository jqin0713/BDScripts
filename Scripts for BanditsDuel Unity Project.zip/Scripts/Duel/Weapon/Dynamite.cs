﻿using UnityEngine;
using System.Collections;
using UnityEngine.Networking;
using System.Collections.Generic;
using DG.Tweening;
using Spine.Unity;
using System.Linq;
using LGG;

namespace BD
{
	public class Dynamite : LGBehaviour
	{
		[SerializeField]
		private SkeletonAnimation skeletonAnimation;
		[SerializeField]
		private CircleCollider2D circleCollider;

		public Unit localUnit;
		private int damage;
		private Rigidbody2D dynamiteRigidbody;
		private List<Unit> collidingUnits;
		private List<Destructible> collidingDestructibles;

		public bool Redo;

		protected override void Awake()
		{
			collidingUnits = new List<Unit>();
			collidingDestructibles = new List<Destructible>();
			dynamiteRigidbody = GetComponent<Rigidbody2D>();
			Redo = false;
		}
			
		public void Throw(Vector3 target, Unit localUnit)
		{
			this.localUnit = localUnit;
			damage = localUnit.Weapon.Data.Params[DuelManager.ParamTypes.Damage];
			transform.SetParent(localUnit.Owner.WeaponObjectsRoot.transform);
			transform.position = localUnit.Hand.transform.position;
			circleCollider.radius = localUnit.Weapon.Data.Params[DuelManager.ParamTypes.ExplosionRange] / transform.localScale.x;

			skeletonAnimation.state.ClearTracks();
			skeletonAnimation.state.SetAnimation(0, "DynamiteThrow", false);
			skeletonAnimation.timeScale = 1f;

			transform.DOMove(target, 1.0f).SetSpeedBased(false);
			StartCoroutine(ThrowRoutine());
		}

		//The following two methods will be used extensively to check for various enhancements on weapons.
		//Although systematic application was considered, manual interpretation of the ORDER of the enhancements
		//is important to ensure that the enhancements combine usefulness appropriately
		private bool HasEnhancement(string enhancement)
		{
			return localUnit.Weapon.Enhancements.Exists(x => x.SuperName == enhancement);
		}
		private Super GetEnhancement(string enhancement)
		{
			return localUnit.Weapon.Enhancements.Find(x => x.SuperName == enhancement);
		}

		public void RemoveEnhancement(string enhancement)
		{
			if (!HasEnhancement(enhancement))
			{
				Debug.LogWarning("Trying to remove enhancement with name " + enhancement + ", which currently does not exist for this Dynamite");
				return;
			}
			localUnit.Weapon.Enhancements.Remove(GetEnhancement(enhancement));
		}

		//New plan: Use the above methods and change various variables (like delay and damage) in the appropriate order
		public IEnumerator ThrowRoutine()
		{
			yield return StartCoroutine(ThrowButDontDestroy());
			Destroy(gameObject);
		}

		private IEnumerator ThrowButDontDestroy()
		{
			Redo = false;

			yield return new WaitForSeconds(1.3f);

			skeletonAnimation.state.ClearTracks();
			skeletonAnimation.state.SetAnimation(0, "FuseBurning", true);
			skeletonAnimation.timeScale = 3f;

			yield return new WaitForSeconds(0.833f);

			skeletonAnimation.state.ClearTracks();
			skeletonAnimation.state.SetAnimation(0, "DynamiteExplosion", true);
			skeletonAnimation.timeScale = 1f;

			AudioManager.Instance.PlaySound("sfx_dynamite_explode");

			List<Unit> unitsHit = new List<Unit>();

			foreach (Unit u in collidingUnits)
			{
				if ((u.Owner != localUnit.Owner || localUnit.Weapon.EnableFriendlyFire || GameManager.Instance.FriendlyFireException) && !unitsHit.Contains(u))
				{
					DuelManager.HitTypes ht;
					int damage = localUnit.Weapon.Data.Params[DuelManager.ParamTypes.Damage];

					int colCount = 0;

					for (int i = 0; i < collidingUnits.Count; i++)
					{
						if (collidingUnits[i] == u)
						{
							colCount++;
						}
					}

					if (colCount == 3)
					{
						ht = DuelManager.HitTypes.Crit;
						damage *= 2;
					}
					else if (colCount == 2)
					{
						ht = DuelManager.HitTypes.Normal;
						damage *= 1;
					}
					else // if (colCount == 1)
					{
						ht = DuelManager.HitTypes.Graze;
						damage /= 2;
					}

					if (u != null)
					{
						foreach (Super s in localUnit.Weapon.Enhancements) {
							
							((AttackEnhancer)s).Hit (u, ref damage, ref ht);
						}
						u.KnockDown (damage, ht);
						unitsHit.Add(u);
					}
				}
			}

			foreach (Destructible d in collidingDestructibles)
			{
				if (d != null)
				{
					d.Hit(0.15f);
				}
			}

			foreach (Super s in localUnit.Weapon.Enhancements) {
				((AttackEnhancer)s).GenerateFieldEffect (transform.position);
			}
			if (Redo) {
				for (int i = 0; i < localUnit.Weapon.Enhancements.Count; i++) {
					if (!((AttackEnhancer)localUnit.Weapon.Enhancements [i]).MarkedForDestruction) {
						localUnit.Weapon.Enhancements.RemoveAt (i);
						i--;
					}
				}
				transform.Translate(new Vector3(0f, 0f, 20f));
				yield return new WaitForSeconds(0.5f);
				skeletonAnimation.state.ClearTracks();
				skeletonAnimation.skeleton.SetToSetupPose ();
				skeletonAnimation.state.SetAnimation(0, "DynamiteThrow", false);
				skeletonAnimation.timeScale = 1.5f;
				transform.DOMove(transform.position, 1.0f).SetSpeedBased(false);
				yield return StartCoroutine (ThrowButDontDestroy ());
			} else {
				for (int i = 0; i < localUnit.Weapon.Enhancements.Count; i++) {
					if (((AttackEnhancer)localUnit.Weapon.Enhancements [i]).MarkedForDestruction) {
						localUnit.Weapon.Enhancements.RemoveAt (i);
						i--;
					}
				}
			}



			yield return new WaitForSeconds(0.867f);
		}

		private void OnTriggerEnter2D(Collider2D other)
		{
			if (other.gameObject.layer == LayerMask.NameToLayer("Hero"))
			{
				Unit otherUnit = other.GetComponentInParent<Unit>();
				collidingUnits.Add(otherUnit);
			}
			else if (other.CompareTag("Destructible"))
			{
				collidingDestructibles.Add(other.transform.parent.GetComponent<Destructible>());
			}
		}

		private void OnTriggerExit2D(Collider2D other)
		{
			if (other.gameObject.layer == LayerMask.NameToLayer("Hero"))
			{
				Unit otherUnit = other.GetComponentInParent<Unit>();
				collidingUnits.Remove(otherUnit);
			}
			else if (other.CompareTag("Destructible"))
			{
				collidingDestructibles.Remove(other.transform.parent.GetComponent<Destructible>());
			}
		}
	}
}

