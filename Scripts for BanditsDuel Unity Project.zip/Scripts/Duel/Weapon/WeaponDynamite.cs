﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using LGG;
using UnityEngine.UI;
using Spine.Unity;
using UnityEngine.Networking;

namespace BD
{
    public class WeaponDynamite : Weapon
    {
        public WeaponDynamite() : base()
        {

        }

        public override void Initialize(Unit unit, string key)
        {
            base.Initialize(unit, key);

        }

        protected override void Press(Hashtable args)
        {
            base.Press(args);

            Holding = true;

            if (localUnit.Ammo <= 0)
            {
                AnimateExlamation();
                return;
            }

            origin = localUnit.transform.position;
            UseRoutine = StartCoroutine(DynamiteUseRoutine());
        }

        private IEnumerator DynamiteUseRoutine()
        {
            float startTime = Time.time;

            while (Holding)
            {
                yield return null;
            }

            if (Time.time - startTime < 0.5f && Vector3.Distance(origin, target) > 20f)
            {
                if (GameManager.Instance.DuelManager.PlacementPhase)
                {
                    AnimateExlamation();
                    UseRoutine = null;
                    yield break;
                }

                float distBasedOnTime = 1f - ((Time.time - startTime) / 0.5f);
                float distBasedOnDist = Mathf.Min(1f, ((target - origin).magnitude / (Data.Range * 1.3f)));
                float avg = (distBasedOnDist + distBasedOnTime) / 2f;

                Vector3 dir = target - origin;
                target = origin + (dir.normalized * Data.Range * avg * 1.3f);

                Shoot(target);

                if (GameManager.Instance.OnlineMatch)
                {
                    CmdShoot(target);
                }
            }

            UseRoutine = null;
        }

        [Command]
        private void CmdShoot(Vector3 target)
        {
            Shoot(target);
            RpcShoot(target);
        }

        [ClientRpc]
        private void RpcShoot(Vector3 target)
        {
            if (hasAuthority) return;

            Shoot(target);
        }

        public override void Shoot(Vector3 target)
        {
            base.Shoot(target);

            Dynamite dynamite = Instantiate(GameManager.Instance.DynamitePrefab).GetComponent<Dynamite>();
			foreach (Super s in Enhancements)
			{
				((AttackEnhancer)s).Projectile = dynamite.gameObject;
			}

            dynamite.Throw(target, localUnit);

            localUnit.StopWalking(false, false);
            localUnit.SetDirection(localUnit.CalculateDirection(target));
            localUnit.SetAnimation("itemGet", false, 1f);
            AudioManager.Instance.PlaySound("sfx_anim_throw1");
            localUnit.StartWalking(1.667f);
        }
    }
}