﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using LGG;
using UnityEngine.Networking;
using UnityEngine.EventSystems;
using Spine.Unity;
using System.Linq;

namespace BD
{
    public class WeaponRevolver : Weapon
    {
        private Coroutine shootAnimRoutine;
        public int lastReloadAmmoCount;
		public int damage;

        public WeaponRevolver() : base()
        {

        }

        public override void Initialize(Unit unit, string key)
        {
            base.Initialize(unit, key);

            lastReloadAmmoCount = localUnit.Ammo;

			//Potentially will be buffed
			damage = WeaponDatabase.Instance.Get("Revolver").Params[DuelManager.ParamTypes.Damage];
        }

        protected override void Press(Hashtable args)
        {
            base.Press(args);

            Holding = true;

            if (ActivateRoutine != null) return;

            if (GameManager.Instance.DuelManager.PlacementPhase)
            {
                AnimateExlamation();
                return;
            }

            if (localUnit.Ammo <= 0 || lastReloadAmmoCount - localUnit.Ammo == 3)
            {
                //SetActionButtonAnimation("REFILL WARNING", false, 1f);
                AnimateExlamation();
                return;
            }

            UseRoutine = StartCoroutine(ShootRoutine());
        }

        private IEnumerator ShootRoutine()
        {
            origin = localUnit.transform.position;
            float startTime = Time.time;

            while (Holding)
            {
                yield return null;
            }


            if (Time.time - startTime < 0.5f && Vector3.Distance(origin, target) > 20f)
            {
                Vector3 dir = target - origin;
                target = origin + (dir.normalized * Data.Range);
                Shoot(target);

                if (GameManager.Instance.OnlineMatch)
                {
                    CmdShoot(target);
                }

                //localUnit.ActionButton.ToggleActionAnimation(true);

                //if (shootAnimRoutine != null)
                //{
                    //StopCoroutine(shootAnimRoutine);
                //}

                //shootAnimRoutine = StartCoroutine(ShootAnimRoutine());
            }

            UseRoutine = null;
        }

        [Command]
        private void CmdShoot(Vector3 target)
        {
            Shoot(target);
            RpcShoot(target);
        }

        [ClientRpc]
        private void RpcShoot(Vector3 target)
        {
            if (hasAuthority) return;

            Shoot(target);
        }

        public override void Shoot(Vector3 target)
        {
            base.Shoot(target);
            
            Unit targetUnit = null;
            RaycastHit2D[] rays = Physics2D.RaycastAll((Vector2)localUnit.transform.position, (Vector2)target - (Vector2)localUnit.transform.position, Data.Range, LayerMask.GetMask("Hero", "Impassable")).OrderBy(x => Vector2.Distance(localUnit.transform.position, x.transform.position)).ToArray();

            for (int i = 0; i < rays.Length; i++)
            {
                if (rays[i].collider.transform.gameObject.layer == LayerMask.NameToLayer("Impassable"))
                {
                    target = rays[i].point;
					//Debug.LogWarning ("Hit impassable object");
                    break;
                }
				else if (rays[i].collider.transform.GetComponentInParent<Unit>() != null && rays[i].collider.transform.GetComponentInParent<Unit>() != localUnit && (rays[i].collider.transform.GetComponentInParent<Unit>().Owner != localUnit.Owner || localUnit.Weapon.EnableFriendlyFire || GameManager.Instance.FriendlyFireException))
                {
                    targetUnit = rays[i].collider.transform.GetComponentInParent<Unit>();
                    break;
                }
            }

            DuelManager.HitTypes hitType = DuelManager.HitTypes.Miss;

			int dmg = 0;

            if (targetUnit != null)
            {
                List<RaycastHit2D> raysList = rays.ToList().Where(rh => rh.collider.transform.GetComponentInParent<Unit>() == targetUnit).ToList();
				dmg = damage;
				if (raysList.Count == 3) {
					target = raysList.SingleOrDefault (rh => rh.collider.gameObject.CompareTag ("Crit")).point;
					dmg *= 2;
					hitType = DuelManager.HitTypes.Crit;
				} else if (raysList.Count == 2) {
					target = raysList.SingleOrDefault (rh => rh.collider.gameObject.CompareTag ("Normal")).point;
					dmg *= 1;
					hitType = DuelManager.HitTypes.Normal;
				} else if (raysList.Count == 1) {
					target = raysList.SingleOrDefault (rh => rh.collider.gameObject.CompareTag ("Graze")).point;
					dmg /= 2;
					hitType = DuelManager.HitTypes.Graze;
				} 
            }

            ShootBullet(target, dmg, hitType, targetUnit);
            localUnit.StopWalking(false, false);
            localUnit.SetDirection(localUnit.CalculateDirection(target));
            localUnit.SetAnimation("shoot", false, 1f);
            AudioManager.Instance.PlaySound("sfx_pistol_shot1");
            localUnit.StartWalking(1.167f);
        }

        private IEnumerator ShootAnimRoutine()
        {
            //localUnit.ActionButton.ActionAnimation.state.ClearTracks();
            float bulletsMissing = lastReloadAmmoCount - localUnit.Ammo;
            //SetActionButtonAnimation("SHOOT", false, 1f, ((bulletsMissing - 1f) / 3f) * 1.9f);

            yield return new WaitForSeconds(0.633f);

            //localUnit.ActionButton.ActionAnimation.timeScale = 0f;

            if (bulletsMissing == 3)
            {
                //SetActionButtonAnimation("REFILL WARNING", false, 1f);
            }
        }

        public override void Activate()
        {
            if (ActivateRoutine != null) return;

            if (localUnit.Ammo <= 0)
            {
                //SetActionButtonAnimation("REFILL WARNING", false, 1f);
                AnimateExlamation();
                return;
            }

            if (shootAnimRoutine != null)
            {
                StopCoroutine(shootAnimRoutine);
            }

            ActivateRoutine = StartCoroutine(ReloadReoutine());
        }

        private IEnumerator ReloadReoutine()
        {
            //localUnit.ActionButton.ActionAnimation.skeleton.SetToSetupPose();
            //SetActionButtonAnimation("REFILL", false, 1f);

            yield return new WaitForSeconds(1.2f);

            if (localUnit.Ammo < 3)
            {
                int FIX_THIS_MESS_LATER = 3 - localUnit.Ammo;
                //SetActionButtonAnimation("SHOOT", false, 0f, ((float)FIX_THIS_MESS_LATER / 3f) * 1.9f);
                lastReloadAmmoCount = localUnit.Ammo + (int)(FIX_THIS_MESS_LATER);
            }
            else
            {
                lastReloadAmmoCount = localUnit.Ammo;
            }
            
            //localUnit.ActionButton.ToggleActionAnimation(false);
            ActivateRoutine = null;
        }

        private void ShootBullet(Vector3 targetPos, int dmg, DuelManager.HitTypes ht, Unit targetUnit = null)
        {
            StartCoroutine(BulletRoutine(targetPos, dmg, ht, targetUnit));
        }


		//The type of bullet will be determined by any AttackEnhancers applied
        private IEnumerator BulletRoutine(Vector3 targetPos, int dmg, DuelManager.HitTypes ht, Unit targetUnit)
        {
            float startTime = Time.time;
            float percent = 0f;

            GameObject bullet = GameObject.Instantiate(GameManager.Instance.BulletPrefab, localUnit.Owner.WeaponObjectsRoot.transform);
			foreach (Super s in Enhancements)
			{
				((AttackEnhancer)s).Projectile = bullet;
			}

            Vector3 startPos = localUnit.Hand.transform.position;
            bullet.transform.position = startPos;

            float AngleRad = Mathf.Atan2(bullet.transform.position.y - targetPos.y, bullet.transform.position.x - targetPos.x);
            float AngleDeg = (180 / Mathf.PI) * AngleRad;
            bullet.transform.rotation = Quaternion.Euler(0, 0, AngleDeg);
            /*
            LineRenderer line;
            line = new GameObject().AddComponent<LineRenderer>();
            line.material = GameManager.Instance.LineMaterialPrefab;
            line.numPositions = 2;
            line.startColor = Color.gray;
            line.endColor = Color.gray;
            line.startWidth = 0.2f;
            line.endWidth = 0.2f;
            line.useWorldSpace = true;
            line.name = ("RevolverSmokeTrail");
            line.transform.SetParent(localUnit.Owner.LinesRoot.transform, true);
            line.SetPosition(0, new Vector3(localUnit.Hand.transform.position.x, localUnit.Hand.transform.position.y, 50f));
            line.SetPosition(1, new Vector3(targetPos.x, targetPos.y, 50f));
            */

            bullet.GetComponentInChildren<SkeletonAnimation>().timeScale = 3.25f;
            while (percent < 1.0f)
            {
                percent = (Time.time - startTime) / 0.6f;
                bullet.transform.position = Vector3.Lerp(startPos, targetPos, percent);
                
                //Color newColor = new Color(0.5f, 0.5f, 0.5f, 1.0f - percent);
                //line.startColor = newColor;
                //line.endColor = newColor;

                yield return new WaitForFixedUpdate();
            }

            if (targetUnit != null)
            {
				foreach (Super s in localUnit.Weapon.Enhancements) {
					((AttackEnhancer)s).Hit (targetUnit, ref dmg, ref ht);
				}
                targetUnit.TakeDamage(dmg, ht);
            }

			foreach (Super s in localUnit.Weapon.Enhancements) {
				((AttackEnhancer)s).GenerateFieldEffect (transform.position);
			}

			for (int i = 0; i < localUnit.Weapon.Enhancements.Count; i++) {
				if (((AttackEnhancer)localUnit.Weapon.Enhancements [i]).MarkedForDestruction) {
					localUnit.Weapon.Enhancements.RemoveAt (i);
					i--;
				}
			}

            yield return new WaitForSeconds(0.3f);

            Destroy(bullet.gameObject);
            //Destroy(line.gameObject);
        }
    }
}