﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using LGG;
using UnityEngine.UI;
using System.Linq;
using DG.Tweening;
using Spine.Unity;
using UnityEngine.Networking;

namespace BD
{
    public class WeaponBarrel : Weapon
    {
        public List<Barrel> Barrels;
        public Barrel currentBarrel;
        private int barrelIndex = 0;
		private bool barrelSet;
		private bool activateCalled;
		private bool earlyExplosion;

        public WeaponBarrel() : base()
        {

        }

        public override void Initialize(Unit unit, string key)
        {
            base.Initialize(unit, key);
			barrelSet = false;
			activateCalled = false;
			earlyExplosion = false;
            Barrels = new List<Barrel>();
        }

        protected override void Press(Hashtable args)
        {
            base.Press(args);

            Holding = true;

            if (localUnit.Ammo <= 0 || Barrels.Count >= GeneralDatabase.Instance.Get("MaxBarrels").IntValue || currentBarrel != null)
            {
                AnimateExlamation();
                return;
            }

            origin = localUnit.transform.position;
            UseRoutine = StartCoroutine(BarrelUseRoutine());
        }

        private IEnumerator BarrelUseRoutine()
        {
            float startTime = Time.time;

            while (Holding)
            {
                yield return null;
            }

            if (Time.time - startTime < 0.5f && Vector3.Distance(origin, target) > 20f)
            {
                if (GameManager.Instance.DuelManager.PlacementPhase)
                {
                    AnimateExlamation();
                    UseRoutine = null;
                    yield break;
                }

                float distBasedOnTime = 1f - ((Time.time - startTime) / 0.5f);
                float distBasedOnDist = Mathf.Min(1f, ((target - origin).magnitude / (Data.Range * 1.3f)));
                float avg = (distBasedOnDist + distBasedOnTime) / 2f;

                Vector3 dir = target - origin;
                target = origin + (dir.normalized * Data.Range * avg * 1.3f);

                Shoot(target);

                if (GameManager.Instance.OnlineMatch)
                {
                    CmdShoot(target);
                }
            }

            UseRoutine = null;
        }

        [Command]
        private void CmdShoot(Vector3 target)
        {
            Shoot(target);
            RpcShoot(target);
        }

        [ClientRpc]
        private void RpcShoot(Vector3 target)
        {
            if (hasAuthority) return;

            Shoot(target);
        }

        public override void Shoot(Vector3 target)
        {
            base.Shoot(target);
			activateCalled = false;
            StartCoroutine(SpawnBarrelRoutine(target));
        }

        public IEnumerator SpawnBarrelRoutine(Vector3 target)
        {
            origin = localUnit.transform.position;
            localUnit.StopWalking(false, false);
            localUnit.ActionState = Unit.ActionStates.Shooting;
            localUnit.SetAnimation("itemGet", false, 1f);
            AudioManager.Instance.PlaySound("sfx_anim_throw1");
            localUnit.StartWalking(1.667f);
            localUnit.SetDirection(localUnit.CalculateDirection(target));

            currentBarrel = Instantiate(GameManager.Instance.BarrelPrefab).GetComponent<Barrel>();
			foreach (Super s in Enhancements)
			{
				((AttackEnhancer)s).Projectile = currentBarrel.gameObject;
			}

            currentBarrel.transform.position = localUnit.transform.position + ((target - localUnit.transform.position).normalized * 6f);
            currentBarrel.transform.SetParent(localUnit.Owner.WeaponObjectsRoot.transform);



            currentBarrel.SetGhostBarrel(localUnit, this, localUnit.CalculateDirection(target));
            Barrels.Add(currentBarrel);
            currentBarrel.Index = barrelIndex;
            barrelIndex++;
            currentBarrel.GetComponent<Rigidbody2D>().velocity = (target - localUnit.transform.position).normalized * 55f;
			Debug.LogWarning ("current velocity is " + currentBarrel.GetComponent<Rigidbody2D> ().velocity);

            
			if (localUnit.Owner == Player.Authoritative)
			{
				currentBarrel.SkeletonAnimation.skeleton.SetColor(new Color(GameManager.Instance.HomeColor.r, GameManager.Instance.HomeColor.g, GameManager.Instance.HomeColor.b, 1f));
			}
			else
			{
				currentBarrel.SkeletonAnimation.skeleton.SetColor(new Color(GameManager.Instance.AwayColor.r, GameManager.Instance.AwayColor.g, GameManager.Instance.AwayColor.b, 1f));
			}


			if (localUnit.Owner == Player.Authoritative)
			{
				localUnit.ActionButton.ToggleActionAnimation(true);
				currentBarrel.SetBarrel ();
				currentBarrel.GetComponent<SpriteRenderer> ().enabled = false;
				barrelSet = true;
				currentBarrel.AnimationRenderer.enabled = true;
				currentBarrel.spawnCollider.enabled = true;
				currentBarrel.Spawned = false;

			}


			Debug.LogWarning ("Origin was at " + origin);

			while (currentBarrel.GetComponent<Rigidbody2D> ().velocity != Vector2.zero && Vector3.Distance (currentBarrel.transform.position, origin) < Data.Range * 0.9f) {
				yield return null;
				if (activateCalled) {
					earlyExplosion = true;
					break;
				}
			}

			Vector3 stopPos = currentBarrel.transform.position;
			//RaycastHit2D hit = Physics2D.GetRayIntersection(GameManager.Instance.DuelManager.MainCamera.ScreenPointToRay(GameManager.Instance.DuelManager.MainCamera.WorldToScreenPoint(stopPos)), 1000f, LayerMask.GetMask("Ground"));

			//if (hit.collider != null)
			{
				//stopPos = new Vector3(hit.collider.transform.position.x, hit.collider.transform.position.y + 0.5f, hit.collider.transform.position.z);
			}

			Debug.LogWarning(" and the barrel stopped at " + stopPos + " while the target position was " + target);

			Shoot2 (stopPos);
        }

        protected override void Shoot2(Vector3 spawnPos)
        {
            base.Shoot2(spawnPos);

            currentBarrel.GetComponent<Rigidbody2D>().velocity = Vector2.zero;
            currentBarrel.GetComponent<Rigidbody2D>().constraints = RigidbodyConstraints2D.FreezePosition | RigidbodyConstraints2D.FreezeRotation;
			if (!barrelSet) {
				currentBarrel.SetBarrel ();
			} else {
				currentBarrel.AnimationRenderer.enabled = false;
				currentBarrel.spawnCollider.enabled = false;
				currentBarrel.Spawned = true;
				if (!earlyExplosion) {
					currentBarrel.GetComponent<SpriteRenderer> ().enabled = true;
				}
			}
            currentBarrel.transform.position = spawnPos;
            currentBarrel.transform.SetParent(localUnit.Owner.WeaponObjectsRoot.transform);

            if (localUnit.Owner == Player.Authoritative)
            {
                localUnit.ActionButton.ToggleActionAnimation(true);
            }
            
            if (localUnit.Owner == Player.Authoritative)
            {
                currentBarrel.GetComponent<SpriteRenderer>().color = GameManager.Instance.HomeColor;
            }
            else
            {
                currentBarrel.GetComponent<SpriteRenderer>().color = GameManager.Instance.AwayColor;
            }

            currentBarrel = null;
        }

        public override void Activate()
        {
            base.Activate();
			activateCalled = true;
            if (localUnit.Owner == Player.Authoritative)
            {
                ActivateRoutine = StartCoroutine(ActivationRoutine());
            }

            List<Barrel> toBeRemoved = new List<Barrel>();

            foreach (Barrel b in Barrels)
            {
				if (true)
                {
                    b.Hit();
                    CmdHit(b.Index);
                    toBeRemoved.Add(b);
                }
            }

            foreach (Barrel b in toBeRemoved)
            {
                Barrels.Remove(b);
            }
        }

        [Command]
        private void CmdHit(int index)
        {
            foreach (Barrel b in Barrels)
            {
                if (b.Index == index)
                {
                    b.Hit();
                    break;
                }
            }

            RpcHit(index);
        }

        [ClientRpc]
        private void RpcHit(int index)
        {
            if (hasAuthority) return;

            foreach (Barrel b in Barrels)
            {
                if (b.Index == index)
                {
                    b.Hit();
                    break;
                }
            }
        }

        private IEnumerator ActivationRoutine()
        {
            SetActionButtonAnimation("Detonating", false, 1);

            yield return new WaitForSeconds(1.333f);

            if (localUnit.Owner == Player.Authoritative && Barrels.Count == 0)
            {
                localUnit.ActionButton.ToggleActionAnimation(false);
            }

            ActivateRoutine = null;
        }
    }
}