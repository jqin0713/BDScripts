﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using LGG;
using System.Linq;
using Spine.Unity;

namespace BD
{
    public class Barrel : Destructible
    {
        [SerializeField] public BoxCollider2D spawnCollider;
        [SerializeField] public BoxCollider2D posCollider;
        [SerializeField] private CircleCollider2D explodeCollider;

        public SkeletonAnimation SkeletonAnimation;
        public MeshRenderer AnimationRenderer;

        public Unit LocalUnit;
        public bool Spawned;
        private WeaponBarrel localWeapon;
        private Vector3 origin;

        public int Index;

        private List<Unit> collidingUnits;

        protected override void Start()
        {
            base.Start();
            
        }

        public void SetGhostBarrel(Unit u, WeaponBarrel w, Unit.Directions dir)
        {
            LocalUnit = u;
            localWeapon = w;
            Spawned = false;
            origin = transform.position;

            SkeletonAnimation.state.ClearTracks();
            SkeletonAnimation.state.SetAnimation(0, "Rolling", true);

            switch (dir)
            {
                case Unit.Directions.Forward:
                    SkeletonAnimation.timeScale = 1f;
                    break;
                case Unit.Directions.Backward:
                    SkeletonAnimation.timeScale = -1f;
                    break;
                case Unit.Directions.Left:
                    SkeletonAnimation.gameObject.transform.localScale = new Vector3(-0.4f, 0.4f, 1f);
                    SkeletonAnimation.timeScale = 1f;
                    break;
                case Unit.Directions.Right:
                    SkeletonAnimation.gameObject.transform.localScale = new Vector3(-0.4f, 0.4f, 1f);
                    SkeletonAnimation.timeScale = -1f;
                    break;
            }

            spawnCollider.enabled = true;
        }

        public void SetBarrel()
        {
            GameManager.Instance.DuelManager.AllDestructibles.Add(this);
            AnimationRenderer.enabled = false;
            GetComponent<SpriteRenderer>().enabled = true;

            spawnCollider.enabled = false;
            posCollider.enabled = true;
            explodeCollider.radius = LocalUnit.Weapon.Data.Params[DuelManager.ParamTypes.ExplosionRange] / transform.localScale.x;
            explodeCollider.enabled = true;
            collidingUnits = new List<Unit>();
            Spawned = true;
        }

        public override void Hit(float delay = 0f)
        {
            if (HitRecieved) return;

            base.Hit(delay);

            Explode(delay);
        }

        private void Explode(float delay)
        {
            posCollider.enabled = false;
            StartCoroutine(ExplodeRoutine(delay));
        }

        private IEnumerator ExplodeRoutine(float delay)
        {
            while (!Spawned)
            {
                yield return null;
            }

            yield return new WaitForSeconds(delay);

            float explodeRange = LocalUnit.Weapon.Data.Params[DuelManager.ParamTypes.ExplosionRange];

            yield return null;

            List<Unit> unitsHit = new List<Unit>();

            foreach (Unit u in collidingUnits)
            {
				if ((u.Owner != LocalUnit.Owner || LocalUnit.Weapon.EnableFriendlyFire || GameManager.Instance.FriendlyFireException) && !unitsHit.Contains(u))
                {
                    DuelManager.HitTypes ht;
                    int damage = LocalUnit.Weapon.Data.Params[DuelManager.ParamTypes.Damage];

                    int colCount = 0;

                    for (int i = 0; i < collidingUnits.Count; i++)
                    {
                        if (collidingUnits[i] == u)
                        {
                            colCount++;
                        }
                    }

                    if (colCount == 3)
                    {
                        ht = DuelManager.HitTypes.Crit;
                        damage *= 2;
                    }
                    else if (colCount == 2)
                    {
                        ht = DuelManager.HitTypes.Normal;
                        damage *= 1;
                    }
                    else // if (colCount == 1)
                    {
                        ht = DuelManager.HitTypes.Graze;
                        damage /= 2;
                    }

                    if (u != null)
                    {
						foreach (Super s in LocalUnit.Weapon.Enhancements) {
							((AttackEnhancer)s).Hit (u, ref damage, ref ht);
						}
                        u.KnockDown(damage, ht);
                        unitsHit.Add(u);
                    }

					foreach (Super s in LocalUnit.Weapon.Enhancements) {
						((AttackEnhancer)s).GenerateFieldEffect (transform.position);
					}

					for (int i = 0; i < LocalUnit.Weapon.Enhancements.Count; i++) {
						if (((AttackEnhancer)LocalUnit.Weapon.Enhancements [i]).MarkedForDestruction) {
							LocalUnit.Weapon.Enhancements.RemoveAt (i);
							i--;
						}
					}
                }
            }

            foreach (Destructible d in GameManager.Instance.DuelManager.AllDestructibles)
            {
               if (Vector3.Distance(this.transform.position, d.transform.position) < explodeRange)
                {
                    if (d != null)
                    {
                        d.Hit(0.15f);
                    }
                }
            }

            AudioManager.Instance.PlaySound("sfx_dynamite_explode");

            GameObject explosion = Instantiate(GameManager.Instance.DuelEffectDefaultPrefab);
            explosion.transform.position = new Vector3(transform.position.x, transform.position.y + 3f, transform.position.z - 2f);
            explosion.transform.localScale = Vector3.one;
            explosion.transform.SetParent(LocalUnit.Owner.EffectsRoot.transform);
            SkeletonAnimation skeletonAnimation = explosion.GetComponent<SkeletonAnimation>();
            skeletonAnimation.state.ClearTracks();
            skeletonAnimation.state.SetAnimation(0, "bombotExplode", false);
            skeletonAnimation.timeScale = 1f;

            GetComponent<SpriteRenderer>().enabled = false;

            yield return new WaitForSeconds(1.867f);

            if (LocalUnit != null)
            {
                WeaponBarrel wb = LocalUnit.GetComponent<WeaponBarrel>();

                if (wb.Barrels.Contains(this))
                {
                    wb.Barrels.Remove(this);

                    if (wb.Barrels.Count == 0 && LocalUnit.Owner == Player.Authoritative)
                    {
                        LocalUnit.ActionButton.ToggleActionAnimation(false);
                    }
                }
            }

            GameManager.Instance.DuelManager.AllDestructibles.Remove(this);
            Destroy(explosion.gameObject);
            Destroy(gameObject);
        }

        private void OnTriggerEnter2D(Collider2D other)
        {
            if (!Spawned)
            {
                if (other.transform.gameObject.layer == LayerMask.NameToLayer("Impassable"))
                {
					Debug.LogWarning ("Impassable barrel proc");
                    GetComponent<Rigidbody2D>().velocity = Vector2.zero;
                    GetComponent<Rigidbody2D>().constraints = RigidbodyConstraints2D.FreezePosition | RigidbodyConstraints2D.FreezeRotation;
                }
				else if (other.gameObject.layer == LayerMask.NameToLayer("UnitPositionCollider") && other.GetComponentInParent<Unit>() != LocalUnit && (other.GetComponentInParent<Unit>().Owner != LocalUnit.Owner || LocalUnit.Weapon.EnableFriendlyFire || GameManager.Instance.FriendlyFireException))
                {
					Debug.LogWarning ("Entering the collider of " + LocalUnit.Data.Key + " caused this barrel to stop ");
                    GetComponent<Rigidbody2D>().velocity = Vector2.zero;
                    GetComponent<Rigidbody2D>().constraints = RigidbodyConstraints2D.FreezePosition | RigidbodyConstraints2D.FreezeRotation;
                }
            }


            
            
                if (other.gameObject.layer == LayerMask.NameToLayer("Hero"))
                {
                    Unit otherUnit = other.GetComponentInParent<Unit>();
                    collidingUnits.Add(otherUnit);
                }
            
        }

        private void OnTriggerExit2D(Collider2D other)
        {
            if (Spawned)
            {
                if (other.gameObject.layer == LayerMask.NameToLayer("Hero"))
                {
                    Unit otherUnit = other.GetComponentInParent<Unit>();
                    collidingUnits.Remove(otherUnit);
                }
            }
        }
    }
}