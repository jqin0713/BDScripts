﻿using UnityEngine;
using System.Linq;

namespace BD
{
	public class Confusion : Debuff
	{
		private float confuseChance;

		public Confusion() {
			confuseChance = EffectAmounts [0];
		}

		public override void ActuallyApplySpecs (string specification)
		{
			confuseChance = float.Parse (specification.Trim ());
		}

		public override void Proc ()
		{			
			if (MarkedForRemoval) {
				return;
			} else if (EffectFrequencyTimeTracker >= EffectDuration) {
				MarkedForRemoval = true;
				AffectedUnit.Weapon.EnableFriendlyFire = false;
				AffectedUnit.AI.TargetFriendly = false;
			} else {
				if (!GameManager.Instance.OnlineMatch) {
					if (EffectFrequencyTimeTracker >= EffectFrequencyProcPoints) {
						//Debug.LogWarning ("Confusion procced and confuse chance is " + confuseChance);
						AffectedUnit.Weapon.EnableFriendlyFire = true;
						float rng = Random.value;
						if (rng < confuseChance) {
							AffectedUnit.AI.TargetFriendly = true;
							//Debug.LogWarning ("Should've changed TargetFriendly");
						} else {
							AffectedUnit.AI.TargetFriendly = false;
						}
						EffectFrequencyTimeTracker += Time.deltaTime;
						EffectFrequencyProcPoints += EffectFrequency;
					} else {
						EffectFrequencyTimeTracker += Time.deltaTime;
					}
				}
			}
		}


	}
}

