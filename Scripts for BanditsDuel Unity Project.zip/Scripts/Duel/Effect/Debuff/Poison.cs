﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using LGG;
using UnityEngine.UI;
using System.Linq;
using DG.Tweening;
using Spine.Unity;
using UnityEngine.Networking;

namespace BD
{
	public class Poison : Debuff
	{
		private float damagePerProc;
		private float slowDownAmount;

		//Notice that the base constructor inside Effect is automatically called first so these values will already have
		//their defaults available
		public Poison() {
			damagePerProc = EffectAmounts [0];
			slowDownAmount = EffectAmounts [1];
		}

		public override void ActuallyApplySpecs (string specification)
		{
			string[] specifications = specification.Split(',');
			damagePerProc = float.Parse(specifications [0].Trim ());
			slowDownAmount = float.Parse(specifications [1].Trim ());
		}

		public override void Proc ()
		{
			//Can be manually set inside Unit to account for the DeadRoutine (specifically, to make sure that there aren't any "hits" post-death that would
			//add unfairly to the score counter)
			if (MarkedForRemoval)
			{
				return;
			}
			else if (EffectFrequencyTimeTracker >= EffectDuration) {
				MarkedForRemoval = true;
				AffectedUnit.Speed = HeroDatabase.Instance.Get (AffectedUnit.Data.Key).Speed;
			} //The following else block also works for zero-frequency debuffs, which will proc every frame. A zero-frequency debuff may
			//be used as a part of dev tools, since it'll pretty much kill an enemy instantly (albeit in a fancy manner)
			else {
				if (EffectFrequencyTimeTracker >= EffectFrequencyProcPoints)
				{
					AffectedUnit.TakeDamageFromDebuff((int)damagePerProc * StackTier);
					AffectedUnit.Speed = HeroDatabase.Instance.Get (AffectedUnit.Data.Key).Speed * Mathf.Pow(slowDownAmount, StackTier);
					EffectFrequencyTimeTracker += Time.deltaTime;
					EffectFrequencyProcPoints += EffectFrequency;
				}
				else
				{
					EffectFrequencyTimeTracker += Time.deltaTime;
				}
			}

		}
	}
}
