﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using LGG;
using UnityEngine.UI;
using System.Linq;
using DG.Tweening;
using Spine.Unity;
using UnityEngine.Networking;
using System;
using System.Text.RegularExpressions;


namespace BD
{
	public class Effect : IEquatable<Effect>
	{
		//This is necessary due to the possibility of supers having "Specifications"
		public Super AssociatedSuper;

		public string EffectName;

		public enum EffectDurationTypes { After_Next_Successful_Enemy_Attack, Rest_Of_Match, Set_Duration, Dependent }
		public EffectDurationTypes EffectDurationType;
		public float EffectDuration;

		//The meaning of this variable varies for different skills. For example, for a healing skill, this might be the amount healed;
		//for a poisoning skill, this might be the DoT; for a confusion skill, this might be the chance that the confusion procs
		public float[] EffectAmounts;

		//For certain effects, this value is set to 0 to denote that it should occur every frame; otherwise, it will happen every
		//EffectFrequency second
		public float EffectFrequency;

		protected float EffectFrequencyProcPoints;
		protected float EffectFrequencyTimeTracker;

		//This dictates the total number of stacks that is allowed for a single debuff. For most DoT skills, the limit will be 3; stacking will
		//apply more DoT and perhaps extend duration. Some effects, like confusion, will only be allowed to stack once.
		public int StackLimit = 1;
		//This is a counter denoting the current number of stacks of a certain effect; it should never exceed StackLimit
		public int StackTier = 1;

		//An effect CAN affect mutliple units at the same time (i.e. in the case that it originates from an AOE super), but in that case, the effect
		//is duplicated and distributed among the various units. As such, each effect is only bound to a single unit
		public Unit AffectedUnit;

		public string TypeOfEffect;

		//After an effect's lifetime ends, this bool is set to true so that DuelManager can know when to remove the effect from the Unit
		public bool MarkedForRemoval;

		public Effect() {
			EffectName = Regex.Replace (this.GetType ().Name, "([A-Z])(?![A-Z])", " $1").Trim();

			EffectDurationType = EffectDatabase.Instance.Get (EffectName).EffectDurationType;
			EffectDuration = (EffectDurationType == Effect.EffectDurationTypes.Dependent) ? ObtainDependentDuration () : EffectDatabase.Instance.Get (EffectName).EffectDuration;

			EffectAmounts = EffectDatabase.Instance.Get (EffectName).EffectAmounts;

			EffectFrequency = EffectDatabase.Instance.Get (EffectName).EffectFrequency;
			EffectFrequencyProcPoints = 0f;
			EffectFrequencyTimeTracker = 0f;

			StackLimit = EffectDatabase.Instance.Get (EffectName).StackLimit;

			TypeOfEffect = EffectDatabase.Instance.Get (EffectName).TypeOfEffect;
		}

		//Currently empty, but will be updated to visually display the effect on the affected unit
		public virtual void Apply()
		{
			
		}

		public void ApplySpecifications(string specification)
		{
			if (specification.Equals("_")) {
				return;
			}
			ActuallyApplySpecs(specification);
		}

		public virtual void ActuallyApplySpecs(string specification)
		{
		}

		//Relatively simple method, created to save time on typing
		public bool CanStack() {
			return StackTier < StackLimit;
		}

		//This method should only be called if this.Equals(e) and if the StackLimit has not been reached yet;
		public void Stack(Effect e) {
			if (!this.Equals (e) || !CanStack()) {
				return;
			}
			StackTier++;
			EffectFrequencyTimeTracker = 0f;
			EffectFrequencyProcPoints = 0f;
		}

		//Even if an effect can't be stacked further, this method is called to reset the timer upon encountering such a scenario
		public void ResetTimer() {
			EffectFrequencyTimeTracker = 0f;
			EffectFrequencyProcPoints = 0f;
		}

		//Hiding the IEquatable equality method
		public bool Equals (Effect e) {
			return this.Equals((object)e);
		}

		//This method assumes polymorphism, which should always be the case due to the way that Super is coded;
		//As for the purpose of this method, it is used to determine whether two effects should be allowed to stack
		public override bool Equals (object obj)
		{
			if (obj == null) {
				return false;
			}
			if (this.GetType () == obj.GetType ()) {
				return Enumerable.SequenceEqual (this.EffectAmounts, ((Effect)obj).EffectAmounts);
			}
			return false;
		}

		//This method is specifically used for Dependent duration types
		public virtual float ObtainDependentDuration() {
			return 0f;
		}

		//By far the most important method, this is what is called to "affect" the unit
		public virtual void Proc() {
		}


	}
}

