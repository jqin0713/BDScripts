﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using LGG;

namespace BD
{
    public class Destructible : LGBehaviour
    {
        [SerializeField] private SpriteRenderer sr;

        public bool HitRecieved = false;
        public bool Visible;

        private int visibleCount;

        public virtual void Hit(float delay = 0f)
        {
            HitRecieved = true;
        }

        public virtual void SetVisible(bool visible)
        {
            if (visible)
            {
                if (visibleCount == 0)
                {
                    sr.enabled = true;
                    this.Visible = true;
                }

                visibleCount++;
            }
            else
            {
                visibleCount--;

                if (visibleCount <= 0)
                {
                    sr.enabled = false;
                    this.Visible = false;
                    visibleCount = 0;
                }
            }
        }
    }
}
