﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using LGG;

namespace BD
{
    public class Footprint : LGBehaviour
    {
        [SerializeField] private SpriteRenderer sprite;

        private float startTime;
        private float fadeTime;

        protected override void Start()
        {
            startTime = Time.time;
            fadeTime = GeneralDatabase.Instance.Get("FootprintFadeTime").FloatValue;

        }

        public void Set(Unit.Directions dir, bool flip, Unit localUnit)
        {
            gameObject.transform.SetParent(localUnit.Owner.FootprintsRoot.transform);
            gameObject.transform.localScale = new Vector3(0.3f, 0.3f, 1f);
            float rot = 0f;

            switch (dir)
            {
                case Unit.Directions.Forward:
                    rot = 315f;
                    break;
                case Unit.Directions.Backward:
                    rot = 135f;
                    break;
                case Unit.Directions.Left:
                    rot = 45f;
                    break;
                case Unit.Directions.Right:
                    rot = 225f;
                    break;
            }

            transform.eulerAngles = new Vector3(53f, 0f, rot);

            if (flip)
            {
                transform.localPosition = new Vector3(transform.localPosition.x - 2.8f, transform.localPosition.y, transform.localPosition.z);
            }
            else
            {
                transform.localPosition = new Vector3(transform.localPosition.x + 2.2f, transform.localPosition.y, transform.localPosition.z);
            }
        }

        void FixedUpdate()
        {
            if (Time.time - startTime >= fadeTime)
            {
                Destroy(gameObject);
            }

            sprite.color = new Color(1f, 1f, 1f, 0.5f - (Time.time - startTime) / fadeTime / 2f);
        }
    }
}