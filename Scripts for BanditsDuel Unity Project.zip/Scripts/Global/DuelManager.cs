﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using LGG;
using UnityEngine.EventSystems;
using System.Linq;
using UnityEngine.UI;
using UnityEngine.Networking;
using TMPro;
using System;

namespace BD
{
	public class DuelManager : LGNetworkBehaviour
	{
		[SerializeField]
		private TextMeshProUGUI player1ScoreText, player2ScoreText, countdownText, latencyText;
		[SerializeField]
		private GameObject playerPrefab;
		[SerializeField]
		private GameObject unitPrefab;
		[SerializeField]
		public Lane[] lanes;
		[SerializeField]
		private SpawnWindow spawnWindow;
		[SerializeField]
		private ActionWindow actionWindow;

		public GameObject SuperSelectionWindowPrefab;
		//Pops up during the action phase of the duel whenever a player is selected
		public GameObject SuperWindowPrefab;
		public GameObject SupersConfirmationButton;
		public GameObject UnitPrefab { get { return unitPrefab; } }
		public GameObject MPBarPrefab;

		public Transform PlayerRoot;
		public AstarPath aStar;
		public Player Player1;
		public Player Player2;

		//The following three variables are used for TimePiercer
		public Player PastPlayer1;
		public Player PastPlayer2;
		public List<Unit> PastAllUnits;

		public bool DuelActive;
		public bool Initializing;
		public Transform TilesRoot;
		public Transform SuperSelectWindowRoot;
		public Transform SuperWindowRoot;
		public Transform MPBarRoot;
		public DuelOptionsWindow DuelOptionsWindow;
		public Camera MainCamera;
		public Camera UICamera;
		public List<Unit> AllUnits;
		public List<Destructible> AllDestructibles;
		public bool SuperSelectionPhase;
		public bool PlacementPhase;

		public int TotalMPPerPlayer;
		public int MPRegainPerSecond;

		private float lastMPGain;

		//Alternates upon selecting different Spawn Cards
		public SuperSelectionWindow ActiveSSWindow;

		public float CacheTime;

		public List<FieldEffect> FieldEffects;



		public GameOverWindow GameOverWindow;

		private Coroutine superSelectionRoutine, placementRoutine, walkAndShootRoutine;

		public enum TargetTypes
		{
			Enemy,
			Friendly
		}

		public enum ParamTypes
		{
			Damage,
			Heal,
			Speed,
			Duration,
			ExplosionRange
		}

		public enum HitTypes
		{
			Miss,
			Graze,
			Normal,
			Crit,
			Debuff
		}

		protected override void Awake()
		{
			base.Awake();

			GameManager.Instance.SetDuelManager(this);
		}

		protected override void Start()
		{
			base.Start();
			TotalMPPerPlayer = GeneralDatabase.Instance.Get("TotalMP").IntValue;
			MPRegainPerSecond = GeneralDatabase.Instance.Get("MPRegainPerSecond").IntValue;
			CacheTime = float.Parse (SuperDatabase.Instance.Get ("Time Piercer").FieldEffectSpecifications[0]);
			InitializeDuel();
		}

		protected override void Update()
		{
			base.Update();

			if (walkAndShootRoutine != null)
			{
				foreach (FieldEffect FE in FieldEffects)
				{
					FE.LifeTime += Time.deltaTime;
					if (FE.LifeTime > FE.SetDuration)
					{
						FE.Destroy();
					}
				}
			}
		}

		public void SetLatency(int l)
		{
			latencyText.text = l.ToString();
		}

		public void InitializeDuel()
		{
			Initializing = true;
			StartCoroutine(Scan());
		}

		private IEnumerator Scan()
		{
			yield return null;
			aStar.Scan();

			while (aStar.isScanning)
			{
				yield return null;
			}

			yield return null;

			Initializing = false;

			if (!GameManager.Instance.OnlineMatch)
			{
				Player1 = Instantiate(playerPrefab).GetComponent<Player>();

				Player2 = Instantiate(playerPrefab).GetComponent<Player>();
				Player1.SetPlayerId(1);
				Player2.SetPlayerId(2);
				StartDuel();
			}
			else if (isServer)
			{
				MainCamera.orthographicSize = 80f;

				foreach (Transform t in MainCamera.transform)
				{
					t.GetComponent<Camera>().orthographicSize = 80f;
				}
			}
		}

		public void StartDuel()
		{
			Player1.Score = Player2.Score = 0;
			Player1.MPBar = Instantiate(GameManager.Instance.DuelManager.MPBarPrefab);
			Player1.MPBar.transform.SetParent(MPBarRoot);
			Player1.MPBar.transform.localScale = new Vector3(1f, 1f, 1f);
			Player1.MPBar.transform.localPosition = new Vector3(-321f, 341f, 0f);
			Player1.MP = 0;
			UpdateScore();
			DuelActive = true;
			AllDestructibles = new List<Destructible>();
			FieldEffects = new List<FieldEffect>();
			SupersConfirmationButton.gameObject.SetActive(false);



			if (GameManager.Instance.OnlineMatch)
			{
				if (GameManager.Instance.IsServer)
				{
					RpcStartDuel();
					superSelectionRoutine = StartCoroutine(SuperSelectionRoutine());
					RpcStartPlacement();
				}
				else if (GameManager.Instance.IsClient)
				{
					GameOverWindow.HideWindow();



					if (DuelOptionsWindow.gameObject.activeSelf)
					{
						DuelOptionsWindow.ToggleWindowActive();
					}

					for (int i = 0; i < GameManager.Instance.TeamList.Count; i++)
					{
						string key = GameManager.Instance.TeamList[i];
						Player.HeroInfo info = new Player.HeroInfo();
						info.Health = HeroDatabase.Instance.Get(GameManager.Instance.TeamList[i]).HP;
						info.Ammo = HeroDatabase.Instance.Get(GameManager.Instance.TeamList[i]).WeaponData.StartingAmmo;
						info.Speed = HeroDatabase.Instance.Get(GameManager.Instance.TeamList[i]).Speed;
						Player.Authoritative.Heroes.Add(key, info);
						Player.Authoritative.CmdAddHero(key);
					}
				}
			}
			else
			{
				GameOverWindow.HideWindow();

				if (DuelOptionsWindow.gameObject.activeSelf)
				{
					DuelOptionsWindow.ToggleWindowActive();
				}

				//Debug.LogWarning ("Current teamlist size is " + GameManager.Instance.TeamList.Count);

				for (int i = 0; i < GameManager.Instance.TeamList.Count; i++)
				{
					string key = GameManager.Instance.TeamList[i];
					Player.HeroInfo info = new Player.HeroInfo();
					info.Health = HeroDatabase.Instance.Get(GameManager.Instance.TeamList[i]).HP;
					info.Ammo = HeroDatabase.Instance.Get(GameManager.Instance.TeamList[i]).WeaponData.StartingAmmo;
					info.Speed = HeroDatabase.Instance.Get(GameManager.Instance.TeamList[i]).Speed;
					Player1.Heroes.Add(key, info);
					Player2.Heroes.Add(key, new Player.HeroInfo(info));
				}


				superSelectionRoutine = StartCoroutine(SuperSelectionRoutine());
				//placementRoutine = StartCoroutine(PlacementRoutine());
			}
		}

		[ClientRpc]
		private void RpcStartDuel()
		{
			StartDuel();
		}

		[ClientRpc]
		public void RpcEndDuel()
		{
			EndDuel();
		}

		public void EndDuel()
		{
			DuelActive = false;



			foreach (Unit u in AllUnits)
			{
				if (u != null)
				{

					Destroy(u.gameObject);
				}
			}

			foreach (Destructible d in AllDestructibles)
			{
				if (d != null)
					Destroy(d.gameObject);
			}


			for (int i = 0; i < lanes.Length; i++)
			{
				lanes[i].Occupied = false;
			}

			if (superSelectionRoutine != null) {
				StopCoroutine (superSelectionRoutine);
			}

			if (placementRoutine != null)
			{
				StopCoroutine(placementRoutine);
			}

			if (walkAndShootRoutine != null)
			{
				StopCoroutine(walkAndShootRoutine);
			}

			Player1.Heroes = new Dictionary<string, Player.HeroInfo>();
			Player1.MPBar.SetActive(false);
			Player2.Heroes = new Dictionary<string, Player.HeroInfo>();

			if (!GameManager.Instance.IsServer)
			{
				actionWindow.ResetWindow();
				actionWindow.gameObject.SetActive(false);
			}

			countdownText.gameObject.SetActive(false);
		}

		public void ResetDuel()
		{
			if (GameManager.Instance.IsClient)
			{
				Player.Authoritative.CmdResetGame();
			}
			else
			{
				EndDuel();

				if (GameManager.Instance.IsServer)
				{
					RpcEndDuel();
				}

				StartDuel();
			}
		}

		[ClientRpc]
		private void RpcStartPlacement()
		{
			foreach (Destructible d in AllDestructibles)
			{
				d.Hit();
			}

			foreach (Unit u in AllUnits)
			{
				if (u != null)
				{
					Destroy(u.gameObject);
				}
			}

			actionWindow.ResetWindow();
			actionWindow.gameObject.SetActive(false);

			if (walkAndShootRoutine != null)
			{
				StopCoroutine(walkAndShootRoutine);
				walkAndShootRoutine = null;
			}

			placementRoutine = StartCoroutine(PlacementRoutine());
		}


		//Shortcut method to see if the Duel is currently in the action phase, i.e. if it's not in the super selection phase or the placement phase
		public bool Action()
		{
			return !PlacementPhase && !SuperSelectionPhase;
		}


		//The first routine that happens
		private IEnumerator SuperSelectionRoutine()
		{
			AllUnits = new List<Unit>();
			PastAllUnits = new List<Unit> ();

			Player1.MPBar.SetActive(false);

			if (!GameManager.Instance.IsServer)
			{
				countdownText.gameObject.SetActive(false);

				for (int i = 0; i < lanes.Length; i++)
				{
					lanes[i].Occupied = false;
				}

				SuperSelectionPhase = true;
				Vector3 startPos = MainCamera.transform.position;
				float startTime = Time.time;
				float percent = 0f;

				while (percent < 1f)
				{
					yield return null;

					if (Player.Authoritative.ClientID == 1)
					{
						MainCamera.transform.position = Vector3.Lerp(startPos, new Vector3(-64f, -32f, 0f), percent);
					}
					else
					{
						MainCamera.transform.position = Vector3.Lerp(startPos, new Vector3(64f, 42f, 0f), percent);
					}

					percent = Time.time - startTime;
				}
			}
			else
			{
				yield return new WaitForSeconds(2f);
			}

			SupersConfirmationButton.gameObject.SetActive(true);

			if (!GameManager.Instance.IsServer)
			{
				spawnWindow.SetSpawnCards();
			}

			//Super selection phase is ended externally after a button confirming that the player has finished selecting his supers is pressed
			while (SuperSelectionPhase)
			{
				yield return null;
			}

			SupersConfirmationButton.gameObject.SetActive(false);
			if (ActiveSSWindow != null)
			{
				ActiveSSWindow.gameObject.SetActive(false);
			}

			placementRoutine = StartCoroutine(PlacementRoutine());
			superSelectionRoutine = null;
		}

		private IEnumerator PlacementRoutine()
		{
			/*AllUnits = new List<Unit>();

            if (!GameManager.Instance.IsServer)
            {
                countdownText.gameObject.SetActive(false);

                for (int i = 0; i < lanes.Length; i++)
                {
                    lanes[i].Occupied = false;
                }

                PlacementPhase = true;
                Vector3 startPos = MainCamera.transform.position;
                float startTime = Time.time;
                float percent = 0f;

                while (percent < 1f)
                {
                    yield return null;

                    if (Player.Authoritative.ClientID == 1)
                    {
                        MainCamera.transform.position = Vector3.Lerp(startPos, new Vector3(-64f, -32f, 0f), percent);
                    }
                    else
                    {
                        MainCamera.transform.position = Vector3.Lerp(startPos, new Vector3(64f, 42f, 0f), percent);
                    }
                    
                    percent = Time.time - startTime;
                }
            }
            else
            {
                yield return new WaitForSeconds(2f);
            }*/

			PlacementPhase = true;

			if (!GameManager.Instance.OnlineMatch)
			{
				List<Lane> lanesCopy = new List<Lane>(lanes.ToList());

				foreach (string key in Player2.Heroes.Keys)
				{
					int rand = (int)UnityEngine.Random.Range(0f, lanesCopy.Count);
					Unit newUnit = Instantiate(unitPrefab).GetComponent<Unit>();
					newUnit.SetData(key, lanesCopy[rand].SpawnPositions[1].position, 2, lanesCopy[rand]);
					lanesCopy.RemoveAt(rand);
				}
			}

			/*if (!GameManager.Instance.IsServer)
            {
                spawnWindow.SetSpawnCards();
            }*/

			while (AllUnits.Count < Player1.Heroes.Count + Player2.Heroes.Count)
			{
				yield return null;
			}

			if (!GameManager.Instance.IsServer)
			{
				spawnWindow.gameObject.SetActive(false);
			}

			PlacementPhase = false;
			walkAndShootRoutine = StartCoroutine(WalkAndShootRoutine());
			placementRoutine = null;
		}

		//This is where debuffs will be applied, decreasing in total life-span with every update but only activating
		//upon the specified interval, via calls to someEffect.Proc();
		private IEnumerator WalkAndShootRoutine()
		{
			//Player1.MPBar.GetComponent<Image>().fillAmount = 0f;
			PastPlayer1 = Player1.PlayerClone();
			PastPlayer1.enabled = false;
			PastPlayer2 = Player2.PlayerClone ();
			PastPlayer2.enabled = false;
			foreach (Unit u in AllUnits) {
				PastAllUnits.Add (u.UnitClone());
				PastAllUnits [PastAllUnits.Count - 1].enabled = false;
			}

			Player1.MPBar.SetActive(true);
			if (!GameManager.Instance.OnlineMatch)
			{
				foreach (Unit u in AllUnits)
				{
					u.WalkToPosition(u.Lane.WalkPositions[u.Owner.ClientID - 1].position);

					if (u.Owner.ClientID == 1)
					{
						actionWindow.AddButton(u);
					}
				}
			}
			else if (GameManager.Instance.IsClient)
			{
				foreach (Unit u in AllUnits)
				{
					u.WalkToPosition(u.Lane.WalkPositions[u.Owner.ClientID - 1].position);

					if (u.Owner == Player.Authoritative)
					{
						actionWindow.AddButton(u);
					}
				}
			}
			else // isServer
			{
				foreach (Unit u in AllUnits)
				{
					u.WalkToPosition(u.Lane.WalkPositions[u.Owner.ClientID - 1].position);
				}
			}



			float percent = 0f;

			if (!GameManager.Instance.IsServer)
			{
				actionWindow.gameObject.SetActive(true);

				while (AllUnits.Where(u => !u.DestinationReached).ToList().Count > 0)
				{
					yield return new WaitForFixedUpdate();

					//Debuffs and Buffs are procced here; note that the initial list is created in order to prevent concurrent modification during
					//the for-each loop. Due to the 0.833 second wait after a Unit's ActionState is declared to be Dead, it is impossible for any
					//modification to occur during the for-each loop AS LONG AS the enemies marked as Dead are not considered for procs					List<Unit> toConsider = AllUnits.Where(x => x.ActionState != Unit.ActionStates.Dead).ToList();
					foreach (Unit u in toConsider)
					{
						for (int i = 0; i < u.Buffs.Count; i++)
						{
							u.Buffs[i].Proc();
							if (u.Buffs[i].MarkedForRemoval)
							{
								u.Buffs.RemoveAt(i);
								i--;
							}
						}
						for (int i = 0; i < u.Debuffs.Count; i++)
						{
							u.Debuffs[i].Proc();
							if (u.Debuffs[i].MarkedForRemoval)
							{
								u.Debuffs.RemoveAt(i);
								i--;
							}
						}
					}

					if (Time.time - lastMPGain > 1f)
					{
						//Player2.MP += MPRegainPerSecond;
						Player1.MP += MPRegainPerSecond;
						lastMPGain = Time.time;
					}



					percent = (AllUnits.Where(u => u.Owner.ClientID == 1).OrderBy(u => u.PercentReached).FirstOrDefault() == null) ? 0f : Mathf.Min(AllUnits.Where(u => u.Owner.ClientID == 1).OrderBy(u => u.PercentReached).FirstOrDefault().PercentReached, percent + 0.0025f);

					if (Player.Authoritative.ClientID == 1)
					{
						MainCamera.transform.position = Vector3.Lerp(new Vector3(-64f, -32f, 0f), new Vector3(0f, 5f, 0f), percent);
					}
					else
					{
						MainCamera.transform.position = Vector3.Lerp(new Vector3(64f, 42f, 0f), new Vector3(0f, 5f, 0f), percent);
					}
				}
			}
			else
			{
				while (AllUnits.Where(u => !u.DestinationReached).ToList().Count > 0)
				{
					List<Unit> toConsider = AllUnits.Where(x => x.ActionState != Unit.ActionStates.Dead).ToList();
					foreach (Unit u in toConsider)
					{
						for (int i = 0; i < u.Buffs.Count; i++)
						{
							u.Buffs[i].Proc();
							if (u.Buffs[i].MarkedForRemoval)
							{
								u.Buffs.RemoveAt(i);
								i--;
							}
						}
						for (int i = 0; i < u.Debuffs.Count; i++)
						{
							u.Debuffs[i].Proc();
							if (u.Debuffs[i].MarkedForRemoval)
							{
								u.Debuffs.RemoveAt(i);
								i--;
							}
						}
					}

					if (Time.time - lastMPGain > 1f)
					{
						//Player2.MP += MPRegainPerSecond;
						Player1.MP += MPRegainPerSecond;
						lastMPGain = Time.time;
					}
					yield return null;
				}
			}



			float timePassed = 0f;
			float timeRemaining;
			countdownText.gameObject.SetActive(true);

			bool spedUp = false;

			while (timePassed < 20f)
			{
				List<Unit> toConsider = AllUnits.Where(x => x.ActionState != Unit.ActionStates.Dead).ToList();
				foreach (Unit u in toConsider)
				{
					for (int i = 0; i < u.Buffs.Count; i++)
					{
						u.Buffs[i].Proc();

						if (u.Buffs[i].MarkedForRemoval)
						{
							u.Buffs.RemoveAt(i);
							i--;
						}
					}
					for (int i = 0; i < u.Debuffs.Count; i++)
					{
						u.Debuffs[i].Proc();
						if (u.Debuffs[i].MarkedForRemoval)
						{
							u.Debuffs.RemoveAt(i);
							i--;
						}
					}
				}


				if (Time.time - lastMPGain > 1f)
				{
					//Player2.MP += MPRegainPerSecond;
					Player1.MP += MPRegainPerSecond;
					lastMPGain = Time.time;
				}


				if (timePassed < 6f && !spedUp && AllUnits.Where(u => u.Ammo > 0).ToList().Count == 0)
				{
					spedUp = true;
					timePassed = 6f;
				}

				timePassed += Time.deltaTime;
				timeRemaining = 20f - timePassed;
				countdownText.text = ((int)timeRemaining).ToString();
				countdownText.fontSize = 100 + 50 * Mathf.Lerp(0f, 1, 1 - (timeRemaining - (int)timeRemaining));
				yield return null;
			}

			Player1.MPBar.SetActive(false);

			if (!GameManager.Instance.OnlineMatch || GameManager.Instance.IsServer)
			{
				foreach (Destructible d in AllDestructibles)
				{
					d.Hit();
				}

				foreach (Unit u in AllUnits)
				{
					Destroy(u.gameObject);
				}

				superSelectionRoutine = StartCoroutine(SuperSelectionRoutine());

				if (GameManager.Instance.IsServer)
				{
					RpcStartPlacement();
				}
				else
				{
					actionWindow.ResetWindow();
					actionWindow.gameObject.SetActive(false);
				}
			}

			walkAndShootRoutine = null;
		}

		public void Quit()
		{
			GameManager.Instance.SwitchScene("Main");
		}

		public void UpdateScore()
		{
			player1ScoreText.text = ("P1: " + Player1.Score.ToString());
			player2ScoreText.text = ("P2: " + Player2.Score.ToString());
		}
	}
}