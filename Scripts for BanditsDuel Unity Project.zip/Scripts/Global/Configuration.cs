﻿public static class Configuration
{
#if UNITY_STANDALONE_LINUX || UNITY_ANDROID || UNITY_IPHONE
    public static string MasterServerIp = "35.164.151.152";
#else
    public static string MasterServerIp = "127.0.0.1";
#endif

    public static int MasterServerPort = 7777;
    public static readonly int GameServerStartingPort = 9000;
    public static readonly string GameServerBinaryPath = "/var/app/current/GameServer.x86_64";
}