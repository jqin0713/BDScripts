﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using LGG;

namespace BD
{
    public class GameManager : LGSingleton<GameManager>
    {
        private const float FADE_TIME = 0.5f;

        [SerializeField] private CanvasRenderer loadingScreenCanvas;
        [SerializeField] private Image loadingScreenLogo;
        [SerializeField] private ClientNetworkManager clientNetworkManager;

        public string CurrentScene { get { return UnityEngine.SceneManagement.SceneManager.GetActiveScene().name; } }
        public List<string> TeamList;
        public int TeamSize;
        public DuelManager DuelManager;
        public Material LineMaterialPrefab;
        public GameObject HeroPrefab;
        public GameObject DuelEffectDefaultPrefab;
        public GameObject DynamitePrefab;
        public GameObject ActionButtonPrefab;
        public GameObject BarrelPrefab;
        public GameObject FloatingTextPrefab;
        public GameObject BulletPrefab;
        public Color HomeColor;
        public Color AwayColor;

        private Coroutine fadeRoutine;
		public bool FriendlyFireException;

        public bool OnlineMatch;
        public bool IsServer;
        public bool IsClient;

        public bool LoadingScene;

		public enum Difficulties
		{
			Easy,
			Normal,
			Hard
		}

		public Difficulties Difficulty;

        protected override void Start()
        {
            base.Start();

            if (CurrentScene == "Boot")
            {
                StartCoroutine(BootRoutine());
            }
        }

        private IEnumerator BootRoutine()
        {
            while (DatabaseManager.AnyLoading())
            {
                yield return null;
            }

            SwitchScene("Main");

            while (LoadingScene)
            {
                yield return null;
            }

            clientNetworkManager.CheckMasterConnection();
        }

		public void SwitchScene(string scene)
		{
            LoadingScene = true;
            StartCoroutine(SwitchSceneRoutine(scene));
		}

		private IEnumerator SwitchSceneRoutine(string scene)
		{
            FadeLoadingScreen(1f);

            yield return new WaitForSeconds(FADE_TIME);

            AsyncOperation op = UnityEngine.SceneManagement.SceneManager.LoadSceneAsync(scene, UnityEngine.SceneManagement.LoadSceneMode.Single);

            while (!op.isDone || fadeRoutine != null)
			{
                yield return null;
			}

            FadeLoadingScreen(0f);
            LoadingScene = false;
        }

		private void FadeLoadingScreen(float target)
		{
		    fadeRoutine = StartCoroutine(FadeRoutine(target));
		}

		private IEnumerator FadeRoutine(float endAlpha)
		{
            float startTime = Time.time;
            float percent = 0f;
            float startAlpha = loadingScreenCanvas.GetAlpha();

            while (percent < 1f)
			{
                percent = Mathf.Min((Time.time - startTime) / FADE_TIME, 1f);
                float targetAlpha = Mathf.Lerp(startAlpha, endAlpha, percent);
                loadingScreenCanvas.SetAlpha(targetAlpha);
                loadingScreenLogo.color = new Color(loadingScreenLogo.color.r, loadingScreenLogo.color.g, loadingScreenLogo.color.b, targetAlpha);
				yield return null;
			}

            fadeRoutine = null;
		}

        public void SetDuelManager(DuelManager dm)
        {
            DuelManager = dm;
        }
    }
}
