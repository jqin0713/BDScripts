﻿using UnityEngine;
using System.Collections;

public class DebugOnly : MonoBehaviour {

	void Awake () {
        if (!Debug.isDebugBuild)
            Destroy(gameObject);
        else
            Destroy(this);
	}

}
