﻿using UnityEngine;
using System.Collections;

public class ConsoleToDisableLogging : MonoBehaviour {

    void OnStart() {
        #if UNITY_EDITOR
        Destroy(gameObject);
        #endif
    }

	void OnEnable () {
        Application.logMessageReceived += ToScreenConsole;
	}
	
	void OnDisable () {
        Application.logMessageReceived -= ToScreenConsole;
	}

    void ToScreenConsole(string condition, string stacktrace,LogType type) {
        switch (type)
        {
            case LogType.Log:
                DisableLogging.Logger.Log(condition);
                break;
            case LogType.Warning:
                string warning = string.Format("{0}\n{1}",condition,stacktrace);
                DisableLogging.Logger.LogWarning(warning);
                break;
            default:
                string error = string.Format("{0}\n{1}",condition,stacktrace);
                DisableLogging.Logger.LogError(error);
                break;
              
        }
    }
}
