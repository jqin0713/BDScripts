﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class CSVParser
{


	public static List<List<string>> Parse(TextAsset asset) {
		return Parse (asset.text);
	}


	/**
	 *  Expected format (google spreadsheet csv generation):
	 *  Tokens with special characters (comma, quote) are wrap in quotes.
	 *    Ex:  ok,ok... => "ok,ok..."
	 *  Any quotes in the token is escaped with a quote.
	 *    Ex: "Accident" => """Accident"""
	 */
	public static List<List<string>> Parse(string csvText)
	{
		List<List<string>> ret = new List<List<string>>();
		
		var lines = csvText.Split('\n');
		foreach(var l in lines)
		{
			string line = l.Replace("\r", "");
			
			List<string> row = new List<string>();
			string token = "";
			bool spToken = false;

			for (int i = 0; i < line.Length; i++)
			{
				if (line[i] == '\"')
				{
					//look for consecutive quotes
					int quoteCount = 1;
					int j = i + 1;
					while (j < line.Length && line[j] == '\"')
					{
						quoteCount++;
						j++;
					}

					//advance index pass all the quotes
					i += quoteCount - 1;

					//odd number of quotes means begin or end of a special token
					if (quoteCount % 2 != 0)
					{
						spToken = !spToken;
						quoteCount--;
					}

					//add every other even number quotes to the token
					if (quoteCount % 2 == 0)
					{
						for (int k = 0; k < quoteCount; k++)
						{
							if (k % 2 == 0)
							{
								token += '\"';
							}
						}
					}
				}
				else if (line[i] == ',')
				{
					//if not a special token, this means end of token
					//otherwise treat it as part of token
					if (spToken == false)
					{
						row.Add(token);
						token = "";
					}
					else
					{
						token += line[i];
					}
				}
				else
				{
					//everything else is part of token
					token += line[i];
				}
			}

			if (token != "")
			{
				row.Add(token);
			}

			// [LGG] If the first column of the row is null (ID), ignore it.
			if (row.Count > 0 && string.IsNullOrEmpty(row[0])) continue;
			ret.Add(row);
		}
		
		return ret;
	}
}
