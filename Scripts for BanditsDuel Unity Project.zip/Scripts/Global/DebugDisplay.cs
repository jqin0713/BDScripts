﻿using UnityEngine;
using System.Collections;
using System.Diagnostics;
using DisableLogging;

public class DebugDisplay : DisableLogging.ScreenConsole{
    public bool allowDrag = true; // Do you want to allow the dragging of the FPS window.
    public float frequency = 0.5F; // The update frequency of the FPS.
    public int nbDecimal = 1; // How many decimal do you want to display.

    private float accum = 0f; // FPS accumulated over the interval.
    private int frames = 0; // Frames drawn over the interval.
    private string sFPS = ""; // The fps formatted into a string.
    private GUIStyle style; // The style the text will be displayed at, based en defaultSkin.label.
    private Color color;
    private Stopwatch stopWatch = new Stopwatch();

    protected override void Start()
    {
        base.Start();

        StartCoroutine(FPS());
        stopWatch.Start();
    }

    protected override void DrawMenu(int windowID)
    {
        if (style == null)
        {
            style = new GUIStyle(GUI.skin.label);
            style.normal.textColor = color;
            style.alignment = TextAnchor.MiddleCenter;
            style.fontSize = this.menuFontSize;
        }

        GUILayout.Label(sFPS + " FPS", style, m_menuButtonHeightOption);

        base.DrawMenu(windowID);
    }

    private void Update() {
        accum += Time.timeScale / Time.deltaTime;
        ++frames;
    }

    private IEnumerator FPS()
    {
        // Infinite loop executed every "frenquency" seconds.
        while (true)
        {
            // Update the FPS.
            float fps = accum / frames;
            sFPS = fps.ToString("f" + Mathf.Clamp(nbDecimal, 0, 10));

            // Update the color.
            color = (fps >= 30) ? Color.green : ((fps > 10) ? Color.red : Color.yellow);

            accum = 0.0F;
            frames = 0;

            yield return new WaitForSeconds(frequency);
        }
    }

    protected override void OnGUI()
    {
        if (IsScreenSizeChanged() && m_resizeWhileRotate)
        {
            DoIfScreenSizeChanged();
        }

        ProcessUpdateRequests();

        // draw menu window
        GUIHelper.AdsorbToFullScreen(ref m_menuBounds, ADSORB_PADDING);

        string s = stopWatch.Elapsed.ToString();
        int index = s.IndexOf('.');
        if (index >= 0)
        {
            s = s.Remove(index);
        }

        m_menuBounds = GUI.Window(0, m_menuBounds, DrawMenu, s);

        // draw console window
        if (showConsole)
        {
            GUIHelper.AdsorbToFullScreen(ref m_consoleBounds, ADSORB_PADDING);
            m_consoleBounds = GUI.Window(1, m_consoleBounds, DrawConsole, STR_CONSOLE);

            if (m_dragDetector == null)
            {
                m_consoleDragArea.Set(0, 0, m_consoleBounds.width, m_consoleBounds.height-m_hSpace);
            }
            else
            {
                m_consoleDragArea.Set(0, 0, m_consoleBounds.width, m_hSpace);
                m_consoleLogDragArea.Set(m_consoleBounds.x+m_wSpace, m_consoleBounds.y+m_hSpace, m_consoleBounds.width-m_wSpace*2, m_consoleBounds.height-m_hSpace*2);
            }
        }
    }
}
