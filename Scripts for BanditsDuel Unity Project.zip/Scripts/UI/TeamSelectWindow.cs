using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.EventSystems;

namespace BD
{
    public class TeamSelectWindow : CardWindow
    {
        protected override void Awake()
        {
            base.Awake();

            NumSlots = 3;
        }

        protected override void CreateSlots()
        {
            base.CreateSlots();

            Messenger.Broadcast(MessageEnum.RefreshCards);
        }

        public List<string> GetFinalTeamList()
        {
            List<string> teamList = new List<string>();

            for (int i = 0; i < CardSlots.Length; i++)
            {
                if (CardSlots[i].GetComponent<Slot>().CurrentCard != null)
                {
                    teamList.Add(CardSlots[i].GetComponent<Slot>().CurrentCard.GetComponent<Card>().HeroData.Key);
                }
                else
                {
                    teamList.Add(HeroDatabase.Instance.Entries[i].Key);
                }
            }

            return teamList;
        }
    }
}