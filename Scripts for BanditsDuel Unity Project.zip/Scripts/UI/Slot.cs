﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace BD
{
    public class Slot : LGG.LGBehaviour
    {
        [SerializeField] private GameObject CardPrefab;
        [SerializeField] private GameObject SpawnCardPrefab;
		[SerializeField]
		private GameObject SuperCardPrefab;


        public int SlotID;

        public GameObject CurrentCard;
        public CardWindow CardWindow;

        public void Set(string key)
        {
            Reset();

            if (CardWindow.gameObject.name.Equals("SpawnWindow"))
            {
                CurrentCard = Instantiate(SpawnCardPrefab);
            }
			else if (CardWindow.gameObject.name.Equals("SuperSelectWindow(Clone)") || CardWindow.gameObject.name.Equals("SuperWindow(Clone)"))
			{
				CurrentCard = Instantiate(SuperCardPrefab);
				//((SuperCard)CurrentCard.GetComponent<Card>()).MPCostLabel.text = SuperDatabase.Instance.Get(key).MPCost.ToString();
				//Deprecated
				//((SuperCard)CurrentCard.GetComponent<Card>()).MPCost = SuperDatabase.Instance.Get(key).MPCost;
				//((SuperCard)CurrentCard.GetComponent<Card>()).CooldownTime = SuperDatabase.Instance.Get(key).Cooldown;
			}
			else
			{
				CurrentCard = Instantiate(CardPrefab);
            }
            
            CurrentCard.transform.SetParent(this.transform);
            CurrentCard.transform.localPosition = new Vector3(0f, 0f, 0f);
            CurrentCard.transform.localScale = Vector3.one;
            CurrentCard.GetComponent<Card>().ParentSlot = this;
            CurrentCard.GetComponent<Card>().Set(key);
        }

        public void Reset()
        {
            if (CurrentCard != null)
            {
                Destroy(CurrentCard);
                CurrentCard = null;
            }
        }
    }
}