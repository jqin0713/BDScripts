﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using LGG;
using System.Linq;
using TMPro;

namespace BD
{
	public class SuperSelectionWindow : CardWindow
	{
		public List<string> SelectedSupers;

		public SpawnCard Source;

		[SerializeField]
		private TextMeshProUGUI SSBannerLabel;

		protected override void Start()
		{
			base.Start();
			SelectedSupers = new List<string>();
		}

		public void ToggleWindowActive()
		{
			if (NumSlots == 0)
			{
				NumSlots = SuperDatabase.Instance.Keys.Where(x => SuperDatabase.Instance.Get(x).Weapon == Source.HeroData.Weapon).ToList().Count;
				SSBannerLabel.text = Source.HeroData.Key + " Supers";
				SetSuperCards();
			}

			gameObject.SetActive(!gameObject.activeSelf);
		}

		public void SetSuperCards() {
			for (int i = 0; i < NumSlots; i++) {
				AddSuper (SuperDatabase.Instance.Keys.Where(x => SuperDatabase.Instance.Get(x).Weapon == Source.HeroData.Weapon).ToList() [i], i);
			}
		}

		//Called whenever the button is pressed
		public void finishSelecting() {
			GameManager.Instance.DuelManager.SuperSelectionPhase = false;
		}
	}
}

