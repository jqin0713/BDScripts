﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using LGG;

namespace BD
{
    public class SpawnWindow : CardWindow
    {
        protected override void Awake()
        {
            base.Awake();

			NumSlots = GameManager.Instance.TeamList.Count;
            gameObject.SetActive(false);
        }

        protected override void Start()
        {
            base.Start();
        }

        public void SetSpawnCards()
        {
            gameObject.SetActive(true);
            int i = 0;

            foreach (string key in Player.Authoritative.Heroes.Keys)
            {
                CardSlots[i].GetComponent<Slot>().Set(key);
                i++;
            }
        }
    }
}