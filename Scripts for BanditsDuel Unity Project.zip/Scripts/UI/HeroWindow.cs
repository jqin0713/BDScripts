using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace BD
{
    public class HeroWindow : CardWindow
    {
        private const int NUM_HEROES_PER_PAGE = 10;  // [TODO]:  Implement Pages :^) -- only prototyping with 3 heroes for now

        [SerializeField] private TeamSelectWindow teamSelectWindow;

        protected override void Start()
        {
            NumSlots = NUM_HEROES_PER_PAGE;
            SetHeroes();
        }

        protected override void AddListeners()
        {
            base.AddListeners();

            Messenger.AddListener(MessageEnum.RefreshCards, Refresh);
        }

        protected override void RemoveListeners()
        {
            base.RemoveListeners();

            Messenger.RemoveListener(MessageEnum.RefreshCards, Refresh);
        }

        private void SetHeroes()
        {
            for (int i = 0; i < HeroDatabase.Instance.Entries.Count; i++)
            {
                //if (!HeroDatabase.Instance.Entries[i].Key.Equals("Minion"))
                {
                    CardSlots[i].GetComponent<Slot>().Set(HeroDatabase.Instance.Entries[i].Key);
                }
            }
        }

        public void Refresh()
        {
            if (CardSlots.Length == 0) return;

            ResetCards();

            List<string> availableHeroesList = new List<string>();

            for (int i = 0; i < HeroDatabase.Instance.Entries.Count; i++)
            {
                if (!teamSelectWindow.ContainsHero(HeroDatabase.Instance.Entries[i].Key) /*&& !HeroDatabase.Instance.Entries[i].Key.Equals("Minion")*/)
                {
                    availableHeroesList.Add(HeroDatabase.Instance.Entries[i].Key);
                }
            }

            for (int i = 0; i < availableHeroesList.Count; i++)
            {
                CardSlots[i].GetComponent<Slot>().Set(availableHeroesList[i]);
            }
        }
    }
}