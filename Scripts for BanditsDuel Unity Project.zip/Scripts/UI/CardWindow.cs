using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using LGG;

namespace BD
{
    public class CardWindow : LGBehaviour
    {
        [SerializeField] private GameObject slotPrefab;
        [SerializeField] private GameObject slotGrid;

        public GameObject[] CardSlots;

        private int numSlots;
        public int NumSlots
        {
            get
            {
                return numSlots;
            }
            set
            {
                numSlots = value;
                DestroySlots();
                CreateSlots();
            }
        }

        public virtual void AddHero(string hero, int slotID)
        {
            CardSlots[slotID].GetComponent<Slot>().Set(hero);
        }

        public virtual void RemoveHero(int slotID)
        {
            CardSlots[slotID].GetComponent<Slot>().Reset();
        }

		public virtual void AddSuper(string super, int slotID)
		{
			CardSlots[slotID].GetComponent<Slot>().Set(super);
		}

		public virtual void RemoveSuper(int slotID)
		{
			CardSlots[slotID].GetComponent<Slot>().Reset();
		}

        public virtual bool ContainsHero(string hero)
        {
            bool contains = false;

            for (int i = 0; i < CardSlots.Length; i++)
            {
                if (CardSlots[i].GetComponent<Slot>().CurrentCard != null && CardSlots[i].GetComponent<Slot>().CurrentCard.GetComponent<Card>().HeroData.Key.Equals(hero))
                {
                    contains = true;
                    break;
                }
            }

            return contains;
        }

		public virtual bool ContainsSuper(string super)
		{
			for (int i = 0; i<CardSlots.Length; i++)
            {
                if (CardSlots[i].GetComponent<Slot>().CurrentCard != null && CardSlots[i].GetComponent<Slot>().CurrentCard.GetComponent<Card>().SuperData.Key.Equals(super))
                {
					return true;
                }
            }
			return false;
		}

        protected virtual void CreateSlots()
        {
            CardSlots = new GameObject[numSlots];

            for (int i = 0; i < CardSlots.Length; i++)
            {
                GameObject slot = Instantiate(slotPrefab) as GameObject;
                slot.transform.SetParent(slotGrid.transform);
                slot.transform.localPosition = new Vector3(slot.transform.position.x, slot.transform.position.y, 0f);
                slot.transform.localScale = Vector3.one;
                slot.GetComponent<Slot>().SlotID = i;
                slot.GetComponent<Slot>().CardWindow = this;

                CardSlots[i] = slot;
            }    
        }

        protected virtual void DestroySlots()
        {
            for (int i = 0; i < CardSlots.Length; i++)
            {
                Destroy(CardSlots[i]);
            }
        }

        protected virtual void ResetCards()
        {
            for (int i = 0; i < CardSlots.Length; i++)
            {
                if (CardSlots[i].GetComponent<Slot>().CurrentCard != null)
                {
                    Destroy(CardSlots[i].GetComponent<Slot>().CurrentCard);
                }
            }
        }
    }
}