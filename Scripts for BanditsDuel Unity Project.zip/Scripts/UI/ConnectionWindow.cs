﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using LGG;
using UnityEngine.UI;
using TMPro;
using UnityEngine.EventSystems;

namespace BD
{
	public class ConnectionWindow : LGBehaviour
	{
		[SerializeField] private GameObject connectedLayer;
		[SerializeField] private GameObject notConnectedLayer;
		[SerializeField] private TextMeshProUGUI connectionMessage;
		[SerializeField] private GameObject ConnectButton;
		[SerializeField] private InputField networkAddress;
		[SerializeField] private InputField networkPort;

		protected override void AddListeners()
		{
			base.AddListeners();

			Messenger.AddListener<bool>(MessageEnum.ClientSetConnectedToMaster, SetConnectedToMaster);
			Messenger.AddListener<PointerEventData>(MessageEnum.ClientConnectToMaster, AttemptingConnection);
		}

		protected override void RemoveListeners()
		{
			base.RemoveListeners();

			Messenger.RemoveListener<bool>(MessageEnum.ClientSetConnectedToMaster, SetConnectedToMaster);
			Messenger.AddListener<PointerEventData>(MessageEnum.ClientConnectToMaster, AttemptingConnection);
		}

		private void SetConnectedToMaster(bool connected)
		{
			connectedLayer.SetActive(connected);
			notConnectedLayer.SetActive(!connected);
			connectionMessage.text = connected ? "Connected to Master Server" : "Failed to Connect to Master Server.";
			networkAddress.text = Configuration.MasterServerIp.ToString();
			networkPort.text = Configuration.MasterServerPort.ToString();

			ConnectButton.SetActive(!connected);
			networkAddress.transform.parent.gameObject.SetActive(!connected);
			networkPort.transform.parent.gameObject.SetActive(!connected);
		}

		private void AttemptingConnection(PointerEventData eventData)
		{
			connectionMessage.text = "Attempting to Connect to Master Server...";
			ConnectButton.SetActive(false);
			networkAddress.transform.parent.gameObject.SetActive(false);
			networkPort.transform.parent.gameObject.SetActive(false);
		}

		public void UpdateAddress()
		{
			Configuration.MasterServerIp = networkAddress.text;
		}

		public void UpdatePort()
		{
			Configuration.MasterServerPort = int.Parse(networkPort.text);
		}

	}
}

