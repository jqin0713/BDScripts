using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using LGG;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using System.Linq;

namespace BD
{
    public class SpawnCard : Card
    {
        [SerializeField] private SpriteRenderer healthBarFill, healthBarEmpty;

        private List<RaycastResult> raycastResults = new List<RaycastResult>();
        private Lane currentLane = null;
		private Vector3 oldPosition;

		//This window appears whenever you click on a particlar Spawn Card
		public SuperSelectionWindow SuperSelectionWindow;

		//Created via selection during the Super Selection mini-scene at the start of each round
		public List<string> Supers;

        public override void Set(string key)
        {
            base.Set(key);

            if (GameManager.Instance.IsClient || !GameManager.Instance.OnlineMatch)
            {
                float percent = Player.Authoritative.Heroes[key].Health / (float)HeroData.HP;
                healthBarFill.transform.localScale = new Vector3(2.5f * percent, 2, 1f);
                healthBarFill.transform.localPosition = new Vector3(-1.9f + (percent * 1.9f), healthBarFill.transform.localPosition.y, healthBarFill.transform.localPosition.z);
            }
        }

		public override void OnClick (PointerEventData eventData)
		{
			if (GameManager.Instance.DuelManager.SuperSelectionPhase) {
				if (SuperSelectionWindow == null) {
					SuperSelectionWindow = Instantiate (GameManager.Instance.DuelManager.SuperSelectionWindowPrefab).GetComponent<SuperSelectionWindow> ();
					SuperSelectionWindow.gameObject.SetActive(false);
					SuperSelectionWindow.Source = this;
					SuperSelectionWindow.transform.SetParent(GameManager.Instance.DuelManager.SuperSelectWindowRoot);
					SuperSelectionWindow.transform.localPosition = new Vector3(600f, -509f, 0f);
					SuperSelectionWindow.transform.localScale = new Vector3(1f, 1f, 1f);
				}
				if (GameManager.Instance.DuelManager.ActiveSSWindow != null) {
					GameManager.Instance.DuelManager.ActiveSSWindow.gameObject.SetActive (false);
				}
				GameManager.Instance.DuelManager.ActiveSSWindow = SuperSelectionWindow;
				SuperSelectionWindow.ToggleWindowActive();

			}
		}

        public override void OnBeginDrag(Transform t, PointerEventData eventData)
        {
			if (GameManager.Instance.DuelManager.SuperSelectionPhase) {
				return;
			}
			oldPosition = new Vector3(transform.position.x, transform.position.y, transform.position.z);
            GetComponent<Image>().enabled = false;
            heroNameLabel.enabled = false;
            border.enabled = false;
            healthBarEmpty.enabled = false;
            healthBarFill.enabled = false;

            if (Player.Authoritative.ClientID == 1)
            {
                skeletonAnimation.skeletonDataAsset = HeroData.BackSkeleton;
            }
            else
            {
                skeletonAnimation.skeletonDataAsset = HeroData.FrontSkeleton;
            }

            skeletonAnimation.initialSkinName = HeroData.Skin;
            skeletonAnimation.Initialize(true);
            skeletonAnimation.skeleton.a = 0.85f;
            skeletonAnimation.AnimationState.SetAnimation(0, "idle", true);
            skeletonAnimation.transform.localScale = new Vector3(100f, 100f, 1f);
        }

        public override void OnDrag(Transform t, PointerEventData eventData)
        {
			if (GameManager.Instance.DuelManager.SuperSelectionPhase) {
				return;
			}
            EventSystem.current.RaycastAll(eventData, raycastResults);
            Lane newLane = null;

            for (int i = 0; i < raycastResults.Count; i++)
            {
                if (raycastResults[i].gameObject.CompareTag("Lane"))
                {
                    newLane = raycastResults[i].gameObject.GetComponent<Lane>();
                    break;
                }
            }

            if (currentLane == null)
            {
                if (newLane != null)
                {
                    currentLane = newLane;
                    currentLane.ShowOverlay(true);
                }
            }
            else
            {
                if (newLane == null)
                {
                    currentLane.ShowOverlay(false);
                    currentLane = null;
                }
                else
                {
                    currentLane.ShowOverlay(false);
                    currentLane = newLane;
                    currentLane.ShowOverlay(true);
                }
            }

            Vector2 worldPos = GameManager.Instance.DuelManager.UICamera.ScreenToWorldPoint(eventData.position);
            transform.position = worldPos;
        }

        public override void OnEndDrag(Transform t, PointerEventData eventData)
        {
			if (GameManager.Instance.DuelManager.SuperSelectionPhase) {
				return;
			}
			if (currentLane == null || currentLane.Occupied)
            {
				gameObject.transform.position = oldPosition;
                GetComponent<Image>().enabled = true;
                heroNameLabel.enabled = true;
                border.enabled = true;
                healthBarEmpty.enabled = true;
                healthBarFill.enabled = true;
                skeletonAnimation.skeletonDataAsset = HeroData.FrontSkeleton;
                skeletonAnimation.initialSkinName = HeroData.Skin;
                skeletonAnimation.Initialize(true);
                skeletonAnimation.skeleton.a = 1f;
                skeletonAnimation.transform.localScale = new Vector3(60f, 60f, 1f);
            }
            else
            {
                currentLane.ShowOverlay(false);
                if (GameManager.Instance.OnlineMatch)
                {
                    Player.Authoritative.CmdSpawnHero(HeroData.Key, GameManager.Instance.DuelManager.lanes.ToList().IndexOf(currentLane));
                }
                else
                {
					//Here is where the planned SuperWindow instantiation, followed by the filling out the SuperWindow with the appropriate supers from the List<string> Supers,
					//and then reverse binding of each SuperCard to this Unit, will take place
                    Unit newUnit = Instantiate(GameManager.Instance.DuelManager.UnitPrefab).GetComponent<Unit>();
                    newUnit.SetData(HeroData.Key, currentLane.SpawnPositions[0].position, 1, currentLane);
					newUnit.SuperWindow = Instantiate(GameManager.Instance.DuelManager.SuperWindowPrefab).GetComponent<SuperWindow>();
					if (newUnit.SuperWindow == null)
					{
						Debug.LogWarning("Super Window is null");
					}
					newUnit.SuperWindow.transform.SetParent(GameManager.Instance.DuelManager.SuperWindowRoot);
					newUnit.SuperWindow.transform.localPosition = new Vector3(0f, -570f, 0f);
					newUnit.SuperWindow.transform.localScale = new Vector3(1f, 1f, 1f);
					int i = 0;
					//Checks if you actually clicked on the SpawnCard to open up the SuperSelectionWindow. If you didn't the game assumes you wanted to
					//go into the match with no Supers (i.e. if SuperSelectionWindow == null)
					if (SuperSelectionWindow != null)
					{
						foreach (string s in SuperSelectionWindow.SelectedSupers)
						{
							newUnit.SuperWindow.AddSuper(s, i);
							if (SuperDatabase.Instance.Get (s).TypeOfSuper == "Attack Enhancer") {
								((SuperCard)newUnit.SuperWindow.CardSlots [i].GetComponent<Slot> ().CurrentCard.GetComponent<Card>()).User = newUnit;
							}
							i++;

						}
					}
					newUnit.SuperWindow.gameObject.SetActive(false);

                }
				currentLane.Occupied = true;
				Destroy (gameObject);
			}
        }
    }
}
