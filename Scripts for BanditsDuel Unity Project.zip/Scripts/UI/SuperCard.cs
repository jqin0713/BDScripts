﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using LGG;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using TMPro;


namespace BD
{
	public class SuperCard : Card
	{
		private Vector3 oldPosition;

		private Color startingColor;

		//Will be set inside SpawnCard, check there for more details
		public Unit User;


		private float lastUsed = -1f;


		public bool OnCooldown { get; private set; }
		public bool SufficientMP { get; private set; }

		//This blue X covering the Super Card appears whenever there is insufficient MP
		public GameObject MPCross;

		public GameObject MPCostLabel;

		protected override void Update()
		{
			base.Update();
			SufficientMP = (Player.Authoritative.MP >= SuperData.MPCost);
			MPCross.SetActive(!SufficientMP && GameManager.Instance.DuelManager.Action());

			MPCostLabel.GetComponentInChildren<TextMeshProUGUI>().text = SuperData.MPCost.ToString();

			bool flash = OnCooldown;
			//At the start of the match, all skills are off cooldown; the only limiting factor is available MP
			OnCooldown = Mathf.Approximately(lastUsed, -1f) ? false : (Time.time - lastUsed < SuperData.Cooldown);
			if (OnCooldown)
			{
				GetComponent<Image>().fillAmount = (Time.time - lastUsed) / SuperData.Cooldown;
			}
			//Only occurs right when the SuperCard changes from being on cooldown to off cooldown
			flash = (flash != OnCooldown && !OnCooldown);
			if (flash)
			{
				StartCoroutine(Flash());
			}
		}

		public bool Usable()
		{
			return SufficientMP && !OnCooldown;
		}

		private IEnumerator Flash()
		{
			GetComponent<Image>().fillAmount = 1f;
			startingColor = GetComponent<Image>().color;
			GetComponent<Image>().color = Color.green;
			yield return new WaitForSeconds(0.25f);
			GetComponent<Image>().color = startingColor;
		}


		public override void OnClick(PointerEventData eventData)
		{
			
			if (GameManager.Instance.DuelManager.SuperSelectionPhase) {
				
				if (!((SuperSelectionWindow)ParentSlot.CardWindow).SelectedSupers.Contains (SuperData.Key)) {
					((SuperSelectionWindow)ParentSlot.CardWindow).SelectedSupers.Add (SuperData.Key);
					startingColor = GetComponent<Image> ().color;
					GetComponent<Image> ().color = Color.green;
				} else {
					((SuperSelectionWindow)ParentSlot.CardWindow).SelectedSupers.Remove (SuperData.Key);
					GetComponent<Image> ().color = startingColor;
				}

			}
			else if (SuperData.TypeOfSuper == "Attack Enhancer")
			{
				if (!Usable()) return;
				Super s = (Super)Assembly.GetExecutingAssembly().CreateInstance("BD." + Regex.Replace(SuperData.Key, @"\s+", ""));
				s.SetData();
				s.User = User;
				s.ApplyEnhancement();
				//Debug.LogWarning ("There are a total of " + s.User.Weapon.Enhancements.Count + " enhancements on this User's weapon and the first one is " + s.User.Weapon.Enhancements [0].SuperName);
				Player.Authoritative.MP -= s.MPCost;
				lastUsed = Time.time;
			}
		}

		public override void OnBeginDrag(Transform t, PointerEventData eventData)
		{
			//Cannot access individual Units' SuperWindows during PlacementPhase, so that check is unnecessary
			if (GameManager.Instance.DuelManager.SuperSelectionPhase)
			{
				return;
			}
			if (!Usable()) return;
			if (SuperData.TypeOfSuper != "Attack Enhancer") {
				oldPosition = new Vector3 (transform.position.x, transform.position.y, transform.position.z);
				GetComponent<Image> ().enabled = false;
				superNameLabel.enabled = false;
				border.enabled = false;
				MPCostLabel.SetActive(false);
			}
		}

		public override void OnDrag(Transform t, PointerEventData eventData)
		{
			if (GameManager.Instance.DuelManager.SuperSelectionPhase)
			{
				return;
			}
			if (!Usable()) return;
			if (SuperData.TypeOfSuper != "Attack Enhancer") {
				Vector2 worldPos = GameManager.Instance.DuelManager.UICamera.ScreenToWorldPoint (eventData.position);
				transform.position = worldPos;
			}
		}

		public override void OnEndDrag (Transform t, PointerEventData eventData)
		{
			if (GameManager.Instance.DuelManager.SuperSelectionPhase)
			{
				return;
			}
			if (!Usable()) return;
			if (SuperData.TypeOfSuper != "Attack Enhancer") {
				if (SuperData.TypeOfSuper == "Enemy Debuffer") {
					if (eventData.pointerCurrentRaycast.gameObject.CompareTag ("Hero")) {
						Unit debuffedUnit = eventData.pointerCurrentRaycast.gameObject.transform.parent.GetComponent<Unit> ();
						if (debuffedUnit.Owner != Player.Authoritative) {
							Super s = (Super)Assembly.GetExecutingAssembly ().CreateInstance ("BD." + Regex.Replace (SuperData.Key, @"\s+", ""));
							s.SetData ();
							s.ApplyEffects (debuffedUnit);
							Player.Authoritative.MP -= s.MPCost;
							lastUsed = Time.time;
						}
					}
				} else if (SuperData.TypeOfSuper == "Ally Assist") {
					if (eventData.pointerCurrentRaycast.gameObject.CompareTag ("Hero")) {
						Unit buffedUnit = eventData.pointerCurrentRaycast.gameObject.transform.parent.GetComponent<Unit> ();
						if (buffedUnit.Owner == Player.Authoritative) {
							Super s = (Super)Assembly.GetExecutingAssembly ().CreateInstance ("BD." + Regex.Replace (SuperData.Key, @"\s+", ""));
							s.SetData ();
							s.ApplyEffects (buffedUnit);
							Player.Authoritative.MP -= s.MPCost;
							lastUsed = Time.time;
						}
					}
				} else if (SuperData.TypeOfSuper == "Field Effect") {
					Vector2 worldPos = GameManager.Instance.DuelManager.UICamera.ScreenToWorldPoint (eventData.position);
					Super s = (Super)Assembly.GetExecutingAssembly ().CreateInstance ("BD." + Regex.Replace (SuperData.Key, @"\s+", ""));
					s.SetData ();
					((FieldEffect)s).Placement (worldPos);
					Player.Authoritative.MP -= s.MPCost;
					lastUsed = Time.time;
				}
				//Note that Super Cards are not destroyed, unlike their Spawn Card counterparts. The only thing that occurs upon using a super is that it gets set on cooldown
				gameObject.transform.position = oldPosition;
				GetComponent<Image> ().enabled = true;
				superNameLabel.enabled = true;
				border.enabled = true;
				MPCostLabel.SetActive(true);
				//Debug.LogWarning("Player currently has " + Player.Authoritative.MP + " MP");
				//Debug.LogWarning("And MP being sufficient says " + SufficientMP);
			}
		}
	}
}
