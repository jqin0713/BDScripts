﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using LGG;
using Spine.Unity;
using UnityEngine.UI;
using System.Linq;

namespace BD
{
    public class ActionWindow : LGBehaviour
    {
        [SerializeField]
        private GridLayoutGroup Grid;
        private List<ActionButton> buttons;

        protected override void Awake()
        {
            base.Awake();

            buttons = new List<ActionButton>();
            gameObject.SetActive(false);
        }

        public void ToggleButtons(bool show)
        {
            foreach (ActionButton ab in buttons)
            {
                ab.gameObject.SetActive(show);
            }
        }

        public void AddButton(Unit u)
        {
            if (u.Data.WeaponData.Key.Equals("Dynamite") || u.Data.WeaponData.Key.Equals("Revolver")) return;

            ActionButton ab = GameObject.Instantiate(GameManager.Instance.ActionButtonPrefab).GetComponent<ActionButton>();
            ab.transform.SetParent(Grid.transform);
            ab.transform.localScale = Vector3.one;
            ab.Set(u);
            buttons.Add(ab);
            UpdateWindowPos();
        }

        public void RemoveButton(Unit u)
        {
            ActionButton ab = null;

            for (int i = 0; i < buttons.Count; i++)
            {
                if (buttons[i].LocalUnit == u)
                {
                    ab = buttons[i];
                    break;
                }
            }

            if (ab != null)
            {
                buttons.Remove(ab);
                Destroy(ab.gameObject);
            }

            UpdateWindowPos();
        }

        public void ResetWindow()
        {
            for (int i = 0; i < buttons.Count; i++)
            {
                Destroy(buttons[i].gameObject);
            }

            buttons = new List<ActionButton>();
        }
        
        private void UpdateWindowPos()
        {
            if (buttons.Count == 3)
            {
                transform.localPosition = new Vector3(-325f, transform.localPosition.y, transform.localPosition.z);
            }
            else if (buttons.Count == 2)
            {
                transform.localPosition = new Vector3(-220f, transform.localPosition.y, transform.localPosition.z);
            }
            else
            {
                transform.localPosition = new Vector3(-115f, transform.localPosition.y, transform.localPosition.z);
            }
        }
    }
}