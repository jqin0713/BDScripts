﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using LGG;

namespace BD
{
	public class SuperWindow : CardWindow
	{
		protected override void Awake ()
		{
			base.Awake ();
			NumSlots = 3;
		}

		protected override void OnDestroy()
		{
			Destroy(gameObject);
		}

		//This is the in-game window that appears at the bottom of the screen whenever a unit is selected
		public void ToggleWindowActive()
		{
			gameObject.SetActive(!gameObject.activeSelf);
		}
	}
}
