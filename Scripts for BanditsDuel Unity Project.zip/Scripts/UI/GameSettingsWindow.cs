﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using LGG;
using UnityEngine.UI;
using TMPro;
using UnityEngine.EventSystems;

namespace BD
{
	public class GameSettingsWindow : LGBehaviour
	{
		[SerializeField] private TeamSelectWindow teamSelectWindow;
		[SerializeField] private Dropdown numHeroesDropdown, difficultyDropdown, friendlyFireDropdown;
		[SerializeField] private GameObject DuelButton;

		protected override void Start()
		{
			base.Start();


			numHeroesDropdown.value = 0;
			numHeroesDropdown.RefreshShownValue();
			SetNumHeroes(numHeroesDropdown);

			difficultyDropdown.value = 0;
			difficultyDropdown.RefreshShownValue ();
			setDifficulty (difficultyDropdown);

			friendlyFireDropdown.value = 0;
			friendlyFireDropdown.RefreshShownValue ();
			setFriendlyFire (friendlyFireDropdown);

		}

		public void setDifficulty(Dropdown target) {
			switch (target.options [target.value].text) {
			case "Easy":
				GameManager.Instance.Difficulty = GameManager.Difficulties.Easy;
				break;
			case "Normal":
				GameManager.Instance.Difficulty = GameManager.Difficulties.Normal;
				break;
			case "Hard":
				GameManager.Instance.Difficulty = GameManager.Difficulties.Hard;
				break;
			default:
				GameManager.Instance.Difficulty = GameManager.Difficulties.Normal;
				break;
			}
		}

		public void setFriendlyFire(Dropdown target) {
			switch (target.options [target.value].text) {
			case "On":
				GameManager.Instance.FriendlyFireException = true;
				break;
			case "Off":
				GameManager.Instance.FriendlyFireException = false;
				break;
			default:
				GameManager.Instance.FriendlyFireException = false;
				break;
			}

		}

		public void SetNumHeroes(Dropdown target)
		{
            GameManager.Instance.TeamSize = int.Parse(target.options[target.value].text);
            teamSelectWindow.NumSlots = GameManager.Instance.TeamSize;
        }
	}
}