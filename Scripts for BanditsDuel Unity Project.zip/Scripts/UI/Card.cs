﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using Spine.Unity;
using TMPro;
using UnityEngine.EventSystems;
using LGG;
using UnityEngine.UI;
using Spine;
using Spine.Unity.Modules;

namespace BD
{
    public class Card : LGBehaviour
    {
        public HeroData HeroData { get; private set; }
		public SuperData SuperData { get; private set; }

        public Slot ParentSlot;

        [SerializeField]
        protected SkeletonAnimation skeletonAnimation;
        [SerializeField]
        protected TextMeshProUGUI heroNameLabel;
		[SerializeField]
		protected TextMeshProUGUI superNameLabel;
        [SerializeField]
        protected Image border;


        public virtual void Set(string key)
        {
			if (HeroDatabase.Instance.Keys.Contains(key))
			{
				HeroData = HeroDatabase.Instance.Get(key);
				heroNameLabel.text = HeroData.Key;
				skeletonAnimation.skeletonDataAsset = HeroData.FrontSkeleton;
				skeletonAnimation.initialSkinName = HeroData.Skin;
				skeletonAnimation.Initialize(true);
			}
			else
			{
				SuperData = SuperDatabase.Instance.Get(key);
				superNameLabel.text = SuperData.Key;
			}
        }

		public virtual void OnClick(PointerEventData eventData)
		{
			
		}

        public virtual void OnDrag(Transform t, PointerEventData eventData)
        {
            Vector2 worldPos = Camera.main.ScreenToWorldPoint(eventData.position);
            transform.position = worldPos;
        }

        public virtual void OnBeginDrag(Transform t, PointerEventData eventData)
        {
            transform.SetParent(GameObject.Find("UIElevatedRoot").transform);

            gameObject.layer = LayerMask.NameToLayer("UIElevated");

            foreach (Transform child in gameObject.transform)
            {
                child.gameObject.layer = LayerMask.NameToLayer("UIElevated");
            }

            AudioManager.Instance.PlaySound("ui_icon_pickup");
        }

        public virtual void OnEndDrag(Transform t, PointerEventData eventData)
        {
            List<RaycastResult> raycastResults = new List<RaycastResult>();
            EventSystem.current.RaycastAll(eventData, raycastResults);

            Slot targetSlot = null;

            for (int i = 0; i < raycastResults.Count; i++)
            {
                if (raycastResults[i].gameObject.GetComponent<Slot>() == null) continue;

                targetSlot = raycastResults[i].gameObject.GetComponent<Slot>();
                break;
            }

            if (targetSlot == null)
            {
                ParentSlot.CardWindow.RemoveHero(ParentSlot.SlotID);
            }
            else
            {
                if (targetSlot.CurrentCard != null)
                {
                    SwapCards(targetSlot);
                }
                else
                {
                    ParentSlot.CardWindow.RemoveHero(ParentSlot.SlotID);
                    targetSlot.CardWindow.AddHero(HeroData.Key, targetSlot.SlotID);
                }
            }

            AudioManager.Instance.PlaySound("ui_icon_drop");
            Messenger.Broadcast(MessageEnum.RefreshCards);
        }

        private void SwapCards(Slot targetSlot)
        {
            string tempHeroName = targetSlot.CurrentCard.GetComponent<Card>().HeroData.Key;
            targetSlot.CardWindow.RemoveHero(targetSlot.SlotID);
            targetSlot.CardWindow.AddHero(HeroData.Key, targetSlot.SlotID);
            ParentSlot.CardWindow.AddHero(tempHeroName, ParentSlot.SlotID);
        }
    }
}