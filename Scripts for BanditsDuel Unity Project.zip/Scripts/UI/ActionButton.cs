﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using LGG;
using Spine.Unity;
using UnityEngine.UI;

namespace BD
{
    public class ActionButton : LGBehaviour
    {
        public Unit LocalUnit;
        public SkeletonAnimation ActionAnimation, BGAnimation;
        private bool actionSet;

        public void Set(Unit u)
        {
            LocalUnit = u;
            LocalUnit.ActionButton = this;

            if (LocalUnit.Weapon.Data.ActionButtonSkeleton == null)
            {
                return;
            }

            ActionAnimation.skeletonDataAsset = LocalUnit.Weapon.Data.ActionButtonSkeleton;
            ActionAnimation.Initialize(true);
            ActionAnimation.GetComponent<MeshRenderer>().sortingLayerName = "GameUI";

            switch (LocalUnit.Weapon.Data.Key)
            {
                case "Revolver":
                    ActionAnimation.transform.localScale = new Vector3(8f, 8f, 1f);
                    ActionAnimation.transform.localPosition = new Vector3(-75f, -75f, ActionAnimation.transform.localPosition.z);

                    ActionAnimation.state.ClearTracks();
                    ActionAnimation.state.SetAnimation(0, "SHOOT", false).time = 0.1f;
                    ActionAnimation.timeScale = 0f;
                    break;
                case "Barrel":
                    ActionAnimation.transform.localScale = new Vector3(9f, 7f, 1f);
                    ActionAnimation.transform.localPosition = new Vector3(0f, -27f, ActionAnimation.transform.localPosition.z);
                    break;
                case "Dynamite":
                    break;
                default:
                    break;
            }

            ActionAnimation.skeleton.SetColor(new Color(0.3f, 0.3f, 0.3f, 0.5f));
            BGAnimation.skeleton.SetColor(new Color(0.3f, 0.3f, 0.3f, 0.5f));
        }

        public void Activate()
        {
            if (actionSet)
            {
                LocalUnit.Weapon.Activate();
            }
        }

        public void ToggleActionAnimation(bool show)
        {
            if (show)
            {
                BGAnimation.skeleton.SetColor(new Color(1f, 1f, 1f));
                ActionAnimation.skeleton.SetColor(new Color(1f, 1f, 1f));
                GetComponent<Clickable>().BloopOnPress = true;
            }
            else
            {
                BGAnimation.skeleton.SetColor(new Color(0.3f, 0.3f, 0.3f, 0.5f));
                ActionAnimation.skeleton.SetColor(new Color(0.3f, 0.3f, 0.3f, 0.5f));
                GetComponent<Clickable>().BloopOnPress = false;
            }

            actionSet = show;
        }
    }
}