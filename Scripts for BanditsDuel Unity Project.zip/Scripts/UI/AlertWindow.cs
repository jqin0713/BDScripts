﻿using UnityEngine;
using System.Collections;
using LGG;
using TMPro;

namespace BD
{
    public class AlertWindow : LGBehaviour
    {
        public TextMeshProUGUI Title;
        public TextMeshProUGUI Message;

        protected override void AddListeners()
        {
            base.AddListeners();

            Messenger.AddListener<string, string>(MessageEnum.SetAlert, Set);
        }

        public void Set(string title, string message)
        {
            Title.text = title;
            Message.text = message;
            gameObject.SetActive(true);
            //LoadingScreen.Instance.FadeIn(); 
        }

        public void Close()
        {
            gameObject.SetActive(false);
            //SceneManager.Instance.SwitchScene("Main");
        }
    }
}