﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using LGG;
using UnityEngine.UI;
using TMPro;
using UnityEngine.EventSystems;

namespace BD
{
	public class GameOverWindow : LGBehaviour
	{
		[SerializeField] private TextMeshProUGUI message;

		public void ShowWindow()
		{
			gameObject.SetActive(true);
		}

		public void HideWindow() {
			gameObject.SetActive (false);
		}

		public void GameOver()
		{
			if (!GameManager.Instance.IsServer)
            {
                if (Player.Authoritative.ClientID == 1 && GameManager.Instance.DuelManager.Player1.Score > GameManager.Instance.DuelManager.Player2.Score)
                {
                    message.text = "You Win!";
                }
                else if (Player.Authoritative.ClientID == 2 && GameManager.Instance.DuelManager.Player2.Score > GameManager.Instance.DuelManager.Player1.Score)
                {
                    message.text = "You Win!";
                }
                else
                {
                    message.text = "You Lose!";
                }
            }
		}
	}
}

