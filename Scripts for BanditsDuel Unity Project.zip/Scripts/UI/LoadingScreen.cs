﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

namespace BD
{
    public class LoadingScreen : LGG.LGSingleton<LoadingScreen>
    {
       
    }
}
