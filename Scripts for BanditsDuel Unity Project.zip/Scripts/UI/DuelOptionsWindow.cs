﻿using UnityEngine;
using System.Collections;
using LGG;
using UnityEngine.EventSystems;

namespace BD
{
    public class DuelOptionsWindow : LGBehaviour
    {
        public void ToggleWindowActive()
        {
            gameObject.SetActive(!gameObject.activeSelf);
        }
    }
}